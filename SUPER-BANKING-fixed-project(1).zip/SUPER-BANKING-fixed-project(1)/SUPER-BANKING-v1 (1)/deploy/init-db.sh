#!/bin/sh
set -eu
psql -v ON_ERROR_STOP=1 --username postgres --dbname postgres --set=pw="$SB_DB_PASSWORD" <<'SQL'
CREATE ROLE sb LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD :'pw';
CREATE DATABASE superbanking OWNER sb;
SQL
