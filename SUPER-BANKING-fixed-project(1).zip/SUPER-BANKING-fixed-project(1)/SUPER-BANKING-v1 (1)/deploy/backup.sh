#!/bin/sh
set -eu
: "${DATABASE_URL:?DATABASE_URL required}"
: "${PRIVATE_STORAGE_DIR:?PRIVATE_STORAGE_DIR required}"
: "${BACKUP_DIR:?BACKUP_DIR required}"
umask 077
dest="$BACKUP_DIR/$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$dest"
pg_dump --format=custom --no-owner --file="$dest/database.dump" "${DATABASE_URL%%\?*}"
tar -czf "$dest/documents.tar.gz" -C "$PRIVATE_STORAGE_DIR" .
printf 'Backup complete: %s\n' "$dest"
