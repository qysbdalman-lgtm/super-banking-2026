// لا يخزن مستندات الهوية أو API أو بيانات المستخدم في ذاكرة التخزين المؤقت.
const CACHE='sb-shell-v1';
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(c=>c.addAll(['/offline.html','/icons/icon-192.png'])));self.skipWaiting()});
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(url.origin!==self.location.origin||url.pathname.startsWith('/api')||event.request.method!=='GET')return;if(event.request.mode==='navigate')event.respondWith(fetch(event.request).catch(()=>caches.match('/offline.html')))});
self.addEventListener('push',event=>event.waitUntil(self.registration.showNotification('SUPER BANKING',{body:'يوجد تحديث جديد. افتح التطبيق وسجل الدخول لعرض التفاصيل.',icon:'/icons/icon-192.png',tag:'sb-update',data:{url:'/'}})));
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil(clients.openWindow('/'))});
