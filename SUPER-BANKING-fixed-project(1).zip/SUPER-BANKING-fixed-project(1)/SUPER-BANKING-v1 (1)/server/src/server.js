require('dotenv').config();
const config = require('./config');

// فحص إعدادات الأمان قبل التشغيل — لا نشغّل النظام في الإنتاج بمفاتيح افتراضية
const weak =
  !process.env.DATABASE_URL ||
  !process.env.JWT_SECRET ||
  process.env.JWT_SECRET.length < 32 ||
  process.env.JWT_SECRET.includes('CHANGE_ME');

if (weak && process.env.NODE_ENV === 'production') {
  console.error('\n✖ إعدادات غير آمنة: DATABASE_URL و JWT_SECRET عشوائي (32 حرفًا على الأقل) مطلوبان في الإنتاج.\n');
  process.exit(1);
}

const app = require('./app');

let server = null;

// لا نفتح منفذًا عند استيراد التطبيق للاختبارات — فقط عند التشغيل المباشر.
if (require.main === module) {
  server = app.listen(config.port, () => {
    console.log('\n  ╭────────────────────────────────────────────────╮');
    console.log('  │   السوبر البنكي الداخلي — SUPER BANKING        │');
    console.log(`  │   الواجهة البرمجية: http://localhost:${config.port}/api    │`);
    console.log('  ╰────────────────────────────────────────────────╯\n');
  });
  const shutdown = () => server.close(() => process.exit(0));
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

module.exports = { app, server };
