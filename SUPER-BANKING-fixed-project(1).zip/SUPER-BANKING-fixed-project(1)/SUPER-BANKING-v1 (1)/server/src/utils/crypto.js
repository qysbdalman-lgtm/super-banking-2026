const crypto = require('crypto');

const ALGO = 'aes-256-gcm';

function keyFrom(secret) {
  return crypto.createHash('sha256').update(String(secret)).digest();
}

/**
 * تشفير بيانات الربط المصرفي (بيانات اعتماد الجهة) قبل حفظها في قاعدة البيانات.
 * المفتاح يُشتق من JWT_SECRET على الخادم فقط، ولا يصل إلى الواجهة أبدًا.
 */
function encryptSecret(plain, secret) {
  if (!plain) return null;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, keyFrom(secret), iv);
  const enc = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString('base64')}:${tag.toString('base64')}:${enc.toString('base64')}`;
}

function decryptSecret(payload, secret) {
  if (!payload) return null;
  const parts = String(payload).split(':');
  if (parts.length !== 4 || parts[0] !== 'v1') return null;
  try {
    const iv = Buffer.from(parts[1], 'base64');
    const tag = Buffer.from(parts[2], 'base64');
    const data = Buffer.from(parts[3], 'base64');
    const decipher = crypto.createDecipheriv(ALGO, keyFrom(secret), iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
  } catch (e) {
    return null;
  }
}

function sha256(input) {
  return crypto.createHash('sha256').update(String(input)).digest('hex');
}

function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

function maskSecret(value) {
  if (!value) return null;
  const s = String(value);
  if (s.length <= 4) return '****';
  return `${s.slice(0, 2)}****${s.slice(-2)}`;
}

module.exports = { encryptSecret, decryptSecret, sha256, randomToken, maskSecret };
