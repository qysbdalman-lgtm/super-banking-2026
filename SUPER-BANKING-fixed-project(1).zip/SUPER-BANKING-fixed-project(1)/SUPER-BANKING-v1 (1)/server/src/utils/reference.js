const { prisma } = require('../db');

const PREFIX = {
  AGENT: 'AG',
  ACCOUNT_REQUEST: 'AR',
  TRANSFER: 'TR',
  TICKET: 'TK',
  CONTRACT: 'CT',
  RECEIPT: 'RC',
  COMMISSION: 'CM',
  SETTLEMENT: 'ST',
};

/**
 * توليد أرقام مرجعية فريدة لا تتكرر.
 * يعتمد على التاريخ + تسلسل ذرّي داخل جدول العدّادات لمنع التكرار حتى مع الطلبات المتزامنة.
 */
async function nextReference(kind) {
  const prefix = PREFIX[kind] || 'RF';
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const period = `${y}${m}`;
  const key = `${prefix}-${period}`;

  // upsert ذرّي: يضمن تسلسلًا فريدًا لكل بادئة/شهر
  const rows = await prisma.$queryRaw`
    INSERT INTO "ReferenceCounter" ("key", "value")
    VALUES (${key}, 1)
    ON CONFLICT ("key") DO UPDATE SET "value" = "ReferenceCounter"."value" + 1
    RETURNING "value"
  `;
  const seq = Number(rows[0].value);
  return `${prefix}-${period}-${String(seq).padStart(5, '0')}`;
}

module.exports = { nextReference };
