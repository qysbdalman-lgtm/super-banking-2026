const rateLimit = require('express-rate-limit');

/**
 * حماية من محاولات الدخول المتكررة (Brute force).
 * تُسجَّل كل محاولة في جدول LoginAttempt، وهذا الحد يمنع الإساءة الآلية.
 */
const loginLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'محاولات دخول كثيرة. حاول مرة أخرى بعد 10 دقائق.' },
  skipSuccessfulRequests: true,
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'عدد الطلبات كبير. حاول بعد قليل.' },
});

const writeLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'عدد عمليات الكتابة كبير. حاول بعد قليل.' },
});

module.exports = { loginLimiter, apiLimiter, writeLimiter };
