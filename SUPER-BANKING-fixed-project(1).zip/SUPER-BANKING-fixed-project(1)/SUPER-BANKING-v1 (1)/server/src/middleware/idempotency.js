const { prisma } = require('../db');
const { HttpError } = require('./error');

/**
 * منع تكرار تنفيذ العملية عند إعادة المحاولة أو انقطاع الاتصال.
 * يُستخدم على العمليات الحساسة (إنشاء حوالة) اعتمادًا على مفتاح idempotencyKey فريد.
 */
function idempotency(model) {
  return async (req, res, next) => {
    try {
      const key = req.body?.idempotencyKey || req.headers['idempotency-key'];
      if (!key) return next();
      const existing = await prisma[model].findUnique({ where: { idempotencyKey: String(key) } });
      if (existing) {
        // نُعيد نفس السجل السابق بدل إنشاء عملية ثانية (منع التكرار عند إعادة المحاولة)
        return res.status(200).json({
          ...existing,
          id: existing.id,
          replayed: true,
          duplicated: true,
          message: 'تم استلام الطلب سابقًا ولم يُنفَّذ مرة أخرى (منع التكرار).',
          data: existing,
        });
      }
      next();
    } catch (e) {
      next(e);
    }
  };
}

module.exports = { idempotency, HttpError };
