const { z } = require('zod');

/** التحقق من صحة البيانات على الخادم (لا نثق بأي مدخلات من الواجهة) */
function validate(schema, source = 'body') {
  return (req, res, next) => {
    const result = schema.safeParse(req[source]);
    if (!result.success) {
      const issues = result.error.issues.map((i) => ({
        field: i.path.join('.') || '_',
        message: i.message,
      }));
      return res.status(400).json({ error: 'بيانات غير صحيحة.', issues });
    }
    req[source] = result.data;
    next();
  };
}

const ARABIC_NAME = /^[\u0600-\u06FF\s'\-\.]{3,}$/;
const PHONE_YE = /^[0-9]{7,15}$/;
const NATIONAL_ID = /^[0-9A-Za-z]{6,20}$/;

const schemas = {
  login: z.object({
    identifier: z.string().min(3, 'أدخل اسم المستخدم أو رقم الهاتف'),
    password: z.string().min(6, 'كلمة المرور قصيرة جدًا'),
    otp: z.string().optional(),
  }),

  changePassword: z.object({
    currentPassword: z.string().min(6),
    newPassword: z
      .string()
      .min(8, 'كلمة المرور يجب ألا تقل عن 8 أحرف')
      .regex(/[A-Za-z]/, 'يجب أن تحتوي على حرف واحد على الأقل')
      .regex(/[0-9]/, 'يجب أن تحتوي على رقم واحد على الأقل'),
  }),

  agentApply: z.object({
    fullName4: z.string().regex(ARABIC_NAME, 'أدخل الاسم الرباعي بالعربية'),
    nationalId: z.string().regex(NATIONAL_ID, 'رقم بطاقة غير صحيح'),
    phone: z.string().regex(PHONE_YE, 'رقم هاتف غير صحيح'),
    whatsapp: z.string().regex(PHONE_YE, 'رقم واتساب غير صحيح').optional().or(z.literal('')),
    governorate: z.string().min(2),
    district: z.string().min(2),
    area: z.string().optional().or(z.literal('')),
    address: z.string().optional().or(z.literal('')),
    businessName: z.string().optional().or(z.literal('')),
    businessType: z.string().optional().or(z.literal('')),
    type: z.enum(['GOLD', 'SILVER']).optional(),
    guarantorName: z.string().optional().or(z.literal('')),
    guarantorPhone: z.string().optional().or(z.literal('')),
    guarantorId: z.string().optional().or(z.literal('')),
    notes: z.string().optional().or(z.literal('')),
  }),

  agentReview: z.object({
    action: z.enum(['APPROVE', 'REJECT', 'NEEDS_INFO', 'SUSPEND', 'REACTIVATE', 'CANCEL']),
    type: z.enum(['GOLD', 'SILVER']).optional(),
    services: z.array(z.string()).optional(),
    banks: z.array(z.number().int()).optional(),
    reason: z.string().optional().or(z.literal('')),
  }),

  customer: z.object({
    fullName4: z.string().regex(ARABIC_NAME, 'أدخل الاسم الرباعي بالعربية'),
    nationalId: z.string().regex(NATIONAL_ID, 'رقم بطاقة غير صحيح'),
    phone: z.string().regex(PHONE_YE, 'رقم هاتف غير صحيح'),
    altPhone: z.string().regex(PHONE_YE, 'رقم بديل غير صحيح').optional().or(z.literal('')),
    dob: z.string().optional().or(z.literal('')),
    gender: z.string().optional().or(z.literal('')),
    governorate: z.string().min(2),
    district: z.string().min(2),
    area: z.string().optional().or(z.literal('')),
    address: z.string().optional().or(z.literal('')),
    accountType: z.string().optional().or(z.literal('')),
    bankId: z.number().int().optional(),
    agentId: z.number().int().optional(),
  }),

  accountRequest: z.object({
    customerId: z.number().int().optional(),
    customer: schemas_customer_ref().optional(),
    bankId: z.number().int(),
    accountType: z.string().min(1, 'اختر نوع الحساب'),
    agentId: z.number().int().optional(),
    consentGiven: z.boolean(),
    notes: z.string().optional().or(z.literal('')),
  }),

  accountRequestStatus: z.object({
    status: z.enum([
      'DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'NEEDS_INFO',
      'SENT_TO_BANK', 'BANK_APPROVED', 'REJECTED', 'COMPLETED', 'CANCELLED',
    ]),
    note: z.string().optional().or(z.literal('')),
    bankRefNo: z.string().optional().or(z.literal('')),
  }),

  transfer: z.object({
    bankId: z.number().int(),
    type: z.enum(['OUTGOING', 'INCOMING']),
    senderName: z.string().min(3),
    senderPhone: z.string().regex(PHONE_YE).optional().or(z.literal('')),
    beneficiaryName: z.string().min(3),
    beneficiaryPhone: z.string().regex(PHONE_YE).optional().or(z.literal('')),
    amount: z.number().positive('المبلغ يجب أن يكون أكبر من صفر'),
    currency: z.string().default('YER'),
    notes: z.string().optional().or(z.literal('')),
    idempotencyKey: z.string().min(8, 'مفتاح منع التكرار مطلوب'),
  }),

  transferStatus: z.object({
    status: z.enum(['PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'REJECTED', 'CANCELLED']),
    note: z.string().optional().or(z.literal('')),
    bankRefNo: z.string().optional().or(z.literal('')),
  }),

  bank: z.object({
    code: z.string().min(2).max(40),
    nameAr: z.string().min(2),
    shortName: z.string().optional().or(z.literal('')),
    logoUrl: z.string().url().optional().or(z.literal('')),
    iconKey: z.string().optional(),
    description: z.string().optional().or(z.literal('')),
    integrationStatus: z.enum(['NOT_AVAILABLE', 'REGISTRATION_PENDING', 'CONNECTED', 'MAINTENANCE', 'SUSPENDED']).optional(),
    apiBaseUrl: z.string().optional().or(z.literal('')),
    apiAuthType: z.string().optional().or(z.literal('')),
    credentials: z.string().optional().or(z.literal('')),
    contactInfo: z.string().optional().or(z.literal('')),
    requirements: z.string().optional().or(z.literal('')),
    serviceStateNote: z.string().optional().or(z.literal('')),
    sortOrder: z.number().int().optional(),
    isActive: z.boolean().optional(),
  }),

  ticket: z.object({
    subject: z.string().min(3),
    description: z.string().min(5),
    bankId: z.number().int().optional(),
    serviceKey: z.string().optional().or(z.literal('')),
    priority: z.enum(['منخفضة', 'عادية', 'عالية', 'عاجلة']).optional(),
    operationRef: z.string().optional().or(z.literal('')),
    attachmentId: z.string().optional().or(z.literal('')),
  }),

  ticketReply: z.object({
    body: z.string().min(2),
    status: z.enum(['NEW', 'UNDER_REVIEW', 'IN_PROGRESS', 'WAITING_INFO', 'RESOLVED', 'CLOSED']).optional(),
  }),

  circular: z.object({
    title: z.string().min(3),
    body: z.string().min(5),
    audience: z.string().default('all'),
    isActive: z.boolean().optional(),
  }),

  userCreate: z.object({
    username: z.string().min(3).max(40),
    fullName: z.string().min(3),
    phone: z.string().regex(PHONE_YE).optional().or(z.literal('')),
    email: z.string().email().optional().or(z.literal('')),
    roleKey: z.string().min(2),
    password: z
      .string()
      .min(8, 'كلمة المرور يجب ألا تقل عن 8 أحرف')
      .regex(/[A-Za-z]/, 'يجب أن تحتوي على حرف واحد على الأقل')
      .regex(/[0-9]/, 'يجب أن تحتوي على رقم واحد على الأقل'),
    governorate: z.string().optional().or(z.literal('')),
    district: z.string().optional().or(z.literal('')),
    agentId: z.number().int().optional(),
  }),

  userStatus: z.object({
    status: z.enum(['ACTIVE', 'SUSPENDED', 'DISABLED', 'PENDING']),
    reason: z.string().optional().or(z.literal('')),
  }),

  commissionRule: z.object({
    bankId: z.number().int(),
    serviceKey: z.string().min(2),
    feeAmount: z.number().min(0),
    commissionAmount: z.number().min(0),
    enabled: z.boolean().optional(),
  }),

  commissionDecision: z.object({
    ids: z.array(z.number().int()).min(1),
    action: z.enum(['APPROVE', 'PAY', 'CANCEL']),
    reason: z.string().optional().or(z.literal('')),
  }),

  settlement: z.object({
    agentId: z.number().int(),
    periodStart: z.string(),
    periodEnd: z.string(),
    note: z.string().optional().or(z.literal('')),
    approve: z.boolean().optional(),
  }),

  notifySend: z.object({
    title: z.string().min(3),
    body: z.string().min(3),
    type: z.string().default('general'),
    audience: z.enum(['all', 'agents', 'staff', 'role', 'user']).default('all'),
    roleKey: z.string().optional(),
    userId: z.number().int().optional(),
    bankId: z.number().int().optional(),
  }),

  setting: z.object({ value: z.string() }),
};

function schemas_customer_ref() {
  return z.object({
    fullName4: z.string().regex(ARABIC_NAME, 'أدخل الاسم الرباعي بالعربية'),
    nationalId: z.string().regex(NATIONAL_ID, 'رقم بطاقة غير صحيح'),
    phone: z.string().regex(PHONE_YE, 'رقم هاتف غير صحيح'),
    altPhone: z.string().optional().or(z.literal('')),
    governorate: z.string().min(2),
    district: z.string().min(2),
    area: z.string().optional().or(z.literal('')),
    address: z.string().optional().or(z.literal('')),
    dob: z.string().optional().or(z.literal('')),
    gender: z.string().optional().or(z.literal('')),
  });
}

module.exports = { validate, schemas };
