function notFound(req, res) {
  res.status(404).json({ error: 'المسار غير موجود.', path: req.originalUrl });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const status = err.status || err.statusCode || 500;
  const isProd = process.env.NODE_ENV === 'production';
  if (status >= 500) console.error('[error]', err);
  res.status(status).json({
    error: err.expose || status < 500 ? err.message : 'حدث خطأ في الخادم. حاول لاحقًا.',
    code: err.code || undefined,
    details: !isProd && status >= 500 ? err.stack : undefined,
  });
}

function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

class HttpError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.expose = true;
    this.code = code;
  }
}

module.exports = { notFound, errorHandler, asyncHandler, HttpError };
