/**
 * صلاحيات على الخادم (RBAC). الحماية الفعلية هنا، وليس في الواجهة فقط.
 */
function requirePermission(...keys) {
  return (req, res, next) => {
    const perms = req.user?.permissions || [];
    const ok = keys.some((k) => perms.includes(k));
    if (!ok) {
      return res.status(403).json({
        error: 'لا تملك الصلاحية لتنفيذ هذا الإجراء.',
        required: keys,
      });
    }
    next();
  };
}

function requireRole(...roleKeys) {
  return (req, res, next) => {
    if (!req.user || !roleKeys.includes(req.user.roleKey)) {
      return res.status(403).json({ error: 'هذا الإجراء متاح لأدوار محددة فقط.', required: roleKeys });
    }
    next();
  };
}

/** هل المستخدم يملك الصلاحية؟ (للتحقق داخل منطق العمل) */
function can(user, permissionKey) {
  return !!user && (user.permissions || []).includes(permissionKey);
}

/** تقييد الوصول إلى بيانات وكيل معيّن: الوكيل يرى ملفه فقط */
function scopeAgentId(user) {
  if (!user) return null;
  if (user.roleKey === 'AGENT_GOLD' || user.roleKey === 'AGENT_SILVER') return user.agentId ?? -1;
  return null;
}

module.exports = { requirePermission, requireRole, can, scopeAgentId };
