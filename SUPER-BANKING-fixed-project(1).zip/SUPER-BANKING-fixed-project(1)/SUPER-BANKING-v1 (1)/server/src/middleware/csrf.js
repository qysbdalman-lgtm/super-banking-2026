/**
 * حماية CSRF بسيطة وفعّالة: كل طلب مُغيِّر للبيانات من الواجهة يجب أن يحمل
 * الترويسة X-SB-Request. تمنع استدعاء الواجهات البرمجية من صفحات خارجية.
 * تُستثنى نقاط الدخول العامة (login / recovery / reset) لأن المستخدم لم يمتلك جلسة بعد.
 */
const PUBLIC_WRITES = [
  '/api/auth/login',
  '/api/auth/recovery',
  '/api/auth/reset',
  '/api/applications/agent',
];

function csrfProtection(req, res, next) {
  const mutating = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method);
  if (!mutating) return next();
  if (PUBLIC_WRITES.some((p) => req.originalUrl.startsWith(p))) return next();
  if (req.headers['x-sb-request'] !== '1') {
    return res.status(403).json({
      error: 'طلب غير موثوق: الترويسة X-SB-Request مطلوبة لتنفيذ هذا الإجراء.',
    });
  }
  return next();
}

module.exports = { csrfProtection };
