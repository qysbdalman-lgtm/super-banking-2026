const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const multer = require('multer');
const config = require('../config');

/**
 * تخزين الوثائق في مجلد خاص خارج أي مجلد عام (غير متاح عبر روابط عامة).
 * التحقق من الامتداد والنوع والحجم، ومنع الملفات الخطرة.
 */
const ALLOWED_EXT = new Set(['.jpg', '.jpeg', '.png', '.webp', '.pdf']);
const ALLOWED_MIME = new Set([
  'image/jpeg', 'image/png', 'image/webp', 'application/pdf',
]);

fs.mkdirSync(config.privateStorageDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const now = new Date();
    const sub = path.join(String(now.getFullYear()), String(now.getMonth() + 1).padStart(2, '0'));
    const dir = path.join(config.privateStorageDir, sub);
    fs.mkdirSync(dir, { recursive: true });
    req._storageSub = sub;
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${crypto.randomBytes(8).toString('hex')}${ext}`);
  },
});

function fileFilter(req, file, cb) {
  const ext = path.extname(file.originalname).toLowerCase();
  if (!ALLOWED_EXT.has(ext)) {
    return cb(new Error('امتداد ملف غير مسموح. المسموح: JPG, PNG, WEBP, PDF'));
  }
  if (!ALLOWED_MIME.has(file.mimetype)) {
    return cb(new Error('نوع ملف غير مسموح.'));
  }
  // منع المسارات المتلاعب بها
  if (file.originalname.includes('..') || file.originalname.includes('/')) {
    return cb(new Error('اسم ملف غير صالح.'));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: config.maxUploadMb * 1024 * 1024, files: 6 },
});

module.exports = { upload };
