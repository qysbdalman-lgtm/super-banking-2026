const jwt = require('jsonwebtoken');
const config = require('../config');
const { prisma } = require('../db');
const { sha256 } = require('../utils/crypto');

/** يستخرج التوكن من ترويسة Authorization أو من الكوكي (جلسة الويب) */
function extractToken(req) {
  const h = req.headers.authorization || '';
  if (h.startsWith('Bearer ')) return h.slice(7).trim();
  if (req.cookies && req.cookies.sb_token) return req.cookies.sb_token;
  return null;
}

const SESSION_INCLUDE = {
  user: {
    include: {
      role: { include: { permissions: { include: { permission: true } } } },
      agent: { select: { id: true, code: true, status: true, type: true } },
    },
  },
};

/**
 * مصادقة الطلب. يقبل شكلين للتوكن:
 *  1) JWT قصير العمر (accessToken) يحمل معرّف الجلسة sid.
 *  2) توكن الجلسة الخام نفسه (كوكي httpOnly أو Authorization) ويُطابق ببصمة sha256.
 * ثم يتحقق من أن الجلسة غير ملغاة ومن حالة المستخدم، ويحمّل دوره وصلاحياته.
 */
async function authenticate(req, res, next) {
  try {
    const token = extractToken(req);
    if (!token) return res.status(401).json({ error: 'غير مصرح: يلزم تسجيل الدخول.' });

    let payload = null;
    try {
      payload = jwt.verify(token, config.jwtSecret);
    } catch (e) {
      payload = null; // ليس JWT — قد يكون توكن جلسة خام
    }

    let session = null;
    if (payload && payload.sid) {
      session = await prisma.session.findUnique({ where: { id: String(payload.sid) }, include: SESSION_INCLUDE });
    }
    if (!session) {
      session = await prisma.session.findUnique({ where: { tokenHash: sha256(token) }, include: SESSION_INCLUDE });
    }

    if (!session || session.revokedAt || session.expiresAt < new Date()) {
      return res.status(401).json({ error: 'الجلسة غير صالحة أو منتهية. يرجى تسجيل الدخول من جديد.' });
    }
    const user = session.user;
    if (user.status !== 'ACTIVE') {
      return res.status(403).json({ error: 'الحساب غير مفعّل. راجع الإدارة.' });
    }

    req.user = {
      id: user.id,
      username: user.username,
      fullName: user.fullName,
      roleId: user.roleId,
      roleKey: user.role.key,
      roleName: user.role.nameAr,
      permissions: user.role.permissions.map((rp) => rp.permission.key),
      mustChangePassword: user.mustChangePassword,
      agentId: user.agent?.id ?? null,
      agentCode: user.agent?.code ?? null,
      agentStatus: user.agent?.status ?? null,
      agentType: user.agent?.type ?? null,
    };
    req.sessionId = session.id;
    req.authToken = token;
    next();
  } catch (e) {
    next(e);
  }
}

/** مصادقة اختيارية: تُحمّل المستخدم إن وُجد توكن، دون رفض الطلب */
async function optionalAuth(req, res, next) {
  const token = extractToken(req);
  if (!token) return next();
  return authenticate(req, res, next);
}

module.exports = { authenticate, optionalAuth, extractToken };
