const {prisma}=require('./db');
const {can}=require('./middleware/rbac');
const agentRole=u=>['AGENT_GOLD','AGENT_SILVER'].includes(u.roleKey);
async function attachScope(req,res,next){try{
 if(req.user.roleKey==='CUSTOMER')return res.status(403).json({error:'بوابة العميل المستقلة غير مفعلة؛ يلزم نموذج ملكية منفصل قبل تفعيلها.'});
 req.agent=agentRole(req.user)?await prisma.agent.findUnique({where:{userId:req.user.id}}):null;
 if(agentRole(req.user)&&(!req.agent||req.agent.status!=='APPROVED'))return res.status(403).json({error:'لا تتوفر صلاحيات الخدمات قبل اعتماد الوكيل وتفعيله.'});
 req.scope=req.agent?{agentId:req.agent.id}:{};next();
}catch(e){next(e)}}
async function serviceAllowed(req,key,bankId){
 if(!req.agent)return true;
 const service=await prisma.agentService.findUnique({where:{agentId_serviceKey:{agentId:req.agent.id,serviceKey:key}}});
 const bank=await prisma.agentBank.findUnique({where:{agentId_bankId:{agentId:req.agent.id,bankId}}});
 return !!service?.enabled&&!!bank;
}
function sanitizeCustomer(c,user){if(!c)return c;return {...c,nationalId:can(user,'customers.view_sensitive')?c.nationalId:'••••'+c.nationalId.slice(-3)}}
module.exports={attachScope,serviceAllowed,sanitizeCustomer,agentRole};
