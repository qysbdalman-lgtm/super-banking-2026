/**
 * واجهة موحّدة للربط مع الجهات المصرفية (Bank Adapter Interface).
 * ---------------------------------------------------------------
 * ⚠️ مهم جدًا:
 * لا يوجد في هذا المشروع أي ربط رسمي فعلي مع أي بنك. جميع الجهات تبدأ بحالة
 * "الربط غير متاح" (NOT_AVAILABLE) أو "طلب تسجيل قيد المعالجة" (REGISTRATION_PENDING).
 * هذا الملف يُنشئ البنية البرمجية اللازمة للربط، ولا يدّعي تنفيذ أي عملية مصرفية حقيقية.
 *
 * لتشغيل الربط فعليًا يجب توفير:
 *   1) موافقة رسمية من الجهة المصرفية على تشغيل الخدمة.
 *   2) عنوان واجهة API (apiBaseUrl) وطريقة المصادقة (apiAuthType).
 *   3) بيانات اعتماد رسمية تُحفظ مشفّرة على الخادم فقط (credentialsEnc).
 *   4) توثيق التوقيع/التحقق الأمني للاستجابات إن وجد.
 */

const STATUS = {
  NOT_AVAILABLE: 'NOT_AVAILABLE',
  REGISTRATION_PENDING: 'REGISTRATION_PENDING',
  CONNECTED: 'CONNECTED',
  MAINTENANCE: 'MAINTENANCE',
  SUSPENDED: 'SUSPENDED',
};

const STATUS_LABEL = {
  NOT_AVAILABLE: 'الربط غير متاح',
  REGISTRATION_PENDING: 'طلب تسجيل قيد المعالجة',
  CONNECTED: 'مرتبط رسميًا',
  MAINTENANCE: 'متوقف مؤقتًا (صيانة)',
  SUSPENDED: 'موقوف من الإدارة',
};

class BankAdapterError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

/**
 * تنفيذ عملية عبر واجهة الجهة.
 * في الوضع الحالي (بدون ربط رسمي) ترمي دائمًا خطأً واضحًا بدل تلفيق نجاح.
 */
async function executeOperation(bank, operation, payload) {
  if (!bank || bank.integrationStatus !== STATUS.CONNECTED) {
    throw new BankAdapterError(
      'INTEGRATION_NOT_AVAILABLE',
      `الربط الرسمي مع «${bank?.nameAr || 'الجهة'}» غير متاح حاليًا. ` +
        `حالة الربط: ${STATUS_LABEL[bank?.integrationStatus] || 'غير معروفة'}. ` +
        `لا يمكن تنفيذ العملية فعليًا قبل اعتماد الربط الرسمي.`
    );
  }
  if (!bank.apiBaseUrl) {
    throw new BankAdapterError('MISSING_API_URL', 'لم يتم إدخال عنوان واجهة API للجهة.');
  }
  // نقطة التوسعة: هنا يُنفَّذ نداء HTTP الحقيقي عند توفّر الربط الرسمي.
  throw new BankAdapterError(
    'ADAPTER_NOT_IMPLEMENTED',
    'بنية الربط جاهزة، لكن تنفيذ النداء الفعلي يحتاج إكمال بيانات الاعتماد والتوثيق الرسمي من الجهة.'
  );
}

/**
 * اختبار اتصال بالجهة. يُسجَّل ناتجه في سجل نتائج الربط (IntegrationLog).
 * لا يُدّعى نجاح الاتصال إن لم يوجد ربط رسمي.
 */
async function testConnection(bank) {
  const started = Date.now();
  if (bank.integrationStatus !== STATUS.CONNECTED) {
    return {
      success: false,
      latencyMs: Date.now() - started,
      message: `لا يمكن اختبار الاتصال: ${STATUS_LABEL[bank.integrationStatus] || 'حالة غير معروفة'}.`,
    };
  }
  if (!bank.apiBaseUrl) {
    return { success: false, latencyMs: Date.now() - started, message: 'عنوان واجهة API غير مُعرَّف.' };
  }
  if (!bank.credentialsEnc) {
    return { success: false, latencyMs: Date.now() - started, message: 'بيانات اعتماد الربط غير محفوظة.' };
  }
  return {
    success: false,
    latencyMs: Date.now() - started,
    message:
      'البنية جاهزة لاختبار الاتصال، لكن تنفيذ الاختبار الفعلي يحتاج موافقة الجهة وبيانات الاعتماد الرسمية.',
  };
}

module.exports = { STATUS, STATUS_LABEL, executeOperation, testConnection, BankAdapterError };
