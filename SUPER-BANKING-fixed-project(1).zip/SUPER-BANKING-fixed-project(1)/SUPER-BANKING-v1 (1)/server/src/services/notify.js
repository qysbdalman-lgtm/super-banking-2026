const { prisma } = require('../db');

/**
 * مركز إشعارات موحد. الإشعارات تُنشأ فقط عند أحداث حقيقية في النظام.
 * لا تُرسل أي بيانات حساسة (أرقام هوية/مبالغ تفصيلية) في نص الإشعار.
 */
async function notifyUsers(userIds, payload) {
  const ids = [...new Set((userIds || []).filter(Boolean))];
  if (!ids.length) return [];
  const created = await prisma.$transaction(
    ids.map((userId) =>
      prisma.notification.create({
        data: {
          userId,
          title: payload.title,
          body: payload.body,
          type: payload.type || 'general',
          iconKey: payload.iconKey || 'bell',
          serviceKey: payload.serviceKey || null,
          bankId: payload.bankId || null,
          entityType: payload.entityType || null,
          entityId: payload.entityId != null ? String(payload.entityId) : null,
        },
      })
    )
  );
  return created;
}

/** كل المستخدمين الذين يملكون صلاحية معينة */
async function usersWithPermission(permissionKey) {
  const rows = await prisma.user.findMany({
    where: {
      status: 'ACTIVE',
      role: { permissions: { some: { permission: { key: permissionKey } } } },
    },
    select: { id: true },
  });
  return rows.map((r) => r.id);
}

/** مستخدمو النظام ذوو الأدوار الإدارية (لمراجعة الطلبات والتعاميم) */
async function adminUserIds() {
  const rows = await prisma.user.findMany({
    where: {
      status: 'ACTIVE',
      role: { key: { in: ['OWNER', 'GM', 'TECH_ADMIN', 'REVIEWER', 'OPS_MONITOR'] } },
    },
    select: { id: true },
  });
  return rows.map((r) => r.id);
}

module.exports = { notifyUsers, usersWithPermission, adminUserIds };
