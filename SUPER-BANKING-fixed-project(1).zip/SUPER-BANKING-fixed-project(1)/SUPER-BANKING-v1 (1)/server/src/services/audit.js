const { prisma } = require('../db');

/**
 * سجل تدقيق غير قابل للتعديل من المستخدم العادي:
 * لا توجد أي واجهة لتعديل أو حذف سجلات التدقيق، والإضافة فقط.
 */
async function audit(req, { action, entityType, entityId, before, after }) {
  try {
    await prisma.auditLog.create({
      data: {
        actorId: req?.user?.id || null,
        actorName: req?.user?.fullName || 'نظام',
        actorRole: req?.user?.roleKey || null,
        action,
        entityType,
        entityId: entityId != null ? String(entityId) : null,
        before: before ?? undefined,
        after: after ?? undefined,
        ip: req?.ip || null,
        userAgent: req?.headers?.['user-agent'] || null,
      },
    });
  } catch (e) {
    // لا نُفشل العملية الأساسية بسبب سجل التدقيق، لكن نسجل الخطأ في الطرفية
    console.error('[audit] failed', e.message);
  }
}

function stripSensitive(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  const clone = Array.isArray(obj) ? [...obj] : { ...obj };
  for (const k of ['password', 'passwordHash', 'token', 'tokenHash', 'refreshHash', 'credentialsEnc', 'mfaSecretEnc']) {
    if (k in clone) clone[k] = '***';
  }
  return clone;
}

module.exports = { audit, stripSensitive };
