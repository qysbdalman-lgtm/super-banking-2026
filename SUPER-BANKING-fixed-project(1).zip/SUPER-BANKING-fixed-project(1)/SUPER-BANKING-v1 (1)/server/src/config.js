require('dotenv').config();
const path = require('path');

const num = (v, d) => (v === undefined || v === '' ? d : Number(v));

const config = {
  env: process.env.NODE_ENV || 'development',
  port: num(process.env.PORT, 4000),
  jwtSecret: process.env.JWT_SECRET || 'dev-only-insecure-secret',
  refreshSecret: process.env.REFRESH_SECRET || 'dev-only-insecure-refresh',
  sessionTtlHours: num(process.env.SESSION_TTL_HOURS, 12),
  accessTtlMinutes: num(process.env.ACCESS_TTL_MINUTES, 30),
  privateStorageDir: path.resolve(
    process.cwd(),
    process.env.PRIVATE_STORAGE_DIR || './storage/private'
  ),
  maxUploadMb: num(process.env.MAX_UPLOAD_MB, 8),
  auditRetentionDays: num(process.env.AUDIT_RETENTION_DAYS, 730),
  owner: {
    username: process.env.OWNER_USERNAME || 'owner',
    phone: process.env.OWNER_PHONE || '',
    fullName: process.env.OWNER_FULL_NAME || 'عبدالمانع عبدالرحمن قيس',
    password: process.env.OWNER_PASSWORD || '',
  },
  push: {
    publicKey: process.env.PUSH_VAPID_PUBLIC || '',
    privateKey: process.env.PUSH_VAPID_PRIVATE || '',
    email: process.env.PUSH_CONTACT_EMAIL || '',
  },
  isProd: (process.env.NODE_ENV || 'development') === 'production',
};

if(!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) throw new Error('JWT_SECRET آمنة مطلوبة بطول 32 حرفًا على الأقل');
module.exports = config;
