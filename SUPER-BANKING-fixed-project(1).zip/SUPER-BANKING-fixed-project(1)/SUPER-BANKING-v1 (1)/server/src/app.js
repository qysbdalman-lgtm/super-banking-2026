require('dotenv').config();
const path = require('path');
const fs = require('fs');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const morgan = require('morgan');

const config = require('./config');
const { notFound, errorHandler } = require('./middleware/error');
const { apiLimiter } = require('./middleware/rateLimit');
const { csrfProtection } = require('./middleware/csrf');

const app = express();
app.set('trust proxy', 1);

app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
    contentSecurityPolicy: false,
  })
);
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
if (!config.isProd) app.use(morgan('tiny'));

/**
 * حماية CSRF للطلبات القادمة بجلسة كوكي: نطلب ترويسة مخصصة لا يستطيع
 * موقع خارجي إرسالها في طلب عادي. الطلبات بتوكن Bearer (تطبيق/APK) مستثناة.
 */
app.use((req, res, next) => {
  const stateChanging = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method);
  const viaCookie = req.cookies && req.cookies.sb_token;
  if (stateChanging && viaCookie && req.headers['x-sb-request'] !== '1') {
    return res.status(403).json({ error: 'طلب غير موثوق: ترويسة الحماية X-SB-Request مطلوبة.' });
  }
  next();
});

app.get('/api/health', (req, res) =>
  res.json({
    ok: true,
    name: 'السوبر البنكي الداخلي — SUPER BANKING',
    version: '1.0.0',
    time: new Date().toISOString(),
  })
);

app.use('/api', apiLimiter);
app.use('/api', csrfProtection);

app.use('/api/applications', require('./routes/applications'));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/users', require('./routes/users'));
app.use('/api/banks', require('./routes/banks'));
app.use('/api/services', require('./routes/services'));
app.use('/api/agents', require('./routes/agents'));
app.use('/api/customers', require('./routes/customers'));
app.use('/api/requests', require('./routes/requests'));
app.use('/api/documents', require('./routes/documents'));
app.use('/api/files', require('./routes/files'));
app.use('/api/transfers', require('./routes/transfers'));
app.use('/api/finance', require('./routes/finance'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/circulars', require('./routes/circulars'));
app.use('/api/tickets', require('./routes/tickets'));
app.use('/api/audit', require('./routes/audit'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/reports', require('./routes/reports'));

// خدمة الواجهة المبنية في الإنتاج
const clientDist = path.resolve(__dirname, '../../client/dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get(/^(?!\/api).*/, (req, res) => res.sendFile(path.join(clientDist, 'index.html')));
}

app.use('/api', notFound);
app.use(errorHandler);

module.exports = app;
