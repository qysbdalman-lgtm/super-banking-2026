/**
 * تهيئة النظام: الأدوار، الصلاحيات، الخدمات، الجهات المصرفية الثمانية،
 * الإعدادات العامة، وحساب مالك النظام.
 *
 * ⚠️ لا توجد كلمة مرور ثابتة داخل الكود. كلمة مرور المالك تُقرأ من متغير البيئة
 * OWNER_PASSWORD، وإن لم تكن موجودة يُولَّد كلمة مرور عشوائية تُطبع مرة واحدة.
 */
require('dotenv').config();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { prisma } = require('../db');
const { ROLES } = require('../constants/roles');
const { ALL_PERMISSIONS, PERMISSION_LABELS } = require('../constants/permissions');
const config = require('../config');

const SERVICES = [
  { key: 'open_account', nameAr: 'فتح الحسابات', description: 'تسجيل طلبات فتح الحسابات المصرفية', category: 'accounts', iconKey: 'user-plus', requiresIntegration: false, sortOrder: 10 },
  { key: 'transfers', nameAr: 'الحوالات المالية', description: 'استلام وإرسال الحوالات', category: 'transfers', iconKey: 'send', requiresIntegration: true, sortOrder: 20 },
  { key: 'salary_disbursement', nameAr: 'صرف المرتبات', description: 'صرف مرتبات الجهات المفوَّضة (يحتاج تفويضًا رسميًا)', category: 'salary', iconKey: 'wallet', requiresIntegration: true, sortOrder: 30 },
  { key: 'account_followup', nameAr: 'متابعة الحسابات', description: 'متابعة حالة حسابات العملاء', category: 'accounts', iconKey: 'search', requiresIntegration: true, sortOrder: 40 },
  { key: 'deposits', nameAr: 'الإيداعات والتسويات', description: 'خدمات الإيداع والتسوية المالية', category: 'finance', iconKey: 'banknote', requiresIntegration: true, sortOrder: 50 },
];

const BANKS = [
  { code: 'SHUMOOL', nameAr: 'بنك الشمول للتمويل الأصغر الإسلامي', nameEn: 'Shumul Bank for Islamic Microfinance', shortName: 'بنك الشمول', iconKey: 'bank', sortOrder: 10, description: 'بنك تمويل أصغر إسلامي — خدمات الحسابات والتمويل الأصغر. (الأسماء الإنجليزية مستخرجة حرفيًا من ملف «البنوك التجارية.pdf».)' },
  { code: 'ADEN', nameAr: 'بنك عدن للتمويل الأصغر', nameEn: 'Aden Bank for Microfinance', shortName: 'بنك عدن', iconKey: 'bank', sortOrder: 20, description: 'بنك تمويل أصغر — خدمات الحسابات والتمويل الأصغر.' },
  { code: 'QASIMI', nameAr: 'بنك القاسمي للتمويل الأصغر الإسلامي', nameEn: 'Qasemi Islamic Microfinance Bank', shortName: 'بنك القاسمي', iconKey: 'bank', sortOrder: 30, description: 'بنك تمويل أصغر إسلامي.' },
  { code: 'BUSAIRI', nameAr: 'بنك البسيري الدولي', nameEn: 'Albasiri International Bank', shortName: 'بنك البسيري', iconKey: 'bank', sortOrder: 40, description: 'بنك دولي — خدمات مصرفية متعددة.' },
  { code: 'KURAIMI', nameAr: 'بنك الكريمي للتمويل الأصغر الإسلامي', nameEn: 'AlKuraimi Islamic Microfinance Bank', shortName: 'بنك الكريمي', iconKey: 'bank', sortOrder: 50, description: 'بنك تمويل أصغر إسلامي.' },
  { code: 'QUTAIBI', nameAr: 'بنك القطيبي', nameEn: 'Qutaibi Bank', shortName: 'بنك القطيبي', iconKey: 'bank', sortOrder: 60, description: 'بنك تجاري — خدمات مصرفية.' },
  { code: 'SHARQ', nameAr: 'بنك الشرق اليمني للتمويل الأصغر الإسلامي', nameEn: 'Sharq Yemeni Bank for Islamic Microfinance', shortName: 'بنك الشرق', iconKey: 'bank', sortOrder: 70, description: 'بنك تمويل أصغر إسلامي.' },
  { code: 'UNMONEY', nameAr: 'الشبكة الموحدة للأموال UNMoney', nameEn: 'UNMoney Unified Money Network', shortName: 'UNMoney', iconKey: 'network', sortOrder: 80, description: 'شبكة تحويل أموال موحدة — خدمات الحوالات.' },
];

const SETTINGS = {
  org_name: 'السوبر البنكي الداخلي',
  org_name_en: 'SUPER BANKING',
  slogan: 'خدمات مصرفية.. أقرب إليك',
  tagline: 'معًا نحو خدمات مالية أسهل وأقرب إليك',
  intro: 'من هنا تبدأ خدماتك المصرفية… من قريتك ومدينتك',
  address: 'محافظة أبين – لودر – الشارع العام – مبنى البسام، الدور الثاني',
  phones: '777762996، 784300081، 784300082',
  owner_name: 'عبدالمانع عبدالرحمن قيس',
  currency: 'YER',
  account_commission_default: '300',
  support_hours: 'السبت - الخميس، 8:00 صباحًا - 3:00 مساءً',
  app_version: '1.0.0',
  maintenance_mode: 'false',
};

async function main() {
  console.log('\n▶ تهيئة SUPER BANKING ...\n');

  // 1) الصلاحيات
  for (const key of ALL_PERMISSIONS) {
    await prisma.permission.upsert({
      where: { key },
      create: { key, nameAr: PERMISSION_LABELS[key] || key, category: key.split('.')[0] },
      update: { nameAr: PERMISSION_LABELS[key] || key },
    });
  }
  console.log(`✔ الصلاحيات: ${ALL_PERMISSIONS.length}`);

  // 2) الأدوار
  for (const r of ROLES) {
    const role = await prisma.role.upsert({
      where: { key: r.key },
      create: { key: r.key, nameAr: r.nameAr, description: r.description, isSystem: true },
      update: { nameAr: r.nameAr, description: r.description },
    });
    const perms = await prisma.permission.findMany({ where: { key: { in: r.permissions } } });
    await prisma.rolePermission.deleteMany({ where: { roleId: role.id } });
    await prisma.rolePermission.createMany({
      data: perms.map((p) => ({ roleId: role.id, permissionId: p.id })),
      skipDuplicates: true,
    });
  }
  console.log(`✔ الأدوار: ${ROLES.length}`);

  // 3) الخدمات
  for (const s of SERVICES) {
    await prisma.service.upsert({ where: { key: s.key }, create: s, update: { nameAr: s.nameAr, description: s.description, iconKey: s.iconKey, sortOrder: s.sortOrder } });
  }
  console.log(`✔ الخدمات: ${SERVICES.length}`);

  // 4) الجهات المصرفية — كلها تبدأ بحالة "الربط غير متاح" بلا استثناء
  for (const b of BANKS) {
    await prisma.bank.upsert({
      where: { code: b.code },
      create: {
        ...b,
        integrationStatus: 'NOT_AVAILABLE',
        requirements:
          'يتطلب: موافقة رسمية من الجهة، عنوان واجهة API، بيانات اعتماد رسمية، توثيق آلية التوقيع/التحقق، واختبار اتصال معتمد.',
        serviceStateNote: 'الربط الرسمي غير متاح حاليًا. تُسجَّل الطلبات وتُتابع داخليًا لحين اعتماد الربط.',
      },
      update: { nameAr: b.nameAr, nameEn: b.nameEn, shortName: b.shortName, sortOrder: b.sortOrder },
    });
  }
  console.log(`✔ الجهات المصرفية: ${BANKS.length} (جميعها: الربط غير متاح)`);

  // 5) ربط الخدمات بالجهات مع عمولة فتح الحساب الافتراضية 300 ريال
  const allBanks = await prisma.bank.findMany();
  const svc = await prisma.service.findMany();
  const svcMap = Object.fromEntries(svc.map((s) => [s.key, s.id]));
  for (const bank of allBanks) {
    // فتح الحسابات متاح تسجيلًا لدى جميع الجهات (تسجيل طلب لا ربط تنفيذي)
    await prisma.bankService.upsert({
      where: { bankId_serviceId: { bankId: bank.id, serviceId: svcMap['open_account'] } },
      create: { bankId: bank.id, serviceId: svcMap['open_account'], enabled: true, feeAmount: 0, commissionAmount: 300, currency: 'YER' },
      update: {},
    });
    // الحوالات: معطّلة حتى يتوفر الربط الرسمي
    await prisma.bankService.upsert({
      where: { bankId_serviceId: { bankId: bank.id, serviceId: svcMap['transfers'] } },
      create: { bankId: bank.id, serviceId: svcMap['transfers'], enabled: false, feeAmount: 0, commissionAmount: 0, currency: 'YER' },
      update: {},
    });
  }
  console.log('✔ ربط الخدمات بالجهات (عمولة فتح الحساب الافتراضية: 300 ريال)');

  // 6) الإعدادات العامة
  for (const [key, value] of Object.entries(SETTINGS)) {
    await prisma.systemSetting.upsert({ where: { key }, create: { key, value }, update: {} });
  }
  console.log(`✔ الإعدادات العامة: ${Object.keys(SETTINGS).length}`);

  // 7) حساب مالك النظام
  const existingOwner = await prisma.user.findFirst({ where: { role: { key: 'OWNER' } } });
  if (existingOwner) {
    console.log(`✔ حساب مالك النظام موجود مسبقًا: ${existingOwner.username}`);
  } else {
    const password = config.owner.password && config.owner.password.length >= 8
      ? config.owner.password
      : `Sb-${crypto.randomBytes(6).toString('base64url')}9Aa`;
    const ownerRole = await prisma.role.findUnique({ where: { key: 'OWNER' } });
    await prisma.user.create({
      data: {
        username: config.owner.username,
        fullName: config.owner.fullName,
        phone: config.owner.phone || null,
        roleId: ownerRole.id,
        passwordHash: await bcrypt.hash(password, 12),
        status: 'ACTIVE',
        mustChangePassword: true,
      },
    });
    console.log('\n════════════════════════════════════════════════');
    console.log('  حساب مالك النظام أُنشئ بنجاح');
    console.log(`  اسم المستخدم : ${config.owner.username}`);
    console.log(`  كلمة المرور  : ${password}`);
    console.log('  ⚠️ غيّر كلمة المرور فورًا بعد أول دخول.');
    console.log('════════════════════════════════════════════════\n');
  }

  console.log('\n✅ اكتملت التهيئة.\n');
}

main()
  .catch((e) => {
    console.error('✖ فشلت التهيئة:', e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
