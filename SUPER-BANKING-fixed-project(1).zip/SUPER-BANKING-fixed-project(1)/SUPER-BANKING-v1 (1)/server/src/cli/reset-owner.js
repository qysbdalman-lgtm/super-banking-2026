/**
 * إعادة تعيين كلمة مرور مالك النظام إلى قيمة معروفة (للتهيئة الأولى أو الاستعادة).
 * التشغيل: node src/cli/reset-owner.js [كلمة المرور]
 */
require('dotenv').config();
const bcrypt = require('bcryptjs');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const username = process.env.OWNER_USERNAME || 'owner';
  const password = process.argv[2] || process.env.OWNER_PASSWORD || 'Owner12345';
  const role = await prisma.role.findUnique({ where: { key: 'OWNER' } });
  const hash = await bcrypt.hash(password, 12);
  const user = await prisma.user.upsert({
    where: { username },
    update: { passwordHash: hash, status: 'ACTIVE', failedAttempts: 0, lockedUntil: null, roleId: role.id },
    create: {
      username, fullName: process.env.OWNER_FULL_NAME || 'عبدالمانع عبدالرحمن قيس',
      phone: process.env.OWNER_PHONE || '777762996', passwordHash: hash, roleId: role.id,
      status: 'ACTIVE', mustChangePassword: false,
    },
  });
  await prisma.session.updateMany({ where: { userId: user.id }, data: { revokedAt: new Date() } });
  console.log(`✅ تم ضبط حساب مالك النظام: ${user.username} — كلمة المرور: ${password}`);
}
main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
