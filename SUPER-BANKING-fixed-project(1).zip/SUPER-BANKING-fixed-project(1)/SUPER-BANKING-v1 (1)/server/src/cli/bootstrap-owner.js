require('dotenv').config();
const bcrypt = require('bcryptjs');
const { prisma } = require('../db');
const config = require('../config');

/**
 * إنشاء حساب مالك النظام الأول (bootstrap).
 * لا توجد أي كلمة مرور ثابتة داخل الكود: كل القيم تُقرأ من متغيرات البيئة.
 *
 *   OWNER_USERNAME=owner OWNER_PHONE=777762996 OWNER_PASSWORD='...' \
 *   node src/cli/bootstrap-owner.js
 *
 * لا يعمل السكربت إلا إذا لم يكن هناك مالك نظام بعد، أو عند تمرير --reset لتغيير كلمة مروره.
 */
(async () => {
  const username = config.owner.username;
  const phone = config.owner.phone || null;
  const fullName = config.owner.fullName;
  const password = config.owner.password;
  const reset = process.argv.includes('--reset');

  if (!password || password.length < 10) {
    console.error('\n✖ يجب تمرير OWNER_PASSWORD بطول 10 أحرف على الأقل عبر متغيرات البيئة.\n');
    process.exit(1);
  }

  const ownerRole = await prisma.role.findUnique({ where: { key: 'OWNER' } });
  if (!ownerRole) {
    console.error('\n✖ دور OWNER غير موجود. نفّذ أولًا: node src/cli/seed.js\n');
    process.exit(1);
  }

  const existing = await prisma.user.findFirst({ where: { role: { key: 'OWNER' } } });
  if (existing && !reset) {
    console.log(`\nℹ يوجد مالك نظام بالفعل: ${existing.username} — لم يتم أي تغيير. (استخدم --reset لتحديث كلمة المرور)\n`);
    process.exit(0);
  }

  const passwordHash = await bcrypt.hash(password, 12);

  if (existing) {
    await prisma.user.update({
      where: { id: existing.id },
      data: { passwordHash, status: 'ACTIVE', mustChangePassword: false, failedAttempts: 0, lockedUntil: null },
    });
    console.log(`\n✔ تم تحديث كلمة مرور مالك النظام: ${existing.username}\n`);
  } else {
    const u = await prisma.user.create({
      data: {
        username,
        phone,
        fullName,
        roleId: ownerRole.id,
        passwordHash,
        status: 'ACTIVE',
        mustChangePassword: true,
      },
    });
    console.log(`\n✔ تم إنشاء مالك النظام: ${u.username} (${u.fullName})\n  غيّر كلمة المرور بعد أول تسجيل دخول.\n`);
  }

  await prisma.$disconnect();
})().catch(async (e) => {
  console.error('\n✖ فشل إنشاء مالك النظام:', e.message, '\n');
  await prisma.$disconnect();
  process.exit(1);
});
