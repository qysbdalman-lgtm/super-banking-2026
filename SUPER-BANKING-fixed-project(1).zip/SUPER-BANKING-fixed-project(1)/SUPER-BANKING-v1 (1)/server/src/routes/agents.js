const express = require('express');
const bcrypt = require('bcryptjs');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission, can } = require('../middleware/rbac');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler, HttpError } = require('../middleware/error');
const { audit } = require('../services/audit');
const { notifyUsers, adminUserIds } = require('../services/notify');
const { nextReference } = require('../utils/reference');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

const AGENT_STATUS_LABEL = {
  NEW: 'طلب جديد',
  UNDER_REVIEW: 'قيد المراجعة',
  NEEDS_INFO: 'مطلوب استكمال بيانات',
  APPROVED: 'مقبول',
  REJECTED: 'مرفوض',
  SUSPENDED: 'موقوف مؤقتًا',
  CANCELLED: 'ملغى',
};

const maskId = (id) => (id ? `${String(id).slice(0, 3)}****${String(id).slice(-2)}` : null);

/** الوكيل يرى ملفه فقط؛ ومن لا يملك عرض الجميع يُقيَّد بنطاق فارغ */
function agentScope(user) {
  if (user.roleKey === 'AGENT_GOLD' || user.roleKey === 'AGENT_SILVER') return { id: user.agentId ?? -1 };
  if (!can(user, P.AGENTS_VIEW_ALL)) return { id: -1 };
  return {};
}

router.get(
  '/',
  requirePermission(P.AGENTS_VIEW),
  asyncHandler(async (req, res) => {
    const { q, status, type, governorate, district, page = 1, pageSize = 25 } = req.query;
    const where = { ...agentScope(req.user) };
    if (status) where.status = status;
    if (type) where.type = type;
    if (governorate) where.governorate = governorate;
    if (district) where.district = district;
    if (q) {
      where.OR = [
        { fullName4: { contains: q, mode: 'insensitive' } },
        { code: { contains: q, mode: 'insensitive' } },
        { phone: { contains: q } },
        { businessName: { contains: q, mode: 'insensitive' } },
      ];
    }
    const take = Math.min(Number(pageSize), 100);
    const skip = (Math.max(Number(page), 1) - 1) * take;
    const sensitive = can(req.user, P.CUSTOMERS_VIEW_SENSITIVE);
    const [items, total] = await Promise.all([
      prisma.agent.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take,
        include: {
          services: true,
          banks: { include: { bank: { select: { id: true, nameAr: true, integrationStatus: true } } } },
          user: { select: { id: true, username: true, status: true } },
        },
      }),
      prisma.agent.count({ where }),
    ]);
    res.json({
      items: items.map((a) => ({
        id: a.id,
        code: a.code,
        contractNo: a.contractNo,
        fullName4: a.fullName4,
        nationalId: sensitive ? a.nationalId : maskId(a.nationalId),
        phone: a.phone,
        whatsapp: a.whatsapp,
        governorate: a.governorate,
        district: a.district,
        area: a.area,
        businessName: a.businessName,
        businessType: a.businessType,
        status: a.status,
        statusLabel: AGENT_STATUS_LABEL[a.status],
        type: a.type,
        services: a.services.filter((s) => s.enabled).map((s) => s.serviceKey),
        banks: a.banks.map((b) => b.bank),
        appliedAt: a.appliedAt,
        approvedAt: a.approvedAt,
        lastActivityAt: a.lastActivityAt,
        settlementBalance: Number(a.settlementBalance),
        user: a.user,
      })),
      total,
      page: Number(page),
      pageSize: take,
      statuses: Object.entries(AGENT_STATUS_LABEL).map(([key, label]) => ({ key, label })),
    });
  })
);

/** العقود القريبة من الانتهاء */
router.get(
  '/meta/expiring-contracts',
  requirePermission(P.CONTRACTS_VIEW),
  asyncHandler(async (req, res) => {
    const days = Number(req.query.days || 60);
    const limit = new Date(Date.now() + days * 86400000);
    const rows = await prisma.agentContract.findMany({
      where: { expiresAt: { not: null, lte: limit } },
      orderBy: { expiresAt: 'asc' },
      include: { agent: { select: { id: true, code: true, fullName4: true, phone: true } } },
    });
    res.json(rows);
  })
);

/** طلب الانضمام إلى شبكة الوكلاء */
router.post(
  ['/', '/apply'],
  requirePermission(P.AGENTS_CREATE),
  validate(schemas.agentApply),
  asyncHandler(async (req, res) => {
    const d = req.body;
    const dup = await prisma.agent.findFirst({ where: { OR: [{ nationalId: d.nationalId }, { phone: d.phone }] } });
    if (dup) {
      throw new HttpError(409, `يوجد طلب سابق بنفس رقم البطاقة أو الهاتف (رقم الوكيل: ${dup.code}).`);
    }
    const code = await nextReference('AGENT');
    const created = await prisma.agent.create({
      data: {
        code,
        fullName4: d.fullName4,
        nationalId: d.nationalId,
        phone: d.phone,
        whatsapp: d.whatsapp || null,
        governorate: d.governorate,
        district: d.district,
        area: d.area || null,
        address: d.address || null,
        businessName: d.businessName || null,
        businessType: d.businessType || null,
        type: d.type || 'SILVER',
        guarantorName: d.guarantorName || null,
        guarantorPhone: d.guarantorPhone || null,
        guarantorId: d.guarantorId || null,
        notes: d.notes || null,
        status: 'NEW',
        createdById: req.user.id,
      },
    });
    await audit(req, { action: 'create_agent', entityType: 'Agent', entityId: created.id, after: { code } });
    await notifyUsers(await adminUserIds(), {
      title: 'طلب انضمام وكيل جديد',
      body: `تم استلام طلب انضمام للوكيل ${d.fullName4} — الرقم ${code}.`,
      type: 'agent_new',
      iconKey: 'user-plus',
      entityType: 'Agent',
      entityId: created.id,
    });
    res.status(201).json({
      ok: true,
      id: created.id,
      code,
      status: 'NEW',
      statusLabel: AGENT_STATUS_LABEL.NEW,
      message: 'تم استلام طلب الانضمام وسيتم مراجعته من الإدارة.',
    });
  })
);

router.get(
  '/:id',
  requirePermission(P.AGENTS_VIEW),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const scope = agentScope(req.user);
    if (scope.id !== undefined && scope.id !== id) throw new HttpError(403, 'لا تملك صلاحية عرض بيانات هذا الوكيل.');
    const a = await prisma.agent.findUnique({
      where: { id },
      include: {
        services: true,
        banks: { include: { bank: true } },
        violations: { orderBy: { createdAt: 'desc' } },
        contracts: { orderBy: { createdAt: 'desc' } },
        user: { select: { id: true, username: true, status: true, lastLoginAt: true } },
      },
    });
    if (!a) throw new HttpError(404, 'الوكيل غير موجود.');
    const sensitive = can(req.user, P.CUSTOMERS_VIEW_SENSITIVE);
    res.json({
      ...a,
      nationalId: sensitive ? a.nationalId : maskId(a.nationalId),
      statusLabel: AGENT_STATUS_LABEL[a.status],
      settlementBalance: Number(a.settlementBalance),
    });
  })
);

router.get(
  '/:id/operations',
  requirePermission(P.AGENTS_VIEW),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const scope = agentScope(req.user);
    if (scope.id !== undefined && scope.id !== id) throw new HttpError(403, 'غير مصرح.');
    const [requests, transfers, commissions] = await Promise.all([
      prisma.accountRequest.findMany({
        where: { agentId: id },
        orderBy: { createdAt: 'desc' },
        take: 50,
        select: { id: true, reference: true, status: true, createdAt: true, bank: { select: { nameAr: true } } },
      }),
      prisma.transfer.findMany({
        where: { agentId: id },
        orderBy: { createdAt: 'desc' },
        take: 50,
        select: { id: true, reference: true, status: true, amount: true, currency: true, createdAt: true, type: true },
      }),
      prisma.commissionEntry.findMany({ where: { agentId: id }, orderBy: { createdAt: 'desc' }, take: 50 }),
    ]);
    res.json({
      requests,
      transfers: transfers.map((t) => ({ ...t, amount: Number(t.amount) })),
      commissions: commissions.map((c) => ({ ...c, amount: Number(c.amount) })),
    });
  })
);

/** مراجعة طلب وكيل: اعتماد/رفض/استكمال بيانات/إيقاف/إعادة تفعيل/إلغاء */
router.post(
  '/:id/review',
  requirePermission(P.AGENTS_REVIEW, P.AGENTS_SUSPEND),
  validate(schemas.agentReview),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const { action, type, services, banks, reason } = req.body;
    const agent = await prisma.agent.findUnique({ where: { id } });
    if (!agent) throw new HttpError(404, 'الوكيل غير موجود.');

    const map = {
      APPROVE: 'APPROVED',
      REJECT: 'REJECTED',
      NEEDS_INFO: 'NEEDS_INFO',
      SUSPEND: 'SUSPENDED',
      REACTIVATE: 'APPROVED',
      CANCEL: 'CANCELLED',
    };
    const newStatus = map[action];
    if (['REJECT', 'SUSPEND', 'NEEDS_INFO'].includes(action) && !reason) {
      throw new HttpError(400, 'يجب توضيح السبب لهذا الإجراء.');
    }
    // لا يُعتمد الوكيل دون تحديد الخدمات المصرح بها
    if (action === 'APPROVE' && !(services && services.length)) {
      throw new HttpError(400, 'حدد الخدمات المعتمدة قبل اعتماد الوكيل.');
    }

    const data = { status: newStatus };
    if (action === 'APPROVE') {
      data.approvedAt = new Date();
      data.approvedById = req.user.id;
      data.rejectReason = null;
      if (type) data.type = type;
    }
    if (['REJECT', 'SUSPEND'].includes(action)) data.rejectReason = reason;

    const updated = await prisma.agent.update({ where: { id }, data });

    if (action === 'APPROVE') {
      if (can(req.user, P.AGENTS_SET_SERVICES)) {
        await prisma.agentService.deleteMany({ where: { agentId: id } });
        await prisma.agentService.createMany({
          data: services.map((key) => ({
            agentId: id,
            serviceKey: key,
            enabled: true,
            approvedById: req.user.id,
            approvedAt: new Date(),
          })),
          skipDuplicates: true,
        });
      }
      if (banks && can(req.user, P.BANKS_MANAGE)) {
        await prisma.agentBank.deleteMany({ where: { agentId: id } });
        if (banks.length) await prisma.agentBank.createMany({ data: banks.map((bankId) => ({ agentId: id, bankId })) });
      }
      // لا يُنشأ حساب دخول للوكيل تلقائيًا: يُنشئه مالك النظام/المدير صراحةً من إدارة المستخدمين ويربطه بملف الوكيل.
    }

    if (['SUSPEND', 'REJECT', 'CANCEL'].includes(action) && agent.userId) {
      await prisma.user.update({ where: { id: agent.userId }, data: { status: 'SUSPENDED' } });
      await prisma.session.updateMany({ where: { userId: agent.userId }, data: { revokedAt: new Date() } });
    }
    if (action === 'REACTIVATE' && agent.userId) {
      await prisma.user.update({ where: { id: agent.userId }, data: { status: 'ACTIVE' } });
    }

    await audit(req, {
      action: `agent_${action.toLowerCase()}`,
      entityType: 'Agent',
      entityId: id,
      before: { status: agent.status, type: agent.type },
      after: { status: updated.status, type: updated.type, reason: reason || null },
    });

    if (agent.userId) {
      const titles = {
        APPROVE: ['تم اعتماد الوكالة', 'تم اعتماد طلب انضمامك إلى شبكة الوكلاء.'],
        REJECT: ['تم رفض طلب الوكالة', `سبب الرفض: ${reason || 'غير محدد'}`],
        SUSPEND: ['تم إيقاف الوكالة', `سبب الإيقاف: ${reason || 'غير محدد'}`],
        REACTIVATE: ['تمت إعادة تفعيل الوكالة', 'تمت إعادة تفعيل حسابك.'],
        NEEDS_INFO: ['مطلوب استكمال بيانات', reason || 'يرجى استكمال البيانات المطلوبة.'],
        CANCEL: ['تم إلغاء الطلب', reason || 'تم إلغاء طلب الوكالة.'],
      };
      const [title, body] = titles[action] || ['تحديث حالة الوكالة', 'تم تحديث حالة ملفك.'];
      await notifyUsers([agent.userId], {
        title,
        body,
        type: 'agent_status',
        iconKey: 'user-check',
        entityType: 'Agent',
        entityId: id,
      });
    }

    res.json({
      ok: true,
      status: updated.status,
      statusLabel: AGENT_STATUS_LABEL[updated.status],
      message: 'تم تنفيذ الإجراء.',
    });
  })
);

router.put(
  '/:id/services',
  requirePermission(P.AGENTS_SET_SERVICES),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const services = Array.isArray(req.body.services) ? req.body.services : [];
    await prisma.agentService.deleteMany({ where: { agentId: id } });
    if (services.length) {
      await prisma.agentService.createMany({
        data: services.map((key) => ({
          agentId: id,
          serviceKey: key,
          enabled: true,
          approvedById: req.user.id,
          approvedAt: new Date(),
        })),
        skipDuplicates: true,
      });
    }
    await audit(req, { action: 'set_agent_services', entityType: 'Agent', entityId: id, after: { services } });
    res.json({ ok: true, message: 'تم تحديث الخدمات المصرح بها للوكيل.' });
  })
);

router.put(
  '/:id/banks',
  requirePermission(P.BANKS_MANAGE, P.AGENTS_SET_SERVICES),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const banks = Array.isArray(req.body.banks) ? req.body.banks.map(Number) : [];
    await prisma.agentBank.deleteMany({ where: { agentId: id } });
    if (banks.length) await prisma.agentBank.createMany({ data: banks.map((bankId) => ({ agentId: id, bankId })) });
    await audit(req, { action: 'set_agent_banks', entityType: 'Agent', entityId: id, after: { banks } });
    res.json({ ok: true, message: 'تم تحديث البنوك المرتبطة بالوكيل.' });
  })
);

router.put(
  '/:id/type',
  requirePermission(P.AGENTS_SET_TYPE),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const type = req.body.type === 'GOLD' ? 'GOLD' : 'SILVER';
    const agent = await prisma.agent.update({ where: { id }, data: { type } });
    if (agent.userId) {
      const role = await prisma.role.findUnique({ where: { key: type === 'GOLD' ? 'AGENT_GOLD' : 'AGENT_SILVER' } });
      await prisma.user.update({ where: { id: agent.userId }, data: { roleId: role.id } });
    }
    await audit(req, { action: 'set_agent_type', entityType: 'Agent', entityId: id, after: { type } });
    res.json({ ok: true, type, message: 'تم تحديث نوع الوكالة.' });
  })
);

router.post(
  '/:id/violations',
  requirePermission(P.AGENTS_REVIEW),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    if (!req.body.note) throw new HttpError(400, 'نص الملاحظة مطلوب.');
    const v = await prisma.agentViolation.create({
      data: { agentId: id, note: req.body.note, severity: req.body.severity || 'ملاحظة', createdById: req.user.id },
    });
    await audit(req, { action: 'add_agent_violation', entityType: 'Agent', entityId: id, after: { note: req.body.note } });
    res.status(201).json({ ok: true, id: v.id });
  })
);

router.post(
  '/:id/contracts',
  requirePermission(P.CONTRACTS_MANAGE),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const { contractNo, issuedAt, expiresAt, status, fileId, notes } = req.body;
    const no = contractNo || (await nextReference('CONTRACT'));
    const c = await prisma.agentContract.create({
      data: {
        agentId: id,
        contractNo: no,
        issuedAt: issuedAt ? new Date(issuedAt) : new Date(),
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        status: status || 'سارٍ',
        fileId: fileId || null,
        notes: notes || null,
        createdById: req.user.id,
      },
    });
    await prisma.agent.update({ where: { id }, data: { contractNo: no } });
    await audit(req, { action: 'create_agent_contract', entityType: 'AgentContract', entityId: c.id, after: { no } });
    res.status(201).json({ ok: true, id: c.id, contractNo: no });
  })
);

module.exports = router;
module.exports.AGENT_STATUS_LABEL = AGENT_STATUS_LABEL;
