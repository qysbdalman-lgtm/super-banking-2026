const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const { prisma } = require('../db');
const config = require('../config');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { asyncHandler, HttpError } = require('../middleware/error');
const { audit } = require('../services/audit');
const { sha256, randomToken } = require('../utils/crypto');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxUploadMb * 1024 * 1024, files: 1 },
});

/**
 * فحص المحتوى الحقيقي للملف (magic bytes) وليس الامتداد فقط.
 * يمنع رفع سكربتات أو ملفات تنفيذية مموّهة بامتداد صورة.
 */
function sniff(buf) {
  if (!buf || buf.length < 4) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: 'image/jpeg', ext: '.jpg' };
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return { mime: 'image/png', ext: '.png' };
  if (buf.slice(0, 4).toString('ascii') === '%PDF') return { mime: 'application/pdf', ext: '.pdf' };
  if (buf.slice(0, 4).toString('ascii') === 'RIFF' && buf.slice(8, 12).toString('ascii') === 'WEBP') {
    return { mime: 'image/webp', ext: '.webp' };
  }
  return null;
}

const SAFE_EXT = new Set(['.jpg', '.jpeg', '.png', '.webp', '.pdf']);
const DOC_TYPES = ['id_front', 'id_back', 'military_id', 'supporting', 'contract', 'other'];

function privateDir() {
  const dir = path.join(config.privateStorageDir, new Date().toISOString().slice(0, 7));
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

/** حفظ المستند في تخزين خاص خارج أي مجلد عام + ربطه بالطلب */
async function storeAndLink(req, { requestId, docType }) {
  if (!req.file) throw new HttpError(400, 'لم يتم إرفاق أي ملف.');
  const ext = path.extname(req.file.originalname || '').toLowerCase();
  if (!SAFE_EXT.has(ext)) throw new HttpError(400, 'امتداد الملف غير مسموح. المسموح: صور JPG/PNG/WEBP أو PDF.');
  const real = sniff(req.file.buffer);
  if (!real) throw new HttpError(400, 'محتوى الملف غير معروف أو غير مطابق لصورة/PDF صالح. تم رفض الملف.');
  if (['.jpg', '.jpeg'].includes(ext) && real.mime !== 'image/jpeg') throw new HttpError(400, 'الملف لا يطابق امتداده.');
  if (ext === '.png' && real.mime !== 'image/png') throw new HttpError(400, 'الملف لا يطابق امتداده.');
  if (ext === '.pdf' && real.mime !== 'application/pdf') throw new HttpError(400, 'الملف لا يطابق امتداده.');
  if (ext === '.webp' && real.mime !== 'image/webp') throw new HttpError(400, 'الملف لا يطابق امتداده.');

  const name = `${Date.now()}-${randomToken(8)}${real.ext}`;
  const dir = privateDir();
  fs.writeFileSync(path.join(dir, name), req.file.buffer, { mode: 0o600 });

  const doc = await prisma.documentFile.create({
    data: {
      storageKey: path.relative(config.privateStorageDir, path.join(dir, name)),
      originalName: req.file.originalname || name,
      mimeType: real.mime,
      size: req.file.size,
      sha256: sha256(req.file.buffer),
      isPrivate: true,
      uploadedById: req.user.id,
    },
  });

  if (requestId && docType) {
    if (!DOC_TYPES.includes(docType)) throw new HttpError(400, 'نوع المستند غير معروف.');
    await prisma.accountRequestDocument.upsert({
      where: { requestId_docType: { requestId: Number(requestId), docType } },
      create: { requestId: Number(requestId), docType, fileId: doc.id, uploadedById: req.user.id },
      update: { fileId: doc.id, uploadedById: req.user.id },
    });
  }

  await audit(req, {
    action: 'upload_document', entityType: 'DocumentFile', entityId: doc.id,
    after: { name: doc.originalName, size: doc.size, requestId: requestId || null, docType: docType || null },
  });
  return doc;
}

/** رفع مستند (هوية/وثيقة) — تخزين خاص، ولا يوجد أي رابط عام */
router.post(
  '/',
  requirePermission(P.DOCUMENTS_VIEW, P.REQUESTS_CREATE, P.REQUESTS_CHANGE_STATUS),
  upload.single('file'),
  asyncHandler(async (req, res) => {
    const { requestId, docType } = req.body || {};
    if (requestId) {
      const r = await prisma.accountRequest.findUnique({ where: { id: Number(requestId) } });
      if (!r) throw new HttpError(404, 'الطلب غير موجود.');
      if (req.user.agentId && r.agentId !== req.user.agentId) throw new HttpError(403, 'غير مصرح بهذا الطلب.');
    }
    const doc = await storeAndLink(req, { requestId, docType });
    res.status(201).json({
      ok: true, id: doc.id, originalName: doc.originalName, mimeType: doc.mimeType, size: doc.size,
      message: 'تم رفع المستند وحفظه في تخزين خاص غير علني.',
    });
  })
);

/** عرض بيانات المستند (بدون محتواه) — الوصول مسجَّل */
router.get(
  '/:id',
  requirePermission(P.DOCUMENTS_VIEW),
  asyncHandler(async (req, res) => {
    const doc = await prisma.documentFile.findUnique({ where: { id: req.params.id } });
    if (!doc) throw new HttpError(404, 'المستند غير موجود.');
    await prisma.documentAccessLog.create({
      data: { fileId: doc.id, userId: req.user.id, userName: req.user.fullName, action: 'view', ip: req.ip },
    });
    res.setHeader('Cache-Control', 'no-store, private');
    res.json({
      id: doc.id, originalName: doc.originalName, mimeType: doc.mimeType,
      size: doc.size, isPrivate: doc.isPrivate, createdAt: doc.createdAt,
    });
  })
);

/** تنزيل المستند — يحتاج صلاحية صريحة، ويُسجَّل في سجل الاطلاع */
router.get(
  '/:id/download',
  requirePermission(P.DOCUMENTS_DOWNLOAD, P.DOCUMENTS_VIEW),
  asyncHandler(async (req, res) => {
    const doc = await prisma.documentFile.findUnique({ where: { id: req.params.id } });
    if (!doc) throw new HttpError(404, 'المستند غير موجود.');
    const full = path.resolve(config.privateStorageDir, doc.storageKey);
    if (!full.startsWith(path.resolve(config.privateStorageDir))) throw new HttpError(400, 'مسار غير صالح.');
    if (!fs.existsSync(full)) throw new HttpError(410, 'الملف غير متوفر في التخزين.');

    await prisma.documentAccessLog.create({
      data: { fileId: doc.id, userId: req.user.id, userName: req.user.fullName, action: 'download', ip: req.ip },
    });
    await audit(req, { action: 'download_document', entityType: 'DocumentFile', entityId: doc.id });

    res.setHeader('Content-Type', doc.mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(doc.originalName)}"`);
    res.setHeader('Cache-Control', 'no-store, private');
    fs.createReadStream(full).pipe(res);
  })
);

module.exports = router;
module.exports.DOC_TYPES = DOC_TYPES;
