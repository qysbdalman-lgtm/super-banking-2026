const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission, can } = require('../middleware/rbac');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler, HttpError } = require('../middleware/error');
const { audit } = require('../services/audit');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

const maskId = (id) => (id ? `${String(id).slice(0, 3)}****${String(id).slice(-2)}` : null);

router.get(
  '/',
  requirePermission(P.CUSTOMERS_VIEW),
  asyncHandler(async (req, res) => {
    const { q, bankId, agentId, status, from, to, page = 1, pageSize = 25 } = req.query;
    const where = {};
    if (req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER') {
      where.agentId = req.user.agentId ?? -1;
    } else if (agentId) {
      where.agentId = Number(agentId);
    }
    if (bankId) where.bankId = Number(bankId);
    if (status) where.status = status;
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt.gte = new Date(from);
      if (to) where.createdAt.lte = new Date(`${to}T23:59:59`);
    }
    if (q) {
      where.OR = [
        { fullName4: { contains: q, mode: 'insensitive' } },
        { phone: { contains: q } },
        { altPhone: { contains: q } },
        { requests: { some: { reference: { contains: q, mode: 'insensitive' } } } },
      ];
      if (can(req.user, P.CUSTOMERS_VIEW_SENSITIVE)) where.OR.push({ nationalId: { contains: q } });
    }
    const take = Math.min(Number(pageSize), 100);
    const skip = (Math.max(Number(page), 1) - 1) * take;
    const sensitive = can(req.user, P.CUSTOMERS_VIEW_SENSITIVE);
    const [items, total] = await Promise.all([
      prisma.customer.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take,
        include: {
          bank: { select: { id: true, nameAr: true } },
          agent: { select: { id: true, code: true, fullName4: true } },
          _count: { select: { requests: true } },
        },
      }),
      prisma.customer.count({ where }),
    ]);
    res.json({
      items: items.map((c) => ({
        id: c.id,
        fullName4: c.fullName4,
        nationalId: sensitive ? c.nationalId : maskId(c.nationalId),
        phone: c.phone,
        governorate: c.governorate,
        district: c.district,
        bank: c.bank,
        agent: c.agent,
        status: c.status,
        requestsCount: c._count.requests,
        createdAt: c.createdAt,
      })),
      total,
      page: Number(page),
      pageSize: take,
      sensitiveMasked: !sensitive,
    });
  })
);

/** كشف الطلبات المتكررة */
router.get(
  '/meta/duplicate-requests',
  requirePermission(P.CUSTOMERS_VIEW),
  asyncHandler(async (req, res) => {
    const rows = await prisma.$queryRaw`
      SELECT "customerId", "bankId", COUNT(*)::int AS cnt
      FROM "AccountRequest"
      WHERE status NOT IN ('REJECTED','CANCELLED')
      GROUP BY "customerId", "bankId"
      HAVING COUNT(*) > 1
      ORDER BY cnt DESC LIMIT 100
    `;
    res.json(rows.map((r) => ({ customerId: Number(r.customerId), bankId: Number(r.bankId), count: Number(r.cnt) })));
  })
);

router.get(
  '/:id',
  requirePermission(P.CUSTOMERS_VIEW),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const c = await prisma.customer.findUnique({
      where: { id },
      include: {
        bank: true,
        agent: { select: { id: true, code: true, fullName4: true, phone: true } },
        requests: { orderBy: { createdAt: 'desc' }, include: { bank: { select: { id: true, nameAr: true } } } },
      },
    });
    if (!c) throw new HttpError(404, 'العميل غير موجود.');
    if ((req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER') && c.agentId !== req.user.agentId) {
      throw new HttpError(404, 'العميل غير موجود.');
    }
    const sensitive = can(req.user, P.CUSTOMERS_VIEW_SENSITIVE);
    res.json({ ...c, nationalId: sensitive ? c.nationalId : maskId(c.nationalId), sensitiveMasked: !sensitive });
  })
);

router.post(
  '/',
  requirePermission(P.CUSTOMERS_CREATE),
  validate(schemas.customer),
  asyncHandler(async (req, res) => {
    const d = req.body;
    const existing = await prisma.customer.findFirst({ where: { OR: [{ nationalId: d.nationalId }, { phone: d.phone }] } });
    if (existing) {
      return res.status(409).json({
        error: 'العميل مسجل مسبقًا (تكرار محتمل).',
        duplicated: true,
        customer: { id: existing.id, fullName4: existing.fullName4, phone: existing.phone },
      });
    }
    const agentId =
      req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER' ? req.user.agentId : d.agentId || null;

    const created = await prisma.customer.create({
      data: {
        fullName4: d.fullName4,
        nationalId: d.nationalId,
        phone: d.phone,
        altPhone: d.altPhone || null,
        dob: d.dob ? new Date(d.dob) : null,
        gender: d.gender || null,
        governorate: d.governorate,
        district: d.district,
        area: d.area || null,
        address: d.address || null,
        accountType: d.accountType || null,
        bankId: d.bankId || null,
        agentId,
        createdById: req.user.id,
      },
    });
    if (agentId) await prisma.agent.update({ where: { id: agentId }, data: { lastActivityAt: new Date() } });
    await audit(req, {
      action: 'create_customer',
      entityType: 'Customer',
      entityId: created.id,
      after: { fullName4: d.fullName4, phone: d.phone },
    });
    res.status(201).json({ ok: true, id: created.id, message: 'تم تسجيل العميل.' });
  })
);

router.patch(
  '/:id',
  requirePermission(P.CUSTOMERS_UPDATE),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const before = await prisma.customer.findUnique({ where: { id } });
    if (!before) throw new HttpError(404, 'العميل غير موجود.');
    if ((req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER') && before.agentId !== req.user.agentId) {
      throw new HttpError(403, 'لا تملك صلاحية تعديل بيانات هذا العميل.');
    }
    if (!req.body.reason) throw new HttpError(400, 'يجب تسجيل سبب التعديل.');
    const allowed = ['fullName4', 'phone', 'altPhone', 'governorate', 'district', 'area', 'address', 'accountType', 'gender'];
    const data = {};
    for (const k of allowed) if (req.body[k] !== undefined) data[k] = req.body[k];
    if (req.body.nationalId && can(req.user, P.CUSTOMERS_VIEW_SENSITIVE)) data.nationalId = req.body.nationalId;
    const updated = await prisma.customer.update({ where: { id }, data });
    await audit(req, {
      action: 'update_customer',
      entityType: 'Customer',
      entityId: id,
      before: { phone: before.phone, district: before.district },
      after: { ...data, reason: req.body.reason },
    });
    res.json({ ok: true, message: 'تم تحديث بيانات العميل وتسجيل سبب التعديل.', customer: updated });
  })
);

module.exports = router;
