const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/error');
const { audit } = require('../services/audit');
const { notifyUsers } = require('../services/notify');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

router.get(
  '/',
  requirePermission(P.CIRCULARS_VIEW),
  asyncHandler(async (req, res) => {
    const where = {};
    if (req.query.all !== 'true') where.isActive = true;
    if (req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER') {
      where.audience = { in: ['all', 'agents'] };
    }
    const rows = await prisma.circular.findMany({ where, orderBy: { publishedAt: 'desc' }, take: 100 });
    res.json(rows);
  })
);

router.post(
  '/',
  requirePermission(P.CIRCULARS_MANAGE),
  validate(schemas.circular),
  asyncHandler(async (req, res) => {
    const { title, body, audience, isActive } = req.body;
    const c = await prisma.circular.create({
      data: { title, body, audience: audience || 'all', isActive: isActive ?? true, publishedById: req.user.id },
    });
    await audit(req, { action: 'create_circular', entityType: 'Circular', entityId: c.id, after: { title } });

    const roleFilter =
      audience === 'agents'
        ? { role: { key: { in: ['AGENT_GOLD', 'AGENT_SILVER'] } } }
        : audience === 'staff'
        ? { role: { key: { notIn: ['AGENT_GOLD', 'AGENT_SILVER', 'CUSTOMER'] } } }
        : {};
    const users = await prisma.user.findMany({ where: { status: 'ACTIVE', ...roleFilter }, select: { id: true } });
    await notifyUsers(users.map((u) => u.id), {
      title: 'تعميم إداري جديد',
      body: title,
      type: 'circular',
      iconKey: 'megaphone',
      entityType: 'Circular',
      entityId: c.id,
    });

    res.status(201).json({ ok: true, id: c.id, message: 'تم نشر التعميم وإشعار المستخدمين.' });
  })
);

router.patch(
  '/:id',
  requirePermission(P.CIRCULARS_MANAGE),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const { title, body, audience, isActive } = req.body;
    await prisma.circular.update({
      where: { id },
      data: {
        ...(title !== undefined ? { title } : {}),
        ...(body !== undefined ? { body } : {}),
        ...(audience !== undefined ? { audience } : {}),
        ...(isActive !== undefined ? { isActive } : {}),
      },
    });
    await audit(req, { action: 'update_circular', entityType: 'Circular', entityId: id, after: req.body });
    res.json({ ok: true });
  })
);

module.exports = router;
