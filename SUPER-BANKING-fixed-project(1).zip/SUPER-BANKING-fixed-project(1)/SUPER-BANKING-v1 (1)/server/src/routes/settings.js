const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/error');
const { audit } = require('../services/audit');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

const PUBLIC_KEYS = new Set([
  'org_name', 'org_name_en', 'slogan', 'tagline', 'intro', 'address', 'phones',
  'currency', 'account_commission_default', 'support_hours', 'app_version', 'maintenance_mode',
]);

router.get(
  '/',
  requirePermission(P.DASHBOARD_VIEW),
  asyncHandler(async (req, res) => {
    const rows = await prisma.systemSetting.findMany();
    const out = {};
    const isAdmin = (req.user.permissions || []).includes(P.SETTINGS_MANAGE);
    for (const r of rows) {
      if (req.query.all === 'true' && isAdmin) out[r.key] = r.value;
      else if (PUBLIC_KEYS.has(r.key)) out[r.key] = r.value;
    }
    res.json(out);
  })
);

router.put(
  '/:key',
  requirePermission(P.SETTINGS_MANAGE),
  validate(schemas.setting),
  asyncHandler(async (req, res) => {
    const key = req.params.key;
    const before = await prisma.systemSetting.findUnique({ where: { key } });
    await prisma.systemSetting.upsert({
      where: { key },
      create: { key, value: req.body.value, updatedById: req.user.id },
      update: { value: req.body.value, updatedById: req.user.id },
    });
    await audit(req, {
      action: 'update_setting',
      entityType: 'SystemSetting',
      entityId: key,
      before: before ? { value: before.value } : null,
      after: { value: req.body.value },
    });
    res.json({ ok: true, message: 'تم حفظ الإعداد.' });
  })
);

module.exports = router;
