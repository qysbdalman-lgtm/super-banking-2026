const express = require('express');
const { z } = require('zod');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler, HttpError } = require('../middleware/error');
const { audit } = require('../services/audit');
const { encryptSecret, maskSecret } = require('../utils/crypto');
const { STATUS_LABEL, testConnection } = require('../services/bankAdapter');
const config = require('../config');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

/** إخفاء بيانات الاعتماد وعنوان الواجهة عن كل من لا يملك صلاحية إدارة الربط */
function publicBank(b, includeIntegration) {
  const base = {
    id: b.id,
    code: b.code,
    nameAr: b.nameAr,
    shortName: b.shortName,
    logoUrl: b.logoUrl,
    iconKey: b.iconKey,
    description: b.description,
    integrationStatus: b.integrationStatus,
    integrationStatusLabel: STATUS_LABEL[b.integrationStatus],
    contactInfo: b.contactInfo,
    requirements: b.requirements,
    serviceStateNote: b.serviceStateNote,
    sortOrder: b.sortOrder,
    isActive: b.isActive,
    lastTestAt: b.lastTestAt,
    lastError: b.lastError,
    services: (b.services || []).map((s) => ({
      id: s.id,
      key: s.service.key,
      nameAr: s.service.nameAr,
      description: s.service.description,
      iconKey: s.service.iconKey,
      requiresIntegration: s.service.requiresIntegration,
      enabled: s.enabled,
      feeAmount: Number(s.feeAmount),
      commissionAmount: Number(s.commissionAmount),
      currency: s.currency,
    })),
  };
  if (includeIntegration) {
    base.apiBaseUrl = b.apiBaseUrl;
    base.apiAuthType = b.apiAuthType;
    base.credentialsMasked = maskSecret(b.credentialsEnc);
  }
  return base;
}

router.get(
  '/',
  requirePermission(P.BANKS_VIEW),
  asyncHandler(async (req, res) => {
    const banks = await prisma.bank.findMany({
      where: req.query.includeInactive === 'true' ? {} : { isActive: true },
      orderBy: [{ sortOrder: 'asc' }, { id: 'asc' }],
      include: { services: { include: { service: true } } },
    });
    const canSeeIntegration = (req.user.permissions || []).includes(P.BANKS_INTEGRATION_MANAGE);
    res.json(banks.map((b) => publicBank(b, canSeeIntegration)));
  })
);

router.get(
  '/meta/statuses',
  requirePermission(P.BANKS_VIEW),
  (req, res) => res.json(Object.entries(STATUS_LABEL).map(([key, label]) => ({ key, label })))
);

router.get(
  '/:id',
  requirePermission(P.BANKS_VIEW),
  asyncHandler(async (req, res) => {
    const bank = await prisma.bank.findUnique({
      where: { id: Number(req.params.id) },
      include: { services: { include: { service: true } } },
    });
    if (!bank) throw new HttpError(404, 'الجهة غير موجودة.');
    const canSeeIntegration = (req.user.permissions || []).includes(P.BANKS_INTEGRATION_MANAGE);
    res.json(publicBank(bank, canSeeIntegration));
  })
);

router.post(
  '/',
  requirePermission(P.BANKS_MANAGE),
  validate(schemas.bank),
  asyncHandler(async (req, res) => {
    const b = req.body;
    const created = await prisma.bank.create({
      data: {
        code: b.code,
        nameAr: b.nameAr,
        shortName: b.shortName || null,
        logoUrl: b.logoUrl || null,
        iconKey: b.iconKey || 'bank',
        description: b.description || null,
        integrationStatus: b.integrationStatus || 'NOT_AVAILABLE',
        apiBaseUrl: b.apiBaseUrl || null,
        apiAuthType: b.apiAuthType || null,
        credentialsEnc: b.credentials ? encryptSecret(b.credentials, config.jwtSecret) : null,
        contactInfo: b.contactInfo || null,
        requirements: b.requirements || null,
        serviceStateNote: b.serviceStateNote || null,
        sortOrder: b.sortOrder ?? 100,
        isActive: b.isActive ?? true,
      },
    });
    await audit(req, { action: 'create_bank', entityType: 'Bank', entityId: created.id, after: { code: b.code } });
    res.status(201).json({ ok: true, id: created.id, message: 'تمت إضافة الجهة المصرفية.' });
  })
);

router.patch(
  '/:id',
  requirePermission(P.BANKS_MANAGE),
  validate(schemas.bank.partial()),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const before = await prisma.bank.findUnique({ where: { id } });
    if (!before) throw new HttpError(404, 'الجهة غير موجودة.');
    const b = req.body;
    // لا يُسمح بإعلان «مرتبط رسميًا» من الواجهة: الربط يُثبت باختبار اتصال ناجح فعلي
    if (b.integrationStatus === 'CONNECTED') {
      const ok = before.lastTestAt && !before.lastError && before.apiBaseUrl;
      if (!ok) {
        throw new HttpError(
          400,
          'لا يمكن تعيين حالة «مرتبط رسميًا» يدويًا. وثّق عنوان API ونفّذ اختبار اتصال ناجحًا مع الجهة أولًا.'
        );
      }
    }
    const data = { ...b };
    delete data.credentials;
    if (b.credentials !== undefined) {
      data.credentialsEnc = b.credentials ? encryptSecret(b.credentials, config.jwtSecret) : null;
    }
    for (const k of ['shortName', 'logoUrl', 'description', 'apiBaseUrl', 'apiAuthType', 'contactInfo', 'requirements', 'serviceStateNote']) {
      if (data[k] === '') data[k] = null;
    }
    const updated = await prisma.bank.update({ where: { id }, data });
    await audit(req, {
      action: 'update_bank',
      entityType: 'Bank',
      entityId: id,
      before: { integrationStatus: before.integrationStatus, isActive: before.isActive },
      after: { integrationStatus: updated.integrationStatus, isActive: updated.isActive },
    });
    res.json({ ok: true, message: 'تم تحديث بيانات الجهة.' });
  })
);

/** اختبار اتصال — يُسجَّل ناتجه ولا يُدّعى نجاحه دون ربط رسمي */
router.post(
  '/:id/test-connection',
  requirePermission(P.BANKS_INTEGRATION_MANAGE),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const bank = await prisma.bank.findUnique({ where: { id } });
    if (!bank) throw new HttpError(404, 'الجهة غير موجودة.');
    const result = await testConnection(bank);
    await prisma.bank.update({
      where: { id },
      data: { lastTestAt: new Date(), lastError: result.success ? null : result.message },
    });
    await prisma.integrationLog.create({
      data: { bankId: id, operation: 'TEST_CONNECTION', success: result.success, errorMessage: result.success ? null : result.message },
    });
    await audit(req, { action: 'test_bank_connection', entityType: 'Bank', entityId: id, after: result });
    res.json(result);
  })
);

router.get(
  '/:id/integration-logs',
  requirePermission(P.BANKS_INTEGRATION_MANAGE),
  asyncHandler(async (req, res) => {
    const logs = await prisma.integrationLog.findMany({
      where: { bankId: Number(req.params.id) },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    res.json(logs);
  })
);

router.post(
  '/:id/maintenance',
  requirePermission(P.SYSTEM_MAINTENANCE, P.BANKS_MANAGE),
  validate(z.object({ enabled: z.boolean(), note: z.string().optional() })),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const bank = await prisma.bank.findUnique({ where: { id } });
    if (!bank) throw new HttpError(404, 'الجهة غير موجودة.');
    await prisma.bank.update({
      where: { id },
      data: {
        integrationStatus: req.body.enabled
          ? 'MAINTENANCE'
          : bank.integrationStatus === 'MAINTENANCE'
          ? 'NOT_AVAILABLE'
          : bank.integrationStatus,
        serviceStateNote: req.body.note || (req.body.enabled ? 'الخدمة متوقفة مؤقتًا للصيانة.' : null),
      },
    });
    await audit(req, { action: 'toggle_bank_maintenance', entityType: 'Bank', entityId: id, after: req.body });
    res.json({ ok: true, message: req.body.enabled ? 'تم إيقاف الخدمة مؤقتًا.' : 'تمت إعادة تشغيل الخدمة.' });
  })
);

module.exports = router;
