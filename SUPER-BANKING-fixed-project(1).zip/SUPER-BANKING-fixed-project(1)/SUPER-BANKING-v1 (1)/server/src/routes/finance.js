const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission, can } = require('../middleware/rbac');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler, HttpError } = require('../middleware/error');
const { audit } = require('../services/audit');
const { notifyUsers } = require('../services/notify');
const { nextReference } = require('../utils/reference');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

const C_LABEL = { PENDING: 'معلقة', APPROVED: 'معتمدة', PAID: 'مصروفة', CANCELLED: 'ملغاة' };

function scope(user) {
  if (user.roleKey === 'AGENT_GOLD' || user.roleKey === 'AGENT_SILVER') return { agentId: user.agentId ?? -1 };
  return {};
}

router.get(
  '/commissions',
  requirePermission(P.FINANCE_VIEW),
  asyncHandler(async (req, res) => {
    const { agentId, status, bankId, from, to, page = 1, pageSize = 25 } = req.query;
    const where = { ...scope(req.user) };
    if (status) where.status = status;
    if (bankId) where.bankId = Number(bankId);
    if (agentId && !scope(req.user).agentId) where.agentId = Number(agentId);
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt.gte = new Date(from);
      if (to) where.createdAt.lte = new Date(`${to}T23:59:59`);
    }
    const take = Math.min(Number(pageSize), 100);
    const skip = (Math.max(Number(page), 1) - 1) * take;
    const [items, total] = await Promise.all([
      prisma.commissionEntry.findMany({
        where, orderBy: { createdAt: 'desc' }, skip, take,
        include: {
          agent: { select: { id: true, code: true, fullName4: true } },
          request: { select: { id: true, reference: true } },
          transfer: { select: { id: true, reference: true } },
        },
      }),
      prisma.commissionEntry.count({ where }),
    ]);
    res.json({
      items: items.map((c) => ({ ...c, amount: Number(c.amount), statusLabel: C_LABEL[c.status] })),
      total, page: Number(page), pageSize: take,
    });
  })
);

/** كشف حساب الوكيل */
router.get(
  '/agents/:id/statement',
  requirePermission(P.FINANCE_VIEW, P.AGENTS_SETTLEMENTS_VIEW),
  asyncHandler(async (req, res) => {
    const agentId = Number(req.params.id);
    if (scope(req.user).agentId && scope(req.user).agentId !== agentId) throw new HttpError(403, 'غير مصرح.');
    const agent = await prisma.agent.findUnique({ where: { id: agentId } });
    if (!agent) throw new HttpError(404, 'الوكيل غير موجود.');
    const { from, to } = req.query;
    const where = { agentId };
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt.gte = new Date(from);
      if (to) where.createdAt.lte = new Date(`${to}T23:59:59`);
    }
    const entries = await prisma.commissionEntry.findMany({ where, orderBy: { createdAt: 'asc' } });
    const totals = entries.reduce(
      (acc, e) => {
        const amt = Number(e.amount);
        if (e.status === 'PENDING') acc.pending += amt;
        if (e.status === 'APPROVED') acc.approved += amt;
        if (e.status === 'PAID') acc.paid += amt;
        if (e.kind === 'ADJUSTMENT') acc.adjustments += amt;
        return acc;
      },
      { pending: 0, approved: 0, paid: 0, adjustments: 0 }
    );
    res.json({
      agent: { id: agent.id, code: agent.code, fullName4: agent.fullName4, type: agent.type },
      currency: 'YER',
      totals,
      balance: Number(agent.settlementBalance),
      entries: entries.map((e) => ({
        id: e.id, date: e.createdAt, serviceKey: e.serviceKey, kind: e.kind,
        amount: Number(e.amount), status: e.status, statusLabel: C_LABEL[e.status], reason: e.reason,
      })),
      note: 'هذا كشف داخلي لمستحقات الوكيل، وليس بديلًا عن النظام المحاسبي الرسمي للبنك.',
    });
  })
);

/** اعتماد/صرف/إلغاء عمولات */
router.post(
  '/commissions/decision',
  requirePermission(P.COMMISSIONS_APPROVE, P.COMMISSIONS_PAY),
  validate(schemas.commissionDecision),
  asyncHandler(async (req, res) => {
    const { ids, action, reason } = req.body;
    const map = { APPROVE: 'APPROVED', PAY: 'PAID', CANCEL: 'CANCELLED' };
    const newStatus = map[action];
    if (action === 'PAY' && !can(req.user, P.COMMISSIONS_PAY)) throw new HttpError(403, 'تحتاج صلاحية الصرف.');
    if (action === 'APPROVE' && !can(req.user, P.COMMISSIONS_APPROVE)) throw new HttpError(403, 'تحتاج صلاحية الاعتماد.');
    if (action === 'CANCEL' && !reason) throw new HttpError(400, 'يجب ذكر سبب الإلغاء.');

    const rows = await prisma.commissionEntry.findMany({ where: { id: { in: ids } } });
    if (!rows.length) throw new HttpError(404, 'لا توجد قيود مطابقة.');
    if (action === 'PAY' && rows.some((r) => r.status === 'PAID')) {
      throw new HttpError(409, 'هذه القيود مصروفة مسبقًا — لا يُصرف القيد مرتين.');
    }
    if (action === 'PAY' && rows.some((r) => r.status !== 'APPROVED')) {
      throw new HttpError(409, 'لا يمكن صرف قيد لم يُعتمد بعد. اعتمد القيود أولًا.');
    }
    if (action === 'APPROVE' && rows.some((r) => r.status === 'PAID')) {
      throw new HttpError(409, 'قيد مصروف مسبقًا لا يُعاد اعتماده.');
    }

    await prisma.$transaction(async (tx) => {
      for (const r of rows) {
        if (r.status === 'PAID' && action !== 'PAY') continue;
        await tx.commissionEntry.update({
          where: { id: r.id },
          data: {
            status: newStatus,
            approvedById: action === 'APPROVE' ? req.user.id : r.approvedById,
            approvedAt: action === 'APPROVE' ? new Date() : r.approvedAt,
            paidAt: action === 'PAY' ? new Date() : r.paidAt,
            reason: reason || r.reason,
          },
        });
        if (action === 'PAY') {
          await tx.agent.update({ where: { id: r.agentId }, data: { settlementBalance: { increment: r.amount } } });
        }
      }
    });

    await audit(req, {
      action: `commission_${action.toLowerCase()}`, entityType: 'CommissionEntry',
      entityId: ids.join(','), after: { ids, action, reason: reason || null },
    });

    const agentIds = [...new Set(rows.map((r) => r.agentId))];
    const agents = await prisma.agent.findMany({ where: { id: { in: agentIds } }, select: { userId: true } });
    const userIds = agents.map((a) => a.userId).filter(Boolean);
    if (userIds.length) {
      const titles = { APPROVE: 'اعتماد عمولة', PAY: 'صرف عمولة', CANCEL: 'إلغاء عمولة' };
      await notifyUsers(userIds, {
        title: titles[action],
        body: `${action === 'PAY' ? 'تم صرف' : action === 'APPROVE' ? 'تم اعتماد' : 'تم إلغاء'} ${rows.length} قيد عمولة.${reason ? ` السبب: ${reason}` : ''}`,
        type: 'commission_status', iconKey: 'coins',
      });
    }

    res.json({ ok: true, updated: rows.length, status: newStatus, statusLabel: C_LABEL[newStatus], message: 'تم تنفيذ الإجراء على القيود المحددة.' });
  })
);

/** قيد تسوية مستقل — لا تعديل صامت للقيود السابقة */
router.post(
  '/adjustments',
  requirePermission(P.FINANCE_MANAGE),
  asyncHandler(async (req, res) => {
    const { agentId, amount, reason } = req.body;
    if (!agentId || !amount || !reason) throw new HttpError(400, 'الوكيل والمبلغ وسبب التسوية مطلوبة.');
    const entry = await prisma.commissionEntry.create({
      data: {
        agentId: Number(agentId), serviceKey: 'adjustment', kind: 'ADJUSTMENT',
        amount: Number(amount), status: 'APPROVED', reason,
        approvedById: req.user.id, approvedAt: new Date(), createdById: req.user.id,
      },
    });
    await audit(req, {
      action: 'create_adjustment', entityType: 'CommissionEntry', entityId: entry.id,
      after: { agentId, amount, reason },
    });
    res.status(201).json({ ok: true, id: entry.id, message: 'تم تسجيل قيد التسوية مع ذكر السبب.' });
  })
);

/** إنشاء تسوية لفترة */
router.post(
  '/settlements',
  requirePermission(P.SETTLEMENTS_MANAGE),
  validate(schemas.settlement),
  asyncHandler(async (req, res) => {
    const { agentId, periodStart, periodEnd, note, approve } = req.body;
    const agent = await prisma.agent.findUnique({ where: { id: agentId } });
    if (!agent) throw new HttpError(404, 'الوكيل غير موجود.');
    const entries = await prisma.commissionEntry.findMany({
      where: { agentId, createdAt: { gte: new Date(periodStart), lte: new Date(`${periodEnd}T23:59:59`) } },
    });
    const earned = entries.filter((e) => e.status !== 'CANCELLED').reduce((s, e) => s + Number(e.amount), 0);
    const paid = entries.filter((e) => e.status === 'PAID').reduce((s, e) => s + Number(e.amount), 0);
    const reference = await nextReference('SETTLEMENT');
    const s = await prisma.settlement.create({
      data: {
        agentId,
        periodStart: new Date(periodStart),
        periodEnd: new Date(periodEnd),
        openingBalance: Number(agent.settlementBalance),
        totalEarned: earned,
        totalPaid: paid,
        closingBalance: Number(agent.settlementBalance) + earned - paid,
        status: approve ? 'معتمدة' : 'مسودة',
        note: `${reference}${note ? ' — ' + note : ''}`,
        createdById: req.user.id,
        approvedById: approve ? req.user.id : null,
        approvedAt: approve ? new Date() : null,
      },
    });
    await audit(req, { action: 'create_settlement', entityType: 'Settlement', entityId: s.id, after: { agentId, earned, paid } });
    res.status(201).json({ ok: true, id: s.id, reference, closingBalance: Number(s.closingBalance), message: 'تم إنشاء التسوية.' });
  })
);

router.get(
  '/expenses',
  requirePermission(P.FINANCE_VIEW),
  asyncHandler(async (req, res) => {
    const rows = await prisma.expense.findMany({ orderBy: { createdAt: 'desc' }, take: 200 });
    res.json(rows.map((e) => ({ ...e, amount: Number(e.amount) })));
  })
);

router.post(
  '/expenses',
  requirePermission(P.FINANCE_MANAGE),
  asyncHandler(async (req, res) => {
    const { agentId, category, amount, note } = req.body;
    if (!category || !amount) throw new HttpError(400, 'التصنيف والمبلغ مطلوبان.');
    const e = await prisma.expense.create({
      data: { agentId: agentId ? Number(agentId) : null, category, amount: Number(amount), note: note || null, createdById: req.user.id },
    });
    await audit(req, { action: 'create_expense', entityType: 'Expense', entityId: e.id, after: { category, amount } });
    res.status(201).json({ ok: true, id: e.id });
  })
);

/** ملخص مالي */
router.get(
  '/overview',
  requirePermission(P.FINANCE_VIEW),
  asyncHandler(async (req, res) => {
    const sc = scope(req.user);
    const [pending, approved, paid, adjustments] = await Promise.all([
      prisma.commissionEntry.aggregate({ where: { ...sc, status: 'PENDING' }, _sum: { amount: true }, _count: true }),
      prisma.commissionEntry.aggregate({ where: { ...sc, status: 'APPROVED' }, _sum: { amount: true }, _count: true }),
      prisma.commissionEntry.aggregate({ where: { ...sc, status: 'PAID' }, _sum: { amount: true }, _count: true }),
      prisma.commissionEntry.aggregate({ where: { ...sc, kind: 'ADJUSTMENT' }, _sum: { amount: true }, _count: true }),
    ]);
    res.json({
      currency: 'YER',
      pending: { amount: Number(pending._sum.amount || 0), count: pending._count },
      approved: { amount: Number(approved._sum.amount || 0), count: approved._count },
      paid: { amount: Number(paid._sum.amount || 0), count: paid._count },
      adjustments: { amount: Number(adjustments._sum.amount || 0), count: adjustments._count },
      note: 'نظام محاسبي داخلي لمتابعة مستحقات الوكلاء، وليس بديلًا عن النظام المحاسبي الرسمي للبنك.',
    });
  })
);

module.exports = router;
