const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler, HttpError } = require('../middleware/error');
const { audit } = require('../services/audit');
const { notifyUsers } = require('../services/notify');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

router.get(
  '/',
  requirePermission(P.NOTIFICATIONS_VIEW),
  asyncHandler(async (req, res) => {
    const { q, bankId, serviceKey, unread, from, to, page = 1, pageSize = 30 } = req.query;
    const where = { userId: req.user.id };
    if (unread === 'true') where.isRead = false;
    if (bankId) where.bankId = Number(bankId);
    if (serviceKey) where.serviceKey = serviceKey;
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt.gte = new Date(from);
      if (to) where.createdAt.lte = new Date(`${to}T23:59:59`);
    }
    if (q) where.OR = [{ title: { contains: q, mode: 'insensitive' } }, { body: { contains: q, mode: 'insensitive' } }];
    const take = Math.min(Number(pageSize), 100);
    const skip = (Math.max(Number(page), 1) - 1) * take;
    const [items, total, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where, orderBy: { createdAt: 'desc' }, skip, take,
        include: { bank: { select: { id: true, nameAr: true } } },
      }),
      prisma.notification.count({ where }),
      prisma.notification.count({ where: { userId: req.user.id, isRead: false } }),
    ]);
    res.json({ items, total, unreadCount, page: Number(page), pageSize: take });
  })
);

/** شارة الأيقونة: إجمالي غير المقروء + التفصيل بحسب البنك */
router.get(
  '/unread-count',
  requirePermission(P.NOTIFICATIONS_VIEW),
  asyncHandler(async (req, res) => {
    const total = await prisma.notification.count({ where: { userId: req.user.id, isRead: false } });
    const byBank = await prisma.notification.groupBy({
      by: ['bankId'],
      where: { userId: req.user.id, isRead: false, bankId: { not: null } },
      _count: true,
    });
    res.json({ total, byBank: byBank.map((b) => ({ bankId: b.bankId, count: b._count })) });
  })
);

router.patch(
  '/:id/read',
  requirePermission(P.NOTIFICATIONS_VIEW),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const n = await prisma.notification.findUnique({ where: { id } });
    if (!n || n.userId !== req.user.id) throw new HttpError(404, 'الإشعار غير موجود.');
    await prisma.notification.update({ where: { id }, data: { isRead: true, readAt: new Date() } });
    res.json({ ok: true });
  })
);

router.post(
  ['/read-all', '/read'],
  requirePermission(P.NOTIFICATIONS_VIEW),
  asyncHandler(async (req, res) => {
    const r = await prisma.notification.updateMany({
      where: { userId: req.user.id, isRead: false },
      data: { isRead: true, readAt: new Date() },
    });
    res.json({ ok: true, updated: r.count });
  })
);

router.delete(
  '/:id',
  requirePermission(P.NOTIFICATIONS_VIEW),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const n = await prisma.notification.findUnique({ where: { id } });
    if (!n || n.userId !== req.user.id) throw new HttpError(404, 'الإشعار غير موجود.');
    if (n.type === 'security') throw new HttpError(400, 'لا يمكن حذف الإشعارات الأمنية.');
    await prisma.notification.delete({ where: { id } });
    res.json({ ok: true, message: 'تم حذف الإشعار.' });
  })
);

router.post(
  '/send',
  requirePermission(P.NOTIFICATIONS_SEND),
  validate(schemas.notifySend),
  asyncHandler(async (req, res) => {
    const { title, body, type, audience, roleKey, userId, bankId } = req.body;
    let ids = [];
    if (audience === 'user' && userId) ids = [Number(userId)];
    else if (audience === 'role' && roleKey) {
      const rows = await prisma.user.findMany({ where: { status: 'ACTIVE', role: { key: roleKey } }, select: { id: true } });
      ids = rows.map((r) => r.id);
    } else if (audience === 'agents') {
      const rows = await prisma.user.findMany({ where: { status: 'ACTIVE', role: { key: { in: ['AGENT_GOLD', 'AGENT_SILVER'] } } }, select: { id: true } });
      ids = rows.map((r) => r.id);
    } else if (audience === 'staff') {
      const rows = await prisma.user.findMany({
        where: { status: 'ACTIVE', role: { key: { notIn: ['AGENT_GOLD', 'AGENT_SILVER', 'CUSTOMER'] } } },
        select: { id: true },
      });
      ids = rows.map((r) => r.id);
    } else {
      const rows = await prisma.user.findMany({ where: { status: 'ACTIVE' }, select: { id: true } });
      ids = rows.map((r) => r.id);
    }
    const created = await notifyUsers(ids, { title, body, type: type || 'admin', iconKey: 'megaphone', bankId: bankId || null });
    await audit(req, { action: 'send_notification', entityType: 'Notification', after: { title, audience, count: created.length } });
    res.status(201).json({ ok: true, sent: created.length, message: `تم إرسال الإشعار إلى ${created.length} مستخدمًا.` });
  })
);

/** تسجيل اشتراك إشعارات الهاتف — يُفعَّل عند تهيئة مفاتيح Push على الخادم */
router.post(
  '/push-subscribe',
  requirePermission(P.NOTIFICATIONS_VIEW),
  asyncHandler(async (req, res) => {
    const config = require('../config');
    if (!config.push.publicKey) {
      return res.status(503).json({
        error: 'إشعارات الهاتف غير مهيأة بعد. يجب إعداد مفاتيح Push في إعدادات الخادم.',
        pushReady: false,
      });
    }
    await audit(req, { action: 'push_subscribe', entityType: 'User', entityId: req.user.id });
    res.json({ ok: true, message: 'تم تسجيل الاشتراك.' });
  })
);

module.exports = router;
