const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission, can } = require('../middleware/rbac');
const { validate, schemas } = require('../middleware/validate');
const { idempotency } = require('../middleware/idempotency');
const { asyncHandler, HttpError } = require('../middleware/error');
const { audit } = require('../services/audit');
const { notifyUsers, usersWithPermission, adminUserIds } = require('../services/notify');
const { nextReference } = require('../utils/reference');
const { executeOperation, STATUS_LABEL } = require('../services/bankAdapter');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

const T_LABEL = {
  DRAFT: 'مسودة', SUBMITTED: 'تم الإرسال', PENDING: 'قيد الانتظار', PROCESSING: 'قيد المعالجة',
  COMPLETED: 'مكتملة', FAILED: 'فشلت', REJECTED: 'مرفوضة', CANCELLED: 'ملغاة',
};

const money = (t) => ({
  ...t,
  amount: Number(t.amount),
  fees: Number(t.fees),
  commission: Number(t.commission),
  statusLabel: T_LABEL[t.status],
});

function scope(user) {
  if (user.roleKey === 'AGENT_GOLD' || user.roleKey === 'AGENT_SILVER') return { agentId: user.agentId ?? -1 };
  return {};
}

router.get(
  '/',
  requirePermission(P.TRANSFERS_VIEW),
  asyncHandler(async (req, res) => {
    const { q, status, bankId, type, from, to, page = 1, pageSize = 25 } = req.query;
    const where = { ...scope(req.user) };
    if (status) where.status = status;
    if (type) where.type = type;
    if (bankId) where.bankId = Number(bankId);
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt.gte = new Date(from);
      if (to) where.createdAt.lte = new Date(`${to}T23:59:59`);
    }
    if (q) {
      where.OR = [
        { reference: { contains: q, mode: 'insensitive' } },
        { senderName: { contains: q, mode: 'insensitive' } },
        { beneficiaryName: { contains: q, mode: 'insensitive' } },
        { beneficiaryPhone: { contains: q } },
      ];
    }
    const take = Math.min(Number(pageSize), 100);
    const skip = (Math.max(Number(page), 1) - 1) * take;
    const [items, total] = await Promise.all([
      prisma.transfer.findMany({
        where, orderBy: { createdAt: 'desc' }, skip, take,
        include: {
          bank: { select: { id: true, nameAr: true, integrationStatus: true } },
          agent: { select: { id: true, code: true, fullName4: true } },
        },
      }),
      prisma.transfer.count({ where }),
    ]);
    res.json({
      items: items.map((t) => ({ ...money(t), bankStatusLabel: STATUS_LABEL[t.bank.integrationStatus] })),
      total, page: Number(page), pageSize: take,
      statuses: Object.entries(T_LABEL).map(([key, label]) => ({ key, label })),
    });
  })
);

/** البحث عن حوالة برقمها المرجعي */
router.get(
  '/lookup/:reference',
  requirePermission(P.TRANSFERS_VIEW),
  asyncHandler(async (req, res) => {
    const t = await prisma.transfer.findUnique({
      where: { reference: req.params.reference },
      include: { bank: true, agent: { select: { code: true, fullName4: true } } },
    });
    if (!t) throw new HttpError(404, 'لا توجد حوالة بهذا الرقم المرجعي.');
    if ((req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER') && t.agentId !== req.user.agentId) {
      throw new HttpError(403, 'غير مصرح بعرض هذه الحوالة.');
    }
    res.json({ ...money(t), bankStatusLabel: STATUS_LABEL[t.bank.integrationStatus] });
  })
);

router.get(
  '/:id',
  requirePermission(P.TRANSFERS_VIEW),
  asyncHandler(async (req, res) => {
    const t = await prisma.transfer.findUnique({
      where: { id: Number(req.params.id) },
      include: { bank: true, agent: true, integrationLogs: { orderBy: { createdAt: 'desc' }, take: 20 } },
    });
    if (!t) throw new HttpError(404, 'الحوالة غير موجودة.');
    if ((req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER') && t.agentId !== req.user.agentId) {
      throw new HttpError(403, 'غير مصرح.');
    }
    res.json({
      ...money(t),
      bankStatusLabel: STATUS_LABEL[t.bank.integrationStatus],
      integrationReady: t.bank.integrationStatus === 'CONNECTED',
    });
  })
);

/**
 * إنشاء طلب حوالة — محمي بمنع التكرار.
 * ⚠️ لا يُنفَّذ أي تحويل مالي فعلي ما لم يكن الربط الرسمي متاحًا (CONNECTED).
 */
router.post(
  '/',
  requirePermission(P.TRANSFERS_CREATE),
  validate(schemas.transfer),
  idempotency('transfer'),
  asyncHandler(async (req, res) => {
    const d = req.body;
    const bank = await prisma.bank.findUnique({
      where: { id: d.bankId },
      include: { services: { include: { service: true } } },
    });
    if (!bank) throw new HttpError(404, 'الجهة المصرفية غير موجودة.');

    const agentId =
      req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER' ? req.user.agentId : null;

    if (req.user.roleKey === 'AGENT_SILVER' && !can(req.user, P.TRANSFERS_CREATE)) {
      throw new HttpError(403, 'الوكيل الفضي غير مصرح له بالحوالات.');
    }
    if (agentId) {
      const allowed = await prisma.agentService.findFirst({ where: { agentId, serviceKey: 'transfers', enabled: true } });
      if (!allowed) throw new HttpError(403, 'خدمة الحوالات غير مصرح بها لهذا الوكيل.');
    }

    const rule = bank.services.find((s) => s.service.key === 'transfers');
    const fees = rule ? Number(rule.feeAmount) : 0;
    const commission = rule ? Number(rule.commissionAmount) : 0;
    const integrationReady = bank.integrationStatus === 'CONNECTED';

    const reference = await nextReference('TRANSFER');
    const created = await prisma.transfer.create({
      data: {
        reference,
        idempotencyKey: d.idempotencyKey,
        bankId: d.bankId,
        type: d.type,
        senderName: d.senderName,
        senderPhone: d.senderPhone || null,
        beneficiaryName: d.beneficiaryName,
        beneficiaryPhone: d.beneficiaryPhone || null,
        amount: d.amount,
        currency: d.currency || 'YER',
        fees,
        commission,
        status: 'PENDING',
        agentId,
        createdById: req.user.id,
        notes: d.notes || null,
        isTest: !integrationReady,
      },
    });

    let execution = { attempted: false, message: 'لم تُنفَّذ عملية تحويل فعلية.' };
    if (integrationReady) {
      try {
        execution = { attempted: true, ...(await executeOperation(bank, 'transfer.create', d)) };
      } catch (e) {
        execution = { attempted: true, success: false, code: e.code, message: e.message };
        await prisma.integrationLog.create({
          data: { bankId: bank.id, operation: 'TRANSFER_CREATE', success: false, errorMessage: e.message, transferId: created.id },
        });
      }
    }

    await audit(req, {
      action: 'create_transfer', entityType: 'Transfer', entityId: created.id,
      after: { reference, amount: d.amount, bank: bank.nameAr, integrationReady },
    });

    const officers = await usersWithPermission(P.TRANSFERS_PROCESS);
    await notifyUsers(officers.length ? officers : await adminUserIds(), {
      title: integrationReady ? 'حوالة جديدة' : 'طلب حوالة جديد (الربط غير متاح)',
      body: `${d.type === 'OUTGOING' ? 'حوالة صادرة' : 'حوالة واردة'} بمبلغ ${d.amount} ${d.currency || 'YER'} — المرجع ${reference}.`,
      type: 'transfer_new', iconKey: 'send', bankId: bank.id,
      entityType: 'Transfer', entityId: created.id,
    });

    res.status(201).json({
      ok: true,
      id: created.id,
      reference,
      status: created.status,
      statusLabel: T_LABEL[created.status],
      fees, commission, currency: created.currency,
      isTest: created.isTest,
      integrationReady,
      execution,
      warning: integrationReady
        ? 'تم تسجيل الطلب. نتيجة التنفيذ الفعلي تعتمد على استجابة الجهة الرسمية.'
        : `تم تسجيل طلب الحوالة فقط. الربط الرسمي مع «${bank.nameAr}» غير متاح (${STATUS_LABEL[bank.integrationStatus]})، ولم يُنفَّذ أي تحويل مالي فعلي.`,
      message: 'تم تسجيل طلب الحوالة.',
    });
  })
);

router.patch(
  '/:id/status',
  requirePermission(P.TRANSFERS_PROCESS),
  validate(schemas.transferStatus),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const { status, note, bankRefNo } = req.body;
    const t = await prisma.transfer.findUnique({ where: { id }, include: { bank: true, agent: true } });
    if (!t) throw new HttpError(404, 'الحوالة غير موجودة.');
    if (['COMPLETED', 'CANCELLED'].includes(t.status)) throw new HttpError(400, 'لا يمكن تعديل حوالة منتهية.');
    if (status === 'COMPLETED' && t.bank.integrationStatus !== 'CONNECTED') {
      throw new HttpError(
        400,
        'لا يمكن إعلان اكتمال الحوالة بدون ربط رسمي مُختبَر مع الجهة المصرفية. الحالة الحالية: الربط غير متاح.'
      );
    }

    const updated = await prisma.transfer.update({
      where: { id },
      data: {
        status,
        bankRefNo: bankRefNo || t.bankRefNo,
        failureReason: ['FAILED', 'REJECTED'].includes(status) ? note || 'غير محدد' : t.failureReason,
        notes: note ? `${t.notes || ''}\n${note}`.trim() : t.notes,
        processedAt: ['COMPLETED', 'FAILED', 'REJECTED'].includes(status) ? new Date() : t.processedAt,
      },
    });
    await audit(req, {
      action: 'change_transfer_status', entityType: 'Transfer', entityId: id,
      before: { status: t.status }, after: { status, note: note || null },
    });

    if (t.agent?.userId) {
      const map = {
        PROCESSING: ['حوالة قيد المعالجة', `الحوالة ${t.reference} قيد المعالجة.`],
        COMPLETED: ['اكتمال الحوالة', `تم إكمال الحوالة ${t.reference}.`],
        FAILED: ['فشل الحوالة', `فشلت الحوالة ${t.reference}: ${note || 'غير محدد'}`],
        REJECTED: ['رفض الحوالة', `تم رفض الحوالة ${t.reference}.`],
        CANCELLED: ['إلغاء الحوالة', `تم إلغاء الحوالة ${t.reference}.`],
      };
      const m = map[status];
      if (m) {
        await notifyUsers([t.agent.userId], {
          title: m[0], body: m[1], type: 'transfer_status', iconKey: 'bell',
          bankId: t.bankId, entityType: 'Transfer', entityId: id,
        });
      }
    }

    if (status === 'COMPLETED' && t.agentId && Number(t.commission) > 0) {
      const exists = await prisma.commissionEntry.findFirst({ where: { transferId: t.id, status: { not: 'CANCELLED' } } });
      if (!exists) {
        await prisma.commissionEntry.create({
          data: {
            agentId: t.agentId, serviceKey: 'transfers', bankId: t.bankId, transferId: t.id,
            amount: t.commission, currency: t.currency, status: 'PENDING',
          },
        });
      }
    }

    res.json({ ok: true, status: updated.status, statusLabel: T_LABEL[updated.status], message: 'تم تحديث حالة الحوالة.' });
  })
);

router.post(
  '/:id/cancel',
  requirePermission(P.TRANSFERS_CANCEL),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const t = await prisma.transfer.findUnique({ where: { id } });
    if (!t) throw new HttpError(404, 'الحوالة غير موجودة.');
    if (['COMPLETED', 'CANCELLED'].includes(t.status)) throw new HttpError(400, 'لا يمكن إلغاء هذه الحوالة.');
    await prisma.transfer.update({
      where: { id },
      data: { status: 'CANCELLED', failureReason: req.body.reason || 'إلغاء بواسطة الموظف' },
    });
    await audit(req, { action: 'cancel_transfer', entityType: 'Transfer', entityId: id, after: { reason: req.body.reason || null } });
    res.json({ ok: true, message: 'تم إلغاء الحوالة.' });
  })
);

/** إيصال الحوالة */
router.get(
  '/:id/receipt',
  requirePermission(P.TRANSFERS_VIEW),
  asyncHandler(async (req, res) => {
    const t = await prisma.transfer.findUnique({
      where: { id: Number(req.params.id) },
      include: { bank: true, agent: true },
    });
    if (!t) throw new HttpError(404, 'الحوالة غير موجودة.');
    res.json({
      organization: 'السوبر البنكي الداخلي — SUPER BANKING',
      reference: t.reference,
      bank: t.bank.nameAr,
      type: t.type === 'OUTGOING' ? 'حوالة صادرة' : 'حوالة واردة',
      sender: t.senderName,
      beneficiary: t.beneficiaryName,
      amount: Number(t.amount),
      currency: t.currency,
      fees: Number(t.fees),
      commission: Number(t.commission),
      status: T_LABEL[t.status],
      agent: t.agent ? `${t.agent.fullName4} (${t.agent.code})` : null,
      createdAt: t.createdAt,
      issuedAt: new Date().toISOString(),
      note: t.isTest
        ? 'تنبيه: الربط الرسمي مع الجهة غير متاح — هذا مستند تسجيل طلب وليس تأكيدًا لتنفيذ تحويل مالي.'
        : 'يُعتمد إتمام الحوالة بناءً على نتيجة الجهة الرسمية.',
    });
  })
);

module.exports = router;
module.exports.T_LABEL = T_LABEL;
