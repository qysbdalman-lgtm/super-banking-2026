const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { asyncHandler } = require('../middleware/error');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

function dateFilter(from, to) {
  const f = {};
  if (from) f.gte = new Date(from);
  if (to) f.lte = new Date(`${to}T23:59:59`);
  return Object.keys(f).length ? f : null;
}

function scope(user) {
  if (user.roleKey === 'AGENT_GOLD' || user.roleKey === 'AGENT_SILVER') return { agentId: user.agentId ?? -1 };
  return {};
}

router.get(
  '/agents',
  requirePermission(P.REPORTS_VIEW, P.AGENTS_VIEW),
  asyncHandler(async (req, res) => {
    const { governorate, district, type, status, from, to } = req.query;
    const where = {};
    if (governorate) where.governorate = governorate;
    if (district) where.district = district;
    if (type) where.type = type;
    if (status) where.status = status;
    const d = dateFilter(from, to);
    if (d) where.createdAt = d;
    const rows = await prisma.agent.findMany({
      where, orderBy: { createdAt: 'desc' },
      include: { _count: { select: { customers: true, requests: true, transfers: true } } },
    });
    res.json({
      title: 'تقرير الوكلاء',
      generatedAt: new Date().toISOString(),
      count: rows.length,
      columns: ['رقم الوكيل', 'الاسم الرباعي', 'النوع', 'الحالة', 'المحافظة', 'المديرية', 'الهاتف', 'العملاء', 'الطلبات', 'الحوالات'],
      rows: rows.map((a) => ({
        code: a.code, name: a.fullName4, type: a.type === 'GOLD' ? 'ذهبي' : 'فضي', status: a.status,
        governorate: a.governorate, district: a.district, phone: a.phone,
        customers: a._count.customers, requests: a._count.requests, transfers: a._count.transfers,
      })),
    });
  })
);

router.get(
  '/customers',
  requirePermission(P.REPORTS_VIEW, P.CUSTOMERS_VIEW),
  asyncHandler(async (req, res) => {
    const { governorate, district, bankId, from, to } = req.query;
    const where = { ...scope(req.user) };
    if (governorate) where.governorate = governorate;
    if (district) where.district = district;
    if (bankId) where.bankId = Number(bankId);
    const d = dateFilter(from, to);
    if (d) where.createdAt = d;
    const rows = await prisma.customer.findMany({
      where, orderBy: { createdAt: 'desc' }, take: 2000,
      include: { bank: { select: { nameAr: true } }, agent: { select: { code: true } } },
    });
    res.json({
      title: 'تقرير العملاء',
      generatedAt: new Date().toISOString(),
      count: rows.length,
      columns: ['الاسم الرباعي', 'الهاتف', 'المحافظة', 'المديرية', 'البنك', 'الوكيل', 'تاريخ التسجيل'],
      rows: rows.map((c) => ({
        name: c.fullName4, phone: c.phone, governorate: c.governorate, district: c.district,
        bank: c.bank?.nameAr || '-', agent: c.agent?.code || '-', createdAt: c.createdAt,
      })),
    });
  })
);

router.get(
  '/account-requests',
  requirePermission(P.REPORTS_VIEW, P.REQUESTS_VIEW),
  asyncHandler(async (req, res) => {
    const { status, bankId, governorate, district, from, to, lateDays } = req.query;
    const where = { ...scope(req.user) };
    if (status) where.status = status;
    if (bankId) where.bankId = Number(bankId);
    if (governorate || district) {
      where.customer = { ...(governorate ? { governorate } : {}), ...(district ? { district } : {}) };
    }
    const d = dateFilter(from, to);
    if (d) where.createdAt = d;
    if (lateDays) {
      where.createdAt = { ...(where.createdAt || {}), lte: new Date(Date.now() - Number(lateDays) * 86400000) };
      where.status = { in: ['SUBMITTED', 'UNDER_REVIEW', 'NEEDS_INFO', 'SENT_TO_BANK'] };
    }
    const rows = await prisma.accountRequest.findMany({
      where, orderBy: { createdAt: 'desc' }, take: 3000,
      include: {
        customer: { select: { fullName4: true, phone: true, governorate: true, district: true } },
        bank: { select: { nameAr: true } },
        agent: { select: { code: true } },
      },
    });
    res.json({
      title: lateDays ? 'تقرير الطلبات المتأخرة' : 'تقرير فتح الحسابات',
      generatedAt: new Date().toISOString(),
      count: rows.length,
      columns: ['المرجع', 'العميل', 'الهاتف', 'المحافظة', 'البنك', 'الوكيل', 'الحالة', 'تاريخ التقديم', 'تاريخ الإكمال'],
      rows: rows.map((r) => ({
        reference: r.reference, customer: r.customer.fullName4, phone: r.customer.phone,
        governorate: r.customer.governorate, bank: r.bank.nameAr, agent: r.agent?.code || '-',
        status: r.status, createdAt: r.createdAt, completedAt: r.completedAt,
      })),
    });
  })
);

router.get(
  '/transfers',
  requirePermission(P.REPORTS_VIEW, P.TRANSFERS_VIEW),
  asyncHandler(async (req, res) => {
    const { status, bankId, type, from, to } = req.query;
    const where = { ...scope(req.user) };
    if (status) where.status = status;
    if (bankId) where.bankId = Number(bankId);
    if (type) where.type = type;
    const d = dateFilter(from, to);
    if (d) where.createdAt = d;
    const rows = await prisma.transfer.findMany({
      where, orderBy: { createdAt: 'desc' }, take: 3000,
      include: { bank: { select: { nameAr: true, integrationStatus: true } }, agent: { select: { code: true } } },
    });
    res.json({
      title: 'تقرير الحوالات',
      generatedAt: new Date().toISOString(),
      count: rows.length,
      note: 'الحوالات المسجلة أثناء عدم توفّر الربط الرسمي هي طلبات مسجّلة وليست تحويلات منفذة فعليًا.',
      columns: ['المرجع', 'النوع', 'الجهة', 'المرسل', 'المستفيد', 'المبلغ', 'العملة', 'الحالة', 'حالة الربط', 'الوكيل', 'التاريخ'],
      rows: rows.map((t) => ({
        reference: t.reference, type: t.type === 'OUTGOING' ? 'صادرة' : 'واردة', bank: t.bank.nameAr,
        sender: t.senderName, beneficiary: t.beneficiaryName, amount: Number(t.amount), currency: t.currency,
        status: t.status, integration: t.bank.integrationStatus, agent: t.agent?.code || '-', createdAt: t.createdAt,
      })),
    });
  })
);

router.get(
  '/commissions',
  requirePermission(P.REPORTS_VIEW, P.FINANCE_VIEW),
  asyncHandler(async (req, res) => {
    const { agentId, status, from, to } = req.query;
    const where = { ...scope(req.user) };
    if (agentId && !scope(req.user).agentId) where.agentId = Number(agentId);
    if (status) where.status = status;
    const d = dateFilter(from, to);
    if (d) where.createdAt = d;
    const rows = await prisma.commissionEntry.findMany({
      where, orderBy: { createdAt: 'desc' }, take: 3000,
      include: { agent: { select: { code: true, fullName4: true } } },
    });
    res.json({
      title: 'تقرير العمولات',
      generatedAt: new Date().toISOString(),
      count: rows.length,
      total: rows.reduce((s, r) => s + Number(r.amount), 0),
      currency: 'YER',
      columns: ['الوكيل', 'الخدمة', 'النوع', 'المبلغ', 'الحالة', 'السبب', 'التاريخ'],
      rows: rows.map((c) => ({
        agent: `${c.agent.fullName4} (${c.agent.code})`, service: c.serviceKey,
        kind: c.kind === 'ADJUSTMENT' ? 'تسوية' : 'مستحقة', amount: Number(c.amount),
        status: c.status, reason: c.reason || '-', createdAt: c.createdAt,
      })),
    });
  })
);

router.get(
  '/banks',
  requirePermission(P.REPORTS_VIEW, P.BANKS_VIEW),
  asyncHandler(async (req, res) => {
    const banks = await prisma.bank.findMany({
      orderBy: { sortOrder: 'asc' },
      include: { _count: { select: { requests: true, transfers: true, agentBanks: true } } },
    });
    res.json({
      title: 'تقرير أداء الجهات المصرفية',
      generatedAt: new Date().toISOString(),
      count: banks.length,
      columns: ['الجهة', 'حالة الربط', 'الطلبات', 'الحوالات', 'الوكلاء المرتبطون', 'مفعّلة'],
      rows: banks.map((b) => ({
        name: b.nameAr, integration: b.integrationStatus, requests: b._count.requests,
        transfers: b._count.transfers, agents: b._count.agentBanks, isActive: b.isActive,
      })),
    });
  })
);

router.get(
  '/errors',
  requirePermission(P.REPORTS_VIEW, P.TICKETS_VIEW),
  asyncHandler(async (req, res) => {
    const [logs, tickets] = await Promise.all([
      prisma.integrationLog.findMany({
        where: { success: false }, orderBy: { createdAt: 'desc' }, take: 200,
        include: { bank: { select: { nameAr: true } } },
      }),
      prisma.ticket.findMany({ orderBy: { createdAt: 'desc' }, take: 200, include: { bank: { select: { nameAr: true } } } }),
    ]);
    res.json({
      title: 'تقرير الأخطاء',
      generatedAt: new Date().toISOString(),
      integrationErrors: logs.map((l) => ({ bank: l.bank.nameAr, operation: l.operation, error: l.errorMessage, at: l.createdAt })),
      tickets: tickets.map((t) => ({ reference: t.reference, subject: t.subject, status: t.status, bank: t.bank?.nameAr || '-', at: t.createdAt })),
    });
  })
);

router.get(
  '/notifications',
  requirePermission(P.REPORTS_VIEW),
  asyncHandler(async (req, res) => {
    const rows = await prisma.notification.findMany({
      where: { userId: req.user.id }, orderBy: { createdAt: 'desc' }, take: 500,
    });
    res.json({
      title: 'تقرير الإشعارات',
      generatedAt: new Date().toISOString(),
      count: rows.length,
      unread: rows.filter((r) => !r.isRead).length,
      rows: rows.map((n) => ({ title: n.title, type: n.type, isRead: n.isRead, createdAt: n.createdAt })),
    });
  })
);

router.get(
  '/agent-activity/:id',
  requirePermission(P.REPORTS_VIEW, P.AGENTS_VIEW),
  asyncHandler(async (req, res) => {
    const agentId = Number(req.params.id);
    if (scope(req.user).agentId && scope(req.user).agentId !== agentId) {
      return res.status(403).json({ error: 'غير مصرح.' });
    }
    const [agent, requests, transfers, commissions] = await Promise.all([
      prisma.agent.findUnique({ where: { id: agentId } }),
      prisma.accountRequest.count({ where: { agentId } }),
      prisma.transfer.count({ where: { agentId } }),
      prisma.commissionEntry.aggregate({ where: { agentId }, _sum: { amount: true }, _count: true }),
    ]);
    res.json({
      title: `تقرير نشاط الوكيل ${agent?.code || ''}`,
      agent: { code: agent?.code, name: agent?.fullName4, status: agent?.status, type: agent?.type },
      requests, transfers,
      commissions: { count: commissions._count, total: Number(commissions._sum.amount || 0) },
      generatedAt: new Date().toISOString(),
    });
  })
);

/**
 * تصدير Excel حقيقي (xlsx) — ملف قابل للفتح والطباعة مع دعم صحيح للأسماء العربية.
 * المسار: /api/reports/<kind>.xlsx   (مثال: /api/reports/requests.xlsx)
 */
router.get(
  '/:kind.:ext',
  requirePermission(P.REPORTS_EXPORT, P.REPORTS_VIEW),
  asyncHandler(async (req, res) => {
    const XLSX = require('xlsx');
    const { HttpError: HE } = require('../middleware/error');
    const { audit: logAudit } = require('../services/audit');
    const { can } = require('../middleware/rbac');

    if (req.params.ext !== 'xlsx') throw new HE(404, 'الصيغة المدعومة للتصدير هي xlsx فقط.');
    const kind = req.params.kind;
    const sc = scope(req.user);
    const fmt = (d) => (d ? new Date(d).toISOString().slice(0, 19).replace('T', ' ') : '-');
    const maskId = (v) =>
      !v ? '-' : can(req.user, P.CUSTOMERS_VIEW_SENSITIVE) ? v : `${String(v).slice(0, 3)}****${String(v).slice(-2)}`;

    let rows = [];
    let title = 'تقرير';

    if (kind === 'requests') {
      title = 'تقرير طلبات فتح الحسابات';
      const list = await prisma.accountRequest.findMany({
        where: { ...sc }, orderBy: { createdAt: 'desc' }, take: 5000,
        include: { customer: true, bank: { select: { nameAr: true } }, agent: { select: { code: true } } },
      });
      rows = list.map((r) => ({
        'المرجع': r.reference, 'العميل': r.customer.fullName4, 'الهاتف': r.customer.phone,
        'المحافظة': r.customer.governorate, 'المديرية': r.customer.district,
        'البنك': r.bank.nameAr, 'الوكيل': r.agent ? r.agent.code : '-',
        'نوع الحساب': r.accountType || '-', 'الحالة': r.status,
        'رقم مرجع الجهة': r.bankRefNo || '-', 'تاريخ التقديم': fmt(r.createdAt), 'تاريخ الإكمال': fmt(r.completedAt),
      }));
    } else if (kind === 'agents') {
      title = 'تقرير الوكلاء';
      const list = await prisma.agent.findMany({ orderBy: { createdAt: 'desc' }, take: 5000 });
      rows = list.map((a) => ({
        'رقم الوكيل': a.code, 'الاسم الرباعي': a.fullName4, 'النوع': a.type === 'GOLD' ? 'ذهبي' : 'فضي',
        'الحالة': a.status, 'المحافظة': a.governorate, 'المديرية': a.district,
        'الهاتف': a.phone, 'رقم العقد': a.contractNo || '-',
        'العمولات المستحقة': Number(a.settlementBalance || 0), 'آخر نشاط': fmt(a.lastActivityAt),
      }));
    } else if (kind === 'customers') {
      title = 'تقرير العملاء';
      const list = await prisma.customer.findMany({
        where: { ...sc }, orderBy: { createdAt: 'desc' }, take: 5000,
        include: { bank: { select: { nameAr: true } }, agent: { select: { code: true } } },
      });
      rows = list.map((c) => ({
        'الاسم الرباعي': c.fullName4, 'رقم البطاقة': maskId(c.nationalId), 'الهاتف': c.phone,
        'المحافظة': c.governorate, 'المديرية': c.district,
        'البنك': c.bank ? c.bank.nameAr : '-', 'الوكيل': c.agent ? c.agent.code : '-',
        'الحالة': c.status, 'تاريخ التسجيل': fmt(c.createdAt),
      }));
    } else if (kind === 'transfers') {
      title = 'تقرير الحوالات';
      const list = await prisma.transfer.findMany({
        where: { ...sc }, orderBy: { createdAt: 'desc' }, take: 5000,
        include: { bank: { select: { nameAr: true, integrationStatus: true } }, agent: { select: { code: true } } },
      });
      rows = list.map((t) => ({
        'المرجع': t.reference, 'النوع': t.type === 'OUTGOING' ? 'صادرة' : 'واردة',
        'الجهة': t.bank.nameAr, 'حالة الربط': t.bank.integrationStatus,
        'المرسل': t.senderName, 'المستفيد': t.beneficiaryName,
        'المبلغ': Number(t.amount), 'العملة': t.currency, 'الرسوم': Number(t.fees), 'العمولة': Number(t.commission),
        'الحالة': t.status, 'الوكيل': t.agent ? t.agent.code : '-', 'التاريخ': fmt(t.createdAt),
        'تنبيه': t.isTest ? 'طلب مسجّل — الربط الرسمي غير متاح' : 'مسجّل عبر ربط رسمي',
      }));
    } else if (kind === 'commissions') {
      title = 'تقرير العمولات';
      const list = await prisma.commissionEntry.findMany({
        where: { ...sc }, orderBy: { createdAt: 'desc' }, take: 5000,
        include: { agent: { select: { code: true, fullName4: true } } },
      });
      rows = list.map((c) => ({
        'الوكيل': `${c.agent.fullName4} (${c.agent.code})`, 'الخدمة': c.serviceKey,
        'النوع': c.kind === 'ADJUSTMENT' ? 'تسوية' : 'مستحقة', 'المبلغ': Number(c.amount),
        'العملة': c.currency, 'الحالة': c.status, 'السبب': c.reason || '-', 'التاريخ': fmt(c.createdAt),
      }));
    } else if (kind === 'banks') {
      title = 'تقرير أداء الجهات المصرفية';
      const list = await prisma.bank.findMany({ orderBy: { sortOrder: 'asc' } });
      rows = list.map((b) => ({
        'الجهة': b.nameAr, 'الاسم المختصر': b.shortName || '-', 'حالة الربط': b.integrationStatus,
        'مفعّلة': b.isActive ? 'نعم' : 'لا', 'آخر اختبار اتصال': fmt(b.lastTestAt),
        'آخر رسالة خطأ': b.lastError || '-', 'متطلبات الاعتماد': b.requirements || '-',
      }));
    } else if (kind === 'notifications') {
      title = 'تقرير الإشعارات';
      const list = await prisma.notification.findMany({
        where: { userId: req.user.id }, orderBy: { createdAt: 'desc' }, take: 5000,
      });
      rows = list.map((n) => ({
        'العنوان': n.title, 'النوع': n.type, 'الرسالة': n.body || '-',
        'مقروء': n.isRead ? 'نعم' : 'لا', 'التاريخ': fmt(n.createdAt),
      }));
    } else if (kind === 'errors') {
      title = 'تقرير الأخطاء';
      const list = await prisma.integrationLog.findMany({
        where: { success: false }, orderBy: { createdAt: 'desc' }, take: 5000,
        include: { bank: { select: { nameAr: true } } },
      });
      rows = list.map((l) => ({
        'الجهة': l.bank.nameAr, 'العملية': l.operation, 'رسالة الخطأ': l.errorMessage || '-', 'التاريخ': fmt(l.createdAt),
      }));
    } else {
      throw new HE(400, 'نوع التقرير غير معروف.');
    }

    const ws = XLSX.utils.json_to_sheet(rows.length ? rows : [{ 'لا توجد بيانات': '-' }]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'التقرير');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    await logAudit(req, { action: 'export_report', entityType: 'Report', entityId: kind, after: { rows: rows.length } });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${kind}-report.xlsx"`);
    res.setHeader('Cache-Control', 'no-store, private');
    res.send(buf);
  })
);

module.exports = router;
