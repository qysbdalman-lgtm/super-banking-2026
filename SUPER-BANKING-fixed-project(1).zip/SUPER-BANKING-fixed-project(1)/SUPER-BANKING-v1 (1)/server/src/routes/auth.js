const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { authenticator } = require('otplib');
const { prisma } = require('../db');
const config = require('../config');
const { sha256, randomToken, encryptSecret, decryptSecret } = require('../utils/crypto');
const { validate, schemas } = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');
const { loginLimiter } = require('../middleware/rateLimit');
const { audit } = require('../services/audit');
const { notifyUsers, adminUserIds } = require('../services/notify');

const r = express.Router();
const MAX_FAILED = 5;
const LOCK_MIN = 15;
const COOKIE = 'sb_token';

const userInclude = {
  role: { include: { permissions: { include: { permission: true } } } },
  agent: { select: { id: true, code: true, status: true, type: true } },
};

function shape(u) {
  return {
    id: u.id,
    username: u.username,
    fullName: u.fullName,
    phone: u.phone,
    roleKey: u.role.key,
    roleName: u.role.nameAr,
    permissions: u.role.permissions.map((p) => p.permission.key),
    mfaEnabled: u.mfaEnabled,
    mustChangePassword: u.mustChangePassword,
    agentId: u.agent ? u.agent.id : null,
    agentCode: u.agent ? u.agent.code : null,
    agentStatus: u.agent ? u.agent.status : null,
    agentType: u.agent ? u.agent.type : null,
  };
}

r.post('/login', loginLimiter, validate(schemas.login), async (req, res, next) => {
  try {
    const { identifier, password, otp } = req.body;
    const ip = req.ip;
    const ua = req.headers['user-agent'];
    const digits = String(identifier).replace(/\D/g, '');
    const user = await prisma.user.findFirst({
      where: { OR: [{ username: identifier }, { phone: identifier }, { phone: digits || '__none__' }] },
      include: userInclude,
    });
    const fail = async (reason, code, extra) => {
      await prisma.loginAttempt.create({
        data: { identifier, userId: user ? user.id : null, success: false, reason, ip, userAgent: ua },
      });
      return res.status(code).json(Object.assign({ error: reason }, extra || {}));
    };
    if (!user) return fail('اسم المستخدم أو كلمة المرور غير صحيحة.', 401);
    if (user.lockedUntil && user.lockedUntil > new Date())
      return fail('الحساب موقوف مؤقتًا بعد محاولات متعددة. حاول لاحقًا.', 423);
    if (user.status !== 'ACTIVE') return fail('الحساب غير مفعّل. راجع الإدارة.', 403);

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) {
      const attempts = user.failedAttempts + 1;
      const data = { failedAttempts: attempts };
      if (attempts >= MAX_FAILED) {
        data.lockedUntil = new Date(Date.now() + LOCK_MIN * 60000);
        data.failedAttempts = 0;
      }
      await prisma.user.update({ where: { id: user.id }, data });
      if (attempts >= MAX_FAILED) {
        await notifyUsers(await adminUserIds(), {
          title: 'إيقاف مؤقت لحساب',
          body: `تم إيقاف الحساب مؤقتًا بعد ${MAX_FAILED} محاولات دخول فاشلة.`,
          type: 'security',
          iconKey: 'shield',
        });
      }
      return fail('اسم المستخدم أو كلمة المرور غير صحيحة.', 401);
    }
    if (user.mfaEnabled) {
      if (!otp) return fail('رمز التحقق الإضافي مطلوب.', 401, { mfaRequired: true });
      const secret = decryptSecret(user.mfaSecretEnc, config.jwtSecret);
      if (!secret || !authenticator.check(String(otp), secret))
        return fail('رمز التحقق الإضافي غير صحيح.', 401, { mfaRequired: true });
    }

    await prisma.user.update({
      where: { id: user.id },
      data: { failedAttempts: 0, lockedUntil: null, lastLoginAt: new Date(), lastLoginIp: ip },
    });
    const expiresAt = new Date(Date.now() + config.sessionTtlHours * 3600000);
    const session = await prisma.session.create({
      data: { userId: user.id, ip, userAgent: ua, expiresAt, tokenHash: 'pending-' + randomToken(8) },
    });
    const token = jwt.sign({ sub: user.id, sid: session.id }, config.jwtSecret, {
      expiresIn: `${config.sessionTtlHours}h`,
    });
    await prisma.session.update({
      where: { id: session.id },
      data: { tokenHash: sha256(token), refreshHash: randomToken(24) },
    });
    await prisma.loginAttempt.create({ data: { identifier, userId: user.id, success: true, ip, userAgent: ua } });
    await audit(
      { user: { id: user.id, fullName: user.fullName, roleKey: user.role.key }, ip, headers: req.headers },
      { action: 'LOGIN', entityType: 'User', entityId: user.id }
    );
    res.cookie(COOKIE, token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: config.isProd,
      maxAge: config.sessionTtlHours * 3600000,
      path: '/',
    });
    res.json({ user: shape(user), token });
  } catch (e) {
    next(e);
  }
});

r.post('/logout', authenticate, async (req, res, next) => {
  try {
    if (req.sessionId) await prisma.session.update({ where: { id: req.sessionId }, data: { revokedAt: new Date() } });
    res.clearCookie(COOKIE, { path: '/' });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

r.get('/me', authenticate, async (req, res, next) => {
  try {
    const u = await prisma.user.findUnique({ where: { id: req.user.id }, include: userInclude });
    res.json({ user: shape(u) });
  } catch (e) {
    next(e);
  }
});

r.post('/password', authenticate, validate(schemas.changePassword), async (req, res, next) => {
  try {
    const u = await prisma.user.findUnique({ where: { id: req.user.id } });
    if (!(await bcrypt.compare(req.body.currentPassword, u.passwordHash)))
      return res.status(400).json({ error: 'كلمة المرور الحالية غير صحيحة.' });
    const passwordHash = await bcrypt.hash(req.body.newPassword, 10);
    await prisma.user.update({ where: { id: u.id }, data: { passwordHash, mustChangePassword: false } });
    await prisma.session.updateMany({ where: { userId: u.id, id: { not: req.sessionId } }, data: { revokedAt: new Date() } });
    await audit(req, { action: 'PASSWORD_CHANGE', entityType: 'User', entityId: u.id });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

r.post('/recovery', async (req, res, next) => {
  try {
    const identifier = String(req.body.identifier || '').trim();
    const digits = identifier.replace(/\D/g, '');
    const user = identifier
      ? await prisma.user.findFirst({ where: { OR: [{ username: identifier }, { phone: digits || '__none__' }] } })
      : null;
    if (user) {
      await prisma.loginAttempt.create({
        data: { identifier, userId: user.id, success: false, reason: 'طلب استعادة حساب', ip: req.ip },
      });
      await notifyUsers(await adminUserIds(), {
        title: 'طلب استعادة حساب',
        body: 'ورد طلب استعادة حساب. تظهر التفاصيل داخل لوحة الإدارة بعد التحقق من الهوية.',
        type: 'security',
        iconKey: 'shield',
      });
      await audit({ user: null, ip: req.ip, headers: req.headers }, {
        action: 'RECOVERY_REQUEST',
        entityType: 'User',
        entityId: user.id,
      });
    }
    res.json({
      message:
        'إذا كان الحساب مسجّلًا فسيتم التعامل مع الطلب من الإدارة. للتحقق من الهوية تواصل مع الإدارة على 777762996.',
    });
  } catch (e) {
    next(e);
  }
});

r.post('/reset', validate(schemas.login.partial().extend({ token: require('zod').z.string().min(10), password: require('zod').z.string().min(8) }).pick({ token: true, password: true })), async (req, res, next) => {
  try {
    const { token, password } = req.body;
    const row = await prisma.passwordReset.findUnique({ where: { tokenHash: sha256(token) } });
    if (!row || row.usedAt || row.expiresAt < new Date())
      return res.status(400).json({ error: 'رمز الاستعادة غير صالح أو منتهي.' });
    const passwordHash = await bcrypt.hash(password, 10);
    await prisma.$transaction([
      prisma.user.update({ where: { id: row.userId }, data: { passwordHash, mustChangePassword: false, failedAttempts: 0, lockedUntil: null } }),
      prisma.passwordReset.update({ where: { id: row.id }, data: { usedAt: new Date() } }),
      prisma.session.updateMany({ where: { userId: row.userId, revokedAt: null }, data: { revokedAt: new Date() } }),
    ]);
    await audit({ user: null, ip: req.ip, headers: req.headers }, { action: 'PASSWORD_RESET', entityType: 'User', entityId: row.userId });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

r.post('/reset/issue', authenticate, async (req, res, next) => {
  try {
    if (!(req.user.permissions || []).includes('users.manage'))
      return res.status(403).json({ error: 'لا تملك الصلاحية.' });
    const userId = Number(req.body.userId);
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) return res.status(404).json({ error: 'المستخدم غير موجود.' });
    const token = randomToken(24);
    const expiresAt = new Date(Date.now() + 24 * 3600000);
    await prisma.passwordReset.create({ data: { userId, tokenHash: sha256(token), expiresAt } });
    await audit(req, { action: 'RESET_ISSUE', entityType: 'User', entityId: userId });
    res.json({ token, expiresAt, note: 'سلّم الرمز للمستخدم عبر قناة موثوقة؛ صالح 24 ساعة ولمرة واحدة.' });
  } catch (e) {
    next(e);
  }
});

r.post('/mfa/setup', authenticate, async (req, res, next) => {
  try {
    const secret = authenticator.generateSecret();
    await prisma.user.update({
      where: { id: req.user.id },
      data: { mfaSecretEnc: encryptSecret(secret, config.jwtSecret), mfaEnabled: false },
    });
    res.json({ secret, otpauth: authenticator.keyuri(req.user.username, 'SUPER BANKING', secret) });
  } catch (e) {
    next(e);
  }
});

r.post('/mfa/enable', authenticate, async (req, res, next) => {
  try {
    const u = await prisma.user.findUnique({ where: { id: req.user.id } });
    const secret = decryptSecret(u.mfaSecretEnc, config.jwtSecret);
    if (!secret) return res.status(400).json({ error: 'ابدأ تهيئة المصادقة الإضافية أولًا.' });
    if (!authenticator.check(String(req.body.otp || ''), secret))
      return res.status(400).json({ error: 'رمز التحقق غير صحيح.' });
    await prisma.user.update({ where: { id: u.id }, data: { mfaEnabled: true } });
    await audit(req, { action: 'MFA_ENABLE', entityType: 'User', entityId: u.id });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

r.post('/mfa/disable', authenticate, async (req, res, next) => {
  try {
    const u = await prisma.user.findUnique({ where: { id: req.user.id } });
    if (!(await bcrypt.compare(String(req.body.password || ''), u.passwordHash)))
      return res.status(400).json({ error: 'كلمة المرور غير صحيحة.' });
    const secret = decryptSecret(u.mfaSecretEnc, config.jwtSecret);
    if (secret && !authenticator.check(String(req.body.otp || ''), secret))
      return res.status(400).json({ error: 'رمز التحقق غير صحيح.' });
    await prisma.user.update({ where: { id: u.id }, data: { mfaEnabled: false, mfaSecretEnc: null } });
    await audit(req, { action: 'MFA_DISABLE', entityType: 'User', entityId: u.id });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

r.get('/sessions', authenticate, async (req, res, next) => {
  try {
    const rows = await prisma.session.findMany({
      where: { userId: req.user.id, revokedAt: null, expiresAt: { gt: new Date() } },
      orderBy: { createdAt: 'desc' },
      select: { id: true, ip: true, userAgent: true, createdAt: true, expiresAt: true },
    });
    res.json(rows.map((s) => ({ ...s, current: s.id === req.sessionId })));
  } catch (e) {
    next(e);
  }
});

r.delete('/sessions/:id', authenticate, async (req, res, next) => {
  try {
    const s = await prisma.session.findUnique({ where: { id: req.params.id } });
    if (!s || s.userId !== req.user.id) return res.status(404).json({ error: 'الجلسة غير موجودة.' });
    await prisma.session.update({ where: { id: s.id }, data: { revokedAt: new Date() } });
    await audit(req, { action: 'SESSION_REVOKE', entityType: 'Session', entityId: s.id });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

module.exports = r;
