const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission, can } = require('../middleware/rbac');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler, HttpError } = require('../middleware/error');
const { audit } = require('../services/audit');
const { notifyUsers, usersWithPermission, adminUserIds } = require('../services/notify');
const { nextReference } = require('../utils/reference');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

const STATUS_LABEL = {
  DRAFT: 'مسودة',
  SUBMITTED: 'تم الإرسال',
  UNDER_REVIEW: 'قيد المراجعة',
  NEEDS_INFO: 'مطلوب استكمال بيانات',
  SENT_TO_BANK: 'تم إرسال الطلب إلى البنك',
  BANK_APPROVED: 'تمت الموافقة من الجهة',
  REJECTED: 'مرفوض',
  COMPLETED: 'مكتمل',
  CANCELLED: 'ملغى',
};

/** انتقالات الحالة المسموح بها — لا يُكتمل الطلب إلا بمرجع نتيجة من الجهة */
const ALLOWED_TRANSITIONS = {
  DRAFT: ['SUBMITTED', 'CANCELLED'],
  SUBMITTED: ['UNDER_REVIEW', 'NEEDS_INFO', 'REJECTED', 'CANCELLED'],
  UNDER_REVIEW: ['NEEDS_INFO', 'SENT_TO_BANK', 'REJECTED', 'CANCELLED'],
  NEEDS_INFO: ['SUBMITTED', 'UNDER_REVIEW', 'CANCELLED'],
  SENT_TO_BANK: ['BANK_APPROVED', 'REJECTED', 'NEEDS_INFO'],
  BANK_APPROVED: ['COMPLETED', 'REJECTED'],
  REJECTED: [],
  COMPLETED: [],
  CANCELLED: [],
};

function requestScope(user) {
  if (user.roleKey === 'AGENT_GOLD' || user.roleKey === 'AGENT_SILVER') return { agentId: user.agentId ?? -1 };
  return {};
}

router.get(
  '/',
  requirePermission(P.REQUESTS_VIEW),
  asyncHandler(async (req, res) => {
    const { q, status, bankId, agentId, from, to, page = 1, pageSize = 25 } = req.query;
    const where = { ...requestScope(req.user) };
    if (status) where.status = status;
    if (bankId) where.bankId = Number(bankId);
    if (agentId && req.user.roleKey !== 'AGENT_GOLD' && req.user.roleKey !== 'AGENT_SILVER') where.agentId = Number(agentId);
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt.gte = new Date(from);
      if (to) where.createdAt.lte = new Date(`${to}T23:59:59`);
    }
    if (q) {
      where.OR = [
        { reference: { contains: q, mode: 'insensitive' } },
        { customer: { fullName4: { contains: q, mode: 'insensitive' } } },
        { customer: { phone: { contains: q } } },
      ];
    }
    const take = Math.min(Number(pageSize), 100);
    const skip = (Math.max(Number(page), 1) - 1) * take;
    const [items, total] = await Promise.all([
      prisma.accountRequest.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take,
        include: {
          customer: { select: { id: true, fullName4: true, phone: true, governorate: true, district: true } },
          bank: { select: { id: true, nameAr: true, integrationStatus: true } },
          agent: { select: { id: true, code: true, fullName4: true } },
          _count: { select: { documents: true } },
        },
      }),
      prisma.accountRequest.count({ where }),
    ]);
    res.json({
      items: items.map((r) => ({ ...r, statusLabel: STATUS_LABEL[r.status] })),
      total,
      page: Number(page),
      pageSize: take,
      statuses: Object.entries(STATUS_LABEL).map(([key, label]) => ({ key, label })),
    });
  })
);

router.get(
  '/:id',
  requirePermission(P.REQUESTS_VIEW),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const r = await prisma.accountRequest.findUnique({
      where: { id },
      include: {
        customer: true,
        bank: true,
        agent: { select: { id: true, code: true, fullName4: true, phone: true } },
        documents: { include: { file: { select: { id: true, originalName: true, mimeType: true, size: true } } } },
        history: { orderBy: { createdAt: 'asc' } },
        commissions: true,
      },
    });
    if (!r) throw new HttpError(404, 'الطلب غير موجود.');
    if ((req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER') && r.agentId !== req.user.agentId) {
      throw new HttpError(403, 'لا تملك صلاحية عرض هذا الطلب.');
    }
    const sensitive = can(req.user, P.CUSTOMERS_VIEW_SENSITIVE);
    res.json({
      ...r,
      statusLabel: STATUS_LABEL[r.status],
      commissions: (r.commissions || []).map((c) => ({ ...c, amount: Number(c.amount) })),
      customer: {
        ...r.customer,
        nationalId: sensitive
          ? r.customer.nationalId
          : `${String(r.customer.nationalId).slice(0, 3)}****${String(r.customer.nationalId).slice(-2)}`,
      },
      sensitiveMasked: !sensitive,
    });
  })
);

/** إنشاء طلب فتح حساب + إنشاء/ربط العميل داخل معاملة واحدة */
router.post(
  '/',
  requirePermission(P.REQUESTS_CREATE),
  validate(schemas.accountRequest),
  asyncHandler(async (req, res) => {
    const d = req.body;
    if (!d.consentGiven) throw new HttpError(400, 'يجب موافقة العميل على معالجة بياناته وفق السياسة المعتمدة.');

    const bank = await prisma.bank.findUnique({ where: { id: d.bankId } });
    if (!bank) throw new HttpError(404, 'البنك غير موجود.');
    if (!bank.isActive) throw new HttpError(400, 'هذه الجهة غير مفعّلة حاليًا.');

    const agentId =
      req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER' ? req.user.agentId : d.agentId || null;

    const result = await prisma.$transaction(async (tx) => {
      let customerId = d.customerId;
      if (!customerId) {
        if (!d.customer) throw new HttpError(400, 'بيانات العميل مطلوبة.');
        const dup = await tx.customer.findFirst({
          where: { OR: [{ nationalId: d.customer.nationalId }, { phone: d.customer.phone }] },
        });
        if (dup) {
          customerId = dup.id;
        } else {
          const c = await tx.customer.create({
            data: {
              fullName4: d.customer.fullName4,
              nationalId: d.customer.nationalId,
              phone: d.customer.phone,
              altPhone: d.customer.altPhone || null,
              governorate: d.customer.governorate,
              district: d.customer.district,
              area: d.customer.area || null,
              address: d.customer.address || null,
              dob: d.customer.dob ? new Date(d.customer.dob) : null,
              gender: d.customer.gender || null,
              accountType: d.accountType,
              bankId: d.bankId,
              agentId,
              createdById: req.user.id,
            },
          });
          customerId = c.id;
        }
      }

      const dupReq = await tx.accountRequest.findFirst({
        where: { customerId, bankId: d.bankId, status: { notIn: ['REJECTED', 'CANCELLED'] } },
      });
      if (dupReq) {
        throw new HttpError(409, `يوجد طلب سابق لنفس العميل لدى هذه الجهة (المرجع: ${dupReq.reference}).`);
      }

      const reference = await nextReference('ACCOUNT_REQUEST');
      const receiptNo = await nextReference('RECEIPT');
      const created = await tx.accountRequest.create({
        data: {
          reference,
          receiptNo,
          customerId,
          bankId: d.bankId,
          agentId,
          accountType: d.accountType,
          status: 'DRAFT',
          consentGiven: true,
          notes: d.notes || null,
          createdById: req.user.id,
          submittedAt: null,
        },
      });
      await tx.accountRequestStatusHistory.create({
        data: {
          requestId: created.id,
          fromStatus: null,
          toStatus: 'DRAFT',
          note: 'تم إنشاء الطلب وحفظه كمسودة، ثم يُرسل بعد استكمال المستندات.',
          changedById: req.user.id,
          changedByName: req.user.fullName,
        },
      });
      return created;
    });

    if (agentId) await prisma.agent.update({ where: { id: agentId }, data: { lastActivityAt: new Date() } });

    await audit(req, {
      action: 'create_account_request',
      entityType: 'AccountRequest',
      entityId: result.id,
      after: { reference: result.reference },
    });

    const reviewers = await usersWithPermission(P.REQUESTS_REVIEW);
    await notifyUsers(reviewers.length ? reviewers : await adminUserIds(), {
      title: 'طلب فتح حساب جديد',
      body: `طلب جديد برقم ${result.reference} لدى ${bank.nameAr}.`,
      type: 'request_new',
      iconKey: 'file-plus',
      bankId: bank.id,
      entityType: 'AccountRequest',
      entityId: result.id,
    });
    if (agentId) {
      const agent = await prisma.agent.findUnique({ where: { id: agentId } });
      if (agent?.userId) {
        await notifyUsers([agent.userId], {
          title: 'تم استلام طلب العميل',
          body: `تم إرسال الطلب ${result.reference} بنجاح. رقم الإيصال: ${result.receiptNo}.`,
          type: 'request_receipt',
          iconKey: 'receipt',
          bankId: bank.id,
          entityType: 'AccountRequest',
          entityId: result.id,
        });
      }
    }

    res.status(201).json({
      ok: true,
      id: result.id,
      reference: result.reference,
      receiptNo: result.receiptNo,
      status: result.status,
      statusLabel: STATUS_LABEL[result.status],
      submittedAt: result.submittedAt,
      message: 'تم استلام الطلب. يمكنك متابعته بالرقم المرجعي.',
    });
  })
);

/** حفظ كمسودة */
router.post(
  '/draft',
  requirePermission(P.REQUESTS_CREATE),
  asyncHandler(async (req, res) => {
    const { customerId, bankId, accountType } = req.body;
    if (!customerId || !bankId) throw new HttpError(400, 'العميل والجهة مطلوبان لحفظ المسودة.');
    const reference = await nextReference('ACCOUNT_REQUEST');
    const created = await prisma.accountRequest.create({
      data: {
        reference,
        customerId: Number(customerId),
        bankId: Number(bankId),
        accountType: accountType || null,
        status: 'DRAFT',
        createdById: req.user.id,
      },
    });
    await prisma.accountRequestStatusHistory.create({
      data: {
        requestId: created.id,
        fromStatus: null,
        toStatus: 'DRAFT',
        note: 'حفظ كمسودة',
        changedById: req.user.id,
        changedByName: req.user.fullName,
      },
    });
    res.status(201).json({ ok: true, id: created.id, reference, message: 'تم حفظ الطلب كمسودة.' });
  })
);

/** تغيير الحالة مع التحقق من الانتقال المسموح وتسجيل السجل */
router.patch(
  '/:id/status',
  requirePermission(P.REQUESTS_CHANGE_STATUS, P.REQUESTS_REVIEW, P.REQUESTS_APPROVE),
  validate(schemas.accountRequestStatus),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const { status, note, bankRefNo } = req.body;
    const r = await prisma.accountRequest.findUnique({ where: { id }, include: { bank: true, agent: true } });
    if (!r) throw new HttpError(404, 'الطلب غير موجود.');

    const allowed = ALLOWED_TRANSITIONS[r.status] || [];
    if (!allowed.includes(status)) {
      throw new HttpError(400, `لا يمكن الانتقال من «${STATUS_LABEL[r.status]}» إلى «${STATUS_LABEL[status]}».`);
    }
    if (['REJECTED', 'BANK_APPROVED', 'COMPLETED'].includes(status) && !can(req.user, P.REQUESTS_APPROVE)) {
      throw new HttpError(403, 'اعتماد أو رفض الطلبات يحتاج صلاحية الاعتماد.');
    }
    if (status === 'COMPLETED' && !r.bankRefNo && !bankRefNo) {
      throw new HttpError(400, 'لا يمكن إكمال الطلب قبل تسجيل نتيجة الجهة المعنية (رقم مرجعي من البنك).');
    }
    if (status === 'REJECTED' && !note) throw new HttpError(400, 'يجب توضيح سبب الرفض.');

    // لا يُرسل الطلب قبل استكمال مستندات الهوية الإلزامية
    if (status === 'SUBMITTED') {
      const docs = await prisma.accountRequestDocument.findMany({ where: { requestId: id } });
      const types = new Set(docs.map((x) => x.docType));
      if (!types.has('id_front') || !types.has('id_back')) {
        throw new HttpError(400, 'لا يمكن إرسال الطلب قبل رفع صورتَي البطاقة الشخصية (الأمام والخلف).');
      }
    }

    const updated = await prisma.$transaction(async (tx) => {
      const up = await tx.accountRequest.update({
        where: { id },
        data: {
          status,
          bankRefNo: bankRefNo || r.bankRefNo,
          rejectionReason: status === 'REJECTED' ? note : r.rejectionReason,
          submittedAt: status === 'SUBMITTED' ? new Date() : r.submittedAt,
          completedAt: status === 'COMPLETED' ? new Date() : r.completedAt,
        },
      });
      await tx.accountRequestStatusHistory.create({
        data: {
          requestId: id,
          fromStatus: r.status,
          toStatus: status,
          note: note || null,
          changedById: req.user.id,
          changedByName: req.user.fullName,
        },
      });
      return up;
    });

    await audit(req, {
      action: 'change_request_status',
      entityType: 'AccountRequest',
      entityId: id,
      before: { status: r.status },
      after: { status, note: note || null },
    });

    const titles = {
      UNDER_REVIEW: ['الطلب قيد المراجعة', `الطلب ${r.reference} قيد المراجعة.`],
      NEEDS_INFO: ['مطلوب استكمال بيانات', note || `الطلب ${r.reference} يحتاج بيانات إضافية.`],
      SENT_TO_BANK: ['تم إرسال الطلب إلى البنك', `الطلب ${r.reference} أُرسل إلى ${r.bank.nameAr}.`],
      BANK_APPROVED: ['تمت الموافقة على الطلب', `تمت الموافقة على الطلب ${r.reference} من ${r.bank.nameAr}.`],
      REJECTED: ['تم رفض الطلب', note || `تم رفض الطلب ${r.reference}.`],
      COMPLETED: ['اكتمال المعاملة', `تم إكمال الطلب ${r.reference}.`],
      CANCELLED: ['تم إلغاء الطلب', `تم إلغاء الطلب ${r.reference}.`],
    };
    const t = titles[status];
    if (r.agent?.userId && t) {
      await notifyUsers([r.agent.userId], {
        title: t[0],
        body: t[1],
        type: 'request_status',
        iconKey: 'file-check',
        bankId: r.bankId,
        entityType: 'AccountRequest',
        entityId: id,
      });
    }

    // استحقاق العمولة عند الإكمال وفق القاعدة المعتمدة في لوحة الإدارة
    if (status === 'COMPLETED' && r.agentId) {
      const rule = await prisma.bankService.findFirst({
        where: { bankId: r.bankId, service: { key: { in: ['open_account', 'account_open'] } } },
      });
      if (rule && Number(rule.commissionAmount) > 0) {
        const exists = await prisma.commissionEntry.findFirst({
          where: { requestId: r.id, kind: 'EARNED', status: { not: 'CANCELLED' } },
        });
        if (!exists) {
          await prisma.commissionEntry.create({
            data: {
              agentId: r.agentId,
              serviceKey: 'open_account',
              bankId: r.bankId,
              requestId: r.id,
              amount: rule.commissionAmount,
              currency: rule.currency,
              status: 'PENDING',
            },
          });
          const agent = await prisma.agent.findUnique({ where: { id: r.agentId } });
          if (agent?.userId) {
            await notifyUsers([agent.userId], {
              title: 'استحقاق عمولة',
              body: `تم تسجيل عمولة مستحقة بقيمة ${Number(rule.commissionAmount)} ${rule.currency} عن الطلب ${r.reference} (بانتظار الاعتماد).`,
              type: 'commission_pending',
              iconKey: 'coins',
              entityType: 'AccountRequest',
              entityId: id,
            });
          }
        }
      }
    }

    res.json({
      ok: true,
      status: updated.status,
      statusLabel: STATUS_LABEL[updated.status],
      message: 'تم تحديث حالة الطلب.',
    });
  })
);

router.get(
  '/:id/history',
  requirePermission(P.REQUESTS_VIEW),
  asyncHandler(async (req, res) => {
    const rows = await prisma.accountRequestStatusHistory.findMany({
      where: { requestId: Number(req.params.id) },
      orderBy: { createdAt: 'asc' },
    });
    res.json(rows.map((h) => ({ ...h, toStatusLabel: STATUS_LABEL[h.toStatus] || h.toStatus })));
  })
);

router.get(
  '/:id/receipt',
  requirePermission(P.REQUESTS_VIEW),
  asyncHandler(async (req, res) => {
    const r = await prisma.accountRequest.findUnique({
      where: { id: Number(req.params.id) },
      include: { customer: true, bank: true, agent: true },
    });
    if (!r) throw new HttpError(404, 'الطلب غير موجود.');
    res.json({
      receiptNo: r.receiptNo,
      reference: r.reference,
      bank: r.bank.nameAr,
      customer: r.customer.fullName4,
      agent: r.agent ? `${r.agent.fullName4} (${r.agent.code})` : null,
      accountType: r.accountType,
      status: STATUS_LABEL[r.status],
      submittedAt: r.submittedAt,
      issuedAt: new Date().toISOString(),
      organization: 'السوبر البنكي الداخلي — SUPER BANKING',
      note: 'هذا إيصال استلام طلب فقط، وليس تأكيدًا بفتح الحساب. يُعتمد فتح الحساب بناءً على نتيجة الجهة المصرفية.',
    });
  })
);

module.exports = router;
module.exports.STATUS_LABEL = STATUS_LABEL;
module.exports.ALLOWED_TRANSITIONS = ALLOWED_TRANSITIONS;
