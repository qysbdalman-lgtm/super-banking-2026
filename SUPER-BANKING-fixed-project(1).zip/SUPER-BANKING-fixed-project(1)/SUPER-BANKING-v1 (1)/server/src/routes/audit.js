const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { asyncHandler } = require('../middleware/error');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

/** سجل التدقيق — للقراءة فقط، لا توجد واجهة تعديل أو حذف */
router.get(
  '/',
  requirePermission(P.AUDIT_VIEW),
  asyncHandler(async (req, res) => {
    const { entityType, entityId, actorId, action, from, to, page = 1, pageSize = 50 } = req.query;
    const where = {};
    if (entityType) where.entityType = entityType;
    if (entityId) where.entityId = String(entityId);
    if (actorId) where.actorId = Number(actorId);
    if (action) where.action = { contains: action, mode: 'insensitive' };
    if (from || to) {
      where.createdAt = {};
      if (from) where.createdAt.gte = new Date(from);
      if (to) where.createdAt.lte = new Date(`${to}T23:59:59`);
    }
    const take = Math.min(Number(pageSize), 200);
    const skip = (Math.max(Number(page), 1) - 1) * take;
    const [items, total] = await Promise.all([
      prisma.auditLog.findMany({ where, orderBy: { createdAt: 'desc' }, skip, take }),
      prisma.auditLog.count({ where }),
    ]);
    res.json({ items, total, page: Number(page), pageSize: take });
  })
);

router.get(
  '/login-attempts',
  requirePermission(P.LOGIN_ATTEMPTS_VIEW),
  asyncHandler(async (req, res) => {
    const { identifier, success, page = 1, pageSize = 50 } = req.query;
    const where = {};
    if (identifier) where.identifier = { contains: identifier };
    if (success === 'true') where.success = true;
    if (success === 'false') where.success = false;
    const take = Math.min(Number(pageSize), 200);
    const skip = (Math.max(Number(page), 1) - 1) * take;
    const [items, total, failed24h] = await Promise.all([
      prisma.loginAttempt.findMany({ where, orderBy: { createdAt: 'desc' }, skip, take }),
      prisma.loginAttempt.count({ where }),
      prisma.loginAttempt.count({ where: { success: false, createdAt: { gte: new Date(Date.now() - 86400000) } } }),
    ]);
    res.json({ items, total, failed24h, page: Number(page), pageSize: take });
  })
);

router.get(
  '/document-access',
  requirePermission(P.AUDIT_VIEW, P.DOCUMENTS_VIEW),
  asyncHandler(async (req, res) => {
    const rows = await prisma.documentAccessLog.findMany({ orderBy: { createdAt: 'desc' }, take: 200 });
    res.json(rows);
  })
);

module.exports = router;
