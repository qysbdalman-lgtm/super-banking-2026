const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { validate, schemas } = require('../middleware/validate');
const { asyncHandler, HttpError } = require('../middleware/error');
const { audit } = require('../services/audit');
const { notifyUsers, usersWithPermission } = require('../services/notify');
const { nextReference } = require('../utils/reference');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

const T_LABEL = {
  NEW: 'جديد', UNDER_REVIEW: 'قيد المراجعة', IN_PROGRESS: 'قيد المعالجة',
  WAITING_INFO: 'بانتظار معلومات إضافية', RESOLVED: 'تم الحل', CLOSED: 'مغلق',
};

function scope(user) {
  if (user.roleKey === 'AGENT_GOLD' || user.roleKey === 'AGENT_SILVER') return { agentId: user.agentId ?? -1 };
  return {};
}

router.get(
  '/',
  requirePermission(P.TICKETS_VIEW),
  asyncHandler(async (req, res) => {
    const { status, priority, bankId, q, page = 1, pageSize = 25 } = req.query;
    const where = { ...scope(req.user) };
    if (status) where.status = status;
    if (priority) where.priority = priority;
    if (bankId) where.bankId = Number(bankId);
    if (q) where.OR = [{ reference: { contains: q, mode: 'insensitive' } }, { subject: { contains: q, mode: 'insensitive' } }];
    const take = Math.min(Number(pageSize), 100);
    const skip = (Math.max(Number(page), 1) - 1) * take;
    const [items, total] = await Promise.all([
      prisma.ticket.findMany({
        where, orderBy: { createdAt: 'desc' }, skip, take,
        include: {
          bank: { select: { id: true, nameAr: true } },
          agent: { select: { id: true, code: true, fullName4: true } },
          _count: { select: { messages: true } },
        },
      }),
      prisma.ticket.count({ where }),
    ]);
    res.json({
      items: items.map((t) => ({ ...t, statusLabel: T_LABEL[t.status] })),
      total, page: Number(page), pageSize: take,
      statuses: Object.entries(T_LABEL).map(([key, label]) => ({ key, label })),
    });
  })
);

router.get(
  '/:id',
  requirePermission(P.TICKETS_VIEW),
  asyncHandler(async (req, res) => {
    const t = await prisma.ticket.findUnique({
      where: { id: Number(req.params.id) },
      include: {
        bank: true,
        agent: { select: { id: true, code: true, fullName4: true } },
        attachment: { select: { id: true, originalName: true, mimeType: true, size: true } },
        messages: { orderBy: { createdAt: 'asc' } },
      },
    });
    if (!t) throw new HttpError(404, 'البلاغ غير موجود.');
    if ((req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER') && t.agentId !== req.user.agentId) {
      throw new HttpError(403, 'غير مصرح.');
    }
    res.json({ ...t, statusLabel: T_LABEL[t.status] });
  })
);

router.post(
  '/',
  requirePermission(P.TICKETS_CREATE),
  validate(schemas.ticket),
  asyncHandler(async (req, res) => {
    const d = req.body;
    const agentId =
      req.user.roleKey === 'AGENT_GOLD' || req.user.roleKey === 'AGENT_SILVER' ? req.user.agentId : req.body.agentId || null;
    const reference = await nextReference('TICKET');
    const t = await prisma.ticket.create({
      data: {
        reference,
        subject: d.subject,
        description: d.description,
        bankId: d.bankId || null,
        serviceKey: d.serviceKey || null,
        priority: d.priority || 'عادية',
        operationRef: d.operationRef || null,
        attachmentId: d.attachmentId || null,
        agentId,
        createdById: req.user.id,
      },
    });
    await audit(req, { action: 'create_ticket', entityType: 'Ticket', entityId: t.id, after: { reference } });
    const support = await usersWithPermission(P.TICKETS_MANAGE);
    if (support.length) {
      await notifyUsers(support, {
        title: 'بلاغ فني جديد',
        body: `${d.subject} — المرجع ${reference} (الأولوية: ${t.priority}).`,
        type: 'ticket_new',
        iconKey: 'life-buoy',
        bankId: t.bankId,
        entityType: 'Ticket',
        entityId: t.id,
      });
    }
    res.status(201).json({ ok: true, id: t.id, reference, statusLabel: T_LABEL[t.status], message: 'تم إرسال البلاغ الفني.' });
  })
);

router.post(
  '/:id/reply',
  requirePermission(P.TICKETS_MANAGE, P.TICKETS_CREATE),
  validate(schemas.ticketReply),
  asyncHandler(async (req, res) => {
    const id = Number(req.params.id);
    const t = await prisma.ticket.findUnique({ where: { id } });
    if (!t) throw new HttpError(404, 'البلاغ غير موجود.');
    const isStaff = req.user.roleKey !== 'AGENT_GOLD' && req.user.roleKey !== 'AGENT_SILVER';
    if (!isStaff && t.agentId !== req.user.agentId) throw new HttpError(403, 'غير مصرح.');
    if (!isStaff && req.body.status) throw new HttpError(403, 'تغيير حالة البلاغ متاح للدعم الفني فقط.');

    const msg = await prisma.ticketMessage.create({
      data: { ticketId: id, senderId: req.user.id, senderName: req.user.fullName, body: req.body.body },
    });
    if (req.body.status && isStaff) {
      await prisma.ticket.update({ where: { id }, data: { status: req.body.status, assignedToId: req.user.id } });
      if (t.agentId) {
        const agent = await prisma.agent.findUnique({ where: { id: t.agentId } });
        if (agent?.userId) {
          await notifyUsers([agent.userId], {
            title: 'تحديث حالة البلاغ الفني',
            body: `البلاغ ${t.reference}: ${T_LABEL[req.body.status]}.`,
            type: 'ticket_status',
            iconKey: 'life-buoy',
            entityType: 'Ticket',
            entityId: id,
          });
        }
      }
    }
    await audit(req, { action: 'reply_ticket', entityType: 'Ticket', entityId: id });
    res.status(201).json({ ok: true, id: msg.id });
  })
);

module.exports = router;
module.exports.T_LABEL = T_LABEL;
