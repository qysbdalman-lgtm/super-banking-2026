const express = require('express');
const bcrypt = require('bcryptjs');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { attachScope } = require('../scope');
const { validate, schemas } = require('../middleware/validate');
const { audit } = require('../services/audit');
const { notifyUsers } = require('../services/notify');

const r = express.Router();
r.use(authenticate, attachScope);

const sel = {
  id: true, username: true, phone: true, email: true, fullName: true, status: true,
  mustChangePassword: true, mfaEnabled: true, lastLoginAt: true, lastLoginIp: true,
  governorate: true, district: true, createdAt: true,
  role: { select: { key: true, nameAr: true } },
  agent: { select: { id: true, code: true, status: true, type: true } },
};

r.get('/', requirePermission('users.view'), async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    const rows = await prisma.user.findMany({
      where: q ? { OR: [{ username: { contains: q, mode: 'insensitive' } }, { fullName: { contains: q } }, { phone: { contains: q } }] } : {},
      orderBy: { id: 'desc' },
      select: sel,
      take: 300,
    });
    res.json(rows.map((u) => ({ ...u, roleKey: u.role.key, roleName: u.role.nameAr, agentCode: u.agent?.code || null })));
  } catch (e) {
    next(e);
  }
});

r.get('/roles', requirePermission('roles.manage', 'users.manage'), async (req, res, next) => {
  try {
    const rows = await prisma.role.findMany({
      orderBy: { id: 'asc' },
      include: { permissions: { include: { permission: true } }, _count: { select: { users: true } } },
    });
    res.json(
      rows.map((x) => ({
        id: x.id, key: x.key, nameAr: x.nameAr, description: x.description, isSystem: x.isSystem,
        usersCount: x._count.users,
        permissions: x.permissions.map((p) => p.permission.key),
      }))
    );
  } catch (e) {
    next(e);
  }
});

r.get('/permissions', requirePermission('roles.manage'), async (req, res, next) => {
  try {
    res.json(await prisma.permission.findMany({ orderBy: [{ category: 'asc' }, { key: 'asc' }] }));
  } catch (e) {
    next(e);
  }
});

r.put('/roles/:id/permissions', requirePermission('roles.manage'), async (req, res, next) => {
  try {
    const role = await prisma.role.findUnique({ where: { id: Number(req.params.id) } });
    if (!role) return res.status(404).json({ error: 'الدور غير موجود.' });
    if (role.key === 'OWNER') return res.status(400).json({ error: 'لا يمكن تعديل صلاحيات مالك النظام.' });
    const keys = Array.isArray(req.body.keys) ? req.body.keys : [];
    const perms = await prisma.permission.findMany({ where: { key: { in: keys } } });
    await prisma.$transaction([
      prisma.rolePermission.deleteMany({ where: { roleId: role.id } }),
      prisma.rolePermission.createMany({ data: perms.map((p) => ({ roleId: role.id, permissionId: p.id })) }),
    ]);
    await audit(req, { action: 'ROLE_PERMISSIONS_UPDATE', entityType: 'Role', entityId: role.id, after: { keys: perms.map((p) => p.key) } });
    res.json({ ok: true, count: perms.length });
  } catch (e) {
    next(e);
  }
});

r.post('/', requirePermission('users.manage'), validate(schemas.userCreate), async (req, res, next) => {
  try {
    const d = req.body;
    if (d.roleKey === 'OWNER') return res.status(400).json({ error: 'لا يُنشأ مالك نظام إضافي من الواجهة.' });
    const role = await prisma.role.findUnique({ where: { key: d.roleKey } });
    if (!role) return res.status(400).json({ error: 'الدور غير معروف.' });
    const dup = await prisma.user.findFirst({ where: { OR: [{ username: d.username }, ...(d.phone ? [{ phone: d.phone }] : [])] } });
    if (dup) return res.status(409).json({ error: 'اسم المستخدم أو الهاتف مستخدم مسبقًا.' });
    let agentId = d.agentId || null;
    if (agentId) {
      const ag = await prisma.agent.findUnique({ where: { id: agentId } });
      if (!ag) return res.status(400).json({ error: 'ملف الوكيل غير موجود.' });
      if (ag.userId) return res.status(409).json({ error: 'ملف الوكيل مرتبط بحساب آخر.' });
    }
    const passwordHash = await bcrypt.hash(d.password, 10);
    const user = await prisma.user.create({
      data: {
        username: d.username, fullName: d.fullName, phone: d.phone || null, email: d.email || null,
        roleId: role.id, passwordHash, status: 'ACTIVE', mustChangePassword: true,
        governorate: d.governorate || null, district: d.district || null, createdById: req.user.id,
      },
    });
    if (agentId) await prisma.agent.update({ where: { id: agentId }, data: { userId: user.id } });
    await audit(req, { action: 'USER_CREATE', entityType: 'User', entityId: user.id, after: { username: user.username, roleKey: role.key } });
    res.status(201).json({ id: user.id, username: user.username, mustChangePassword: true });
  } catch (e) {
    next(e);
  }
});

r.patch('/:id', requirePermission('users.manage'), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const before = await prisma.user.findUnique({ where: { id } });
    if (!before) return res.status(404).json({ error: 'المستخدم غير موجود.' });
    const data = {};
    for (const k of ['fullName', 'phone', 'email', 'governorate', 'district']) if (k in req.body) data[k] = req.body[k] || null;
    if (req.body.roleKey) {
      const role = await prisma.role.findUnique({ where: { key: req.body.roleKey } });
      if (!role) return res.status(400).json({ error: 'الدور غير معروف.' });
      data.roleId = role.id;
    }
    const user = await prisma.user.update({ where: { id }, data });
    await audit(req, { action: 'USER_UPDATE', entityType: 'User', entityId: id, before: { fullName: before.fullName }, after: data });
    res.json({ id: user.id });
  } catch (e) {
    next(e);
  }
});

r.post('/:id/status', requirePermission('users.manage'), validate(schemas.userStatus), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const u = await prisma.user.findUnique({ where: { id }, include: { role: true } });
    if (!u) return res.status(404).json({ error: 'المستخدم غير موجود.' });
    if (u.role.key === 'OWNER' && req.user.roleKey !== 'OWNER') return res.status(403).json({ error: 'لا يمكن تعديل حالة مالك النظام.' });
    if (u.id === req.user.id && req.body.status !== 'ACTIVE') return res.status(400).json({ error: 'لا يمكنك إيقاف حسابك الحالي.' });
    await prisma.user.update({ where: { id }, data: { status: req.body.status } });
    if (req.body.status !== 'ACTIVE')
      await prisma.session.updateMany({ where: { userId: id, revokedAt: null }, data: { revokedAt: new Date() } });
    await notifyUsers([id], {
      title: req.body.status === 'ACTIVE' ? 'إعادة تفعيل الحساب' : 'تحديث حالة الحساب',
      body: req.body.status === 'ACTIVE' ? 'تم إعادة تفعيل حسابك.' : 'تم تغيير حالة حسابك. راجع الإدارة.',
      type: 'account', iconKey: 'shield',
    });
    await audit(req, { action: 'USER_STATUS', entityType: 'User', entityId: id, before: { status: u.status }, after: { status: req.body.status, reason: req.body.reason } });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

module.exports = r;
