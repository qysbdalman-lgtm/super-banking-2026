const express = require('express');
const { z } = require('zod');
const { prisma } = require('../db');
const { validate, schemas } = require('../middleware/validate');
const { loginLimiter } = require('../middleware/rateLimit');
const { nextReference } = require('../utils/reference');
const { notifyUsers, adminUserIds } = require('../services/notify');
const { audit } = require('../services/audit');

/**
 * نقاط عامة (بدون تسجيل دخول) — محصورة في تقديم طلب الانضمام لشبكة الوكلاء
 * والاستعلام عن حالة الطلب بالرقم المرجعي فقط، دون كشف أي بيانات حساسة.
 */
const r = express.Router();

r.post('/agent', loginLimiter, validate(schemas.agentApply), async (req, res, next) => {
  try {
    const d = req.body;
    const dup = await prisma.agent.findFirst({
      where: { OR: [{ nationalId: d.nationalId }, { phone: d.phone }] },
    });
    if (dup) {
      return res.status(409).json({
        error:
          'يوجد طلب مسجَّل مسبقًا بنفس رقم البطاقة أو رقم الهاتف. للاستعلام استخدم رقم الطلب أو راجع الإدارة.',
      });
    }
    const code = await nextReference('AGENT');
    const agent = await prisma.agent.create({
      data: {
        code,
        fullName4: d.fullName4,
        nationalId: d.nationalId,
        phone: d.phone,
        whatsapp: d.whatsapp || null,
        governorate: d.governorate,
        district: d.district,
        area: d.area || null,
        address: d.address || null,
        businessName: d.businessName || null,
        businessType: d.businessType || null,
        guarantorName: d.guarantorName || null,
        guarantorPhone: d.guarantorPhone || null,
        guarantorId: d.guarantorId || null,
        notes: d.notes || null,
        type: d.type || 'SILVER',
        status: 'NEW',
      },
    });
    await notifyUsers(await adminUserIds(), {
      title: 'طلب انضمام وكيل جديد',
      body: `ورد طلب وكالة جديد بالرقم ${code}. يلزم المراجعة والاعتماد قبل منح أي صلاحية خدمة.`,
      type: 'agent',
      iconKey: 'agents',
      entityType: 'Agent',
      entityId: agent.id,
    });
    await audit({ user: null, ip: req.ip, headers: req.headers }, {
      action: 'AGENT_APPLICATION_PUBLIC',
      entityType: 'Agent',
      entityId: agent.id,
      after: { code },
    });
    res.status(201).json({
      id: agent.id,
      code,
      reference: code,
      status: 'NEW',
      message:
        'تم استلام طلبك. لا تُمنح أي صلاحيات خدمة قبل اعتماد الإدارة وتحديد الخدمات المسموح بها. احتفظ بالرقم المرجعي للمتابعة.',
    });
  } catch (e) {
    next(e);
  }
});

r.get('/agent/:code', async (req, res, next) => {
  try {
    const agent = await prisma.agent.findUnique({
      where: { code: req.params.code },
      select: { code: true, status: true, type: true, appliedAt: true, approvedAt: true, rejectReason: true },
    });
    if (!agent) return res.status(404).json({ error: 'لا يوجد طلب بهذا الرقم المرجعي.' });
    const LABEL = {
      NEW: 'طلب جديد', UNDER_REVIEW: 'قيد المراجعة', NEEDS_INFO: 'مطلوب استكمال بيانات',
      APPROVED: 'مقبول', REJECTED: 'مرفوض', SUSPENDED: 'موقوف مؤقتًا', CANCELLED: 'ملغى',
    };
    res.json({ ...agent, statusLabel: LABEL[agent.status] || agent.status });
  } catch (e) {
    next(e);
  }
});

module.exports = r;
module.exports.schema = z;
