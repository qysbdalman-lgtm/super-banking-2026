const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { attachScope } = require('../scope');

const r = express.Router();
r.use(authenticate, attachScope);

r.get('/', requirePermission('dashboard.view'), async (req, res, next) => {
  try {
    const ag = req.scope.agentId;
    const sc = ag ? { agentId: ag } : {};
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const [
      agentsTotal, agentsActive, agentsSuspended, agentsPending,
      customersTotal, requestsToday, requestsTotal, transfersTotal,
      reqGroups, trGroups, commissionsDue, commissionsPaid,
      recentAudit, recentNotifications, circulars, banks, maintBanks, errCount,
    ] = await Promise.all([
      prisma.agent.count(ag ? { where: { id: ag } } : {}),
      prisma.agent.count(ag ? { where: { id: ag, status: 'APPROVED' } } : { where: { status: 'APPROVED' } }),
      prisma.agent.count(ag ? { where: { id: ag, status: 'SUSPENDED' } } : { where: { status: 'SUSPENDED' } }),
      prisma.agent.count(ag ? { where: { id: ag, status: { in: ['NEW', 'UNDER_REVIEW', 'NEEDS_INFO'] } } } : { where: { status: { in: ['NEW', 'UNDER_REVIEW', 'NEEDS_INFO'] } } }),
      prisma.customer.count(ag ? { where: { agentId: ag } } : {}),
      prisma.accountRequest.count({ where: { ...sc, createdAt: { gte: todayStart } } }),
      prisma.accountRequest.count({ where: sc }),
      prisma.transfer.count({ where: sc }),
      prisma.accountRequest.groupBy({ by: ['status'], _count: { _all: true }, where: sc }),
      prisma.transfer.groupBy({ by: ['status'], _count: { _all: true }, where: sc }),
      prisma.commissionEntry.aggregate({ where: { ...(ag ? { agentId: ag } : {}), status: { in: ['PENDING', 'APPROVED'] } }, _sum: { amount: true } }),
      prisma.commissionEntry.aggregate({ where: { ...(ag ? { agentId: ag } : {}), status: 'PAID' }, _sum: { amount: true } }),
      prisma.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 10, select: { id: true, actorName: true, action: true, entityType: true, entityId: true, createdAt: true } }),
      prisma.notification.findMany({ where: { userId: req.user.id }, orderBy: { createdAt: 'desc' }, take: 5 }),
      prisma.circular.findMany({ where: { isActive: true }, orderBy: { publishedAt: 'desc' }, take: 3 }),
      prisma.bank.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' }, select: { id: true, code: true, nameAr: true, nameEn: true, integrationStatus: true, iconKey: true, lastError: true } }),
      prisma.bank.count({ where: { isActive: true, integrationStatus: { in: ['MAINTENANCE', 'SUSPENDED'] } } }),
      prisma.integrationLog.count({ where: { success: false, createdAt: { gte: new Date(Date.now() - 7 * 86400000) } } }),
    ]);

    const map = (rows) => Object.fromEntries(rows.map((x) => [x.status, x._count._all]));
    res.json({
      scope: ag ? 'agent' : 'global',
      // ملخص مختصر بأرقام محسوبة من قاعدة البيانات (لا قيم ثابتة)
      stats: {
        agents: agentsTotal,
        customers: customersTotal,
        requests: requestsTotal,
        transfers: transfersTotal,
      },
      agents: { total: agentsTotal, active: agentsActive, suspended: agentsSuspended, pending: agentsPending },
      customers: { total: customersTotal },
      requests: {
        today: requestsToday,
        total: requestsTotal,
        byStatus: map(reqGroups),
        underReview: (map(reqGroups).UNDER_REVIEW || 0) + (map(reqGroups).SUBMITTED || 0),
        approved: (map(reqGroups).BANK_APPROVED || 0) + (map(reqGroups).SENT_TO_BANK || 0),
        completed: map(reqGroups).COMPLETED || 0,
        rejected: map(reqGroups).REJECTED || 0,
        needsInfo: map(reqGroups).NEEDS_INFO || 0,
      },
      transfers: { total: transfersTotal, byStatus: map(trGroups) },
      commissions: { due: Number(commissionsDue._sum.amount || 0), paid: Number(commissionsPaid._sum.amount || 0) },
      recentAudit,
      recentNotifications,
      circulars,
      banks,
      alerts: { maintenanceBanks: maintBanks, integrationErrors7d: errCount },
    });
  } catch (e) {
    next(e);
  }
});

module.exports = r;
