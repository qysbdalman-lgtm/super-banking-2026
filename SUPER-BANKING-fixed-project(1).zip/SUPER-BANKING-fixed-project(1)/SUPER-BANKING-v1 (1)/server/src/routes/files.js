const express = require('express');
const fs = require('fs');
const path = require('path');
const { prisma } = require('../db');
const config = require('../config');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { upload } = require('../middleware/upload');
const { asyncHandler, HttpError } = require('../middleware/error');
const { audit } = require('../services/audit');
const { sha256 } = require('../utils/crypto');
const { PERMISSIONS: P } = require('../constants/permissions');

const router = express.Router();
router.use(authenticate);

const safePath = (storageKey) => {
  const full = path.resolve(config.privateStorageDir, storageKey);
  if (!full.startsWith(path.resolve(config.privateStorageDir))) throw new HttpError(400, 'مسار غير صالح.');
  return full;
};

/** رفع مستند خاص (هوية/وثيقة داعمة) — يُخزَّن خارج أي مجلد عام */
router.post(
  '/upload',
  requirePermission(P.DOCUMENTS_VIEW),
  upload.single('file'),
  asyncHandler(async (req, res) => {
    if (!req.file) throw new HttpError(400, 'لم يتم إرفاق أي ملف.');
    const buf = fs.readFileSync(req.file.path);
    const doc = await prisma.documentFile.create({
      data: {
        storageKey: path.join(req._storageSub || '', req.file.filename),
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
        sha256: sha256(buf),
        isPrivate: true,
        uploadedById: req.user.id,
      },
    });
    await audit(req, {
      action: 'upload_document', entityType: 'DocumentFile', entityId: doc.id,
      after: { name: req.file.originalname, size: req.file.size },
    });
    res.status(201).json({
      ok: true, id: doc.id, originalName: doc.originalName,
      mimeType: doc.mimeType, size: doc.size,
      message: 'تم رفع المستند وحفظه في تخزين خاص.',
    });
  })
);

/** ربط مستند بطلب فتح حساب */
router.post(
  '/link/:requestId',
  requirePermission(P.DOCUMENTS_VIEW),
  asyncHandler(async (req, res) => {
    const requestId = Number(req.params.requestId);
    const { fileId, docType } = req.body;
    if (!fileId || !docType) throw new HttpError(400, 'الملف ونوع المستند مطلوبان.');
    const reqRow = await prisma.accountRequest.findUnique({ where: { id: requestId } });
    if (!reqRow) throw new HttpError(404, 'الطلب غير موجود.');
    const row = await prisma.accountRequestDocument.upsert({
      where: { requestId_docType: { requestId, docType } },
      create: { requestId, docType, fileId, uploadedById: req.user.id },
      update: { fileId, uploadedById: req.user.id },
    });
    await audit(req, { action: 'link_document', entityType: 'AccountRequest', entityId: requestId, after: { docType } });
    res.json({ ok: true, id: row.id, message: 'تم ربط المستند بالطلب.' });
  })
);

/**
 * تنزيل مستند خاص — لا يوجد أي رابط عام لصور الهويات.
 * الوصول يمرّ عبر هذا المسار المحمي بالصلاحيات ويُسجَّل في سجل الاطلاع.
 */
router.get(
  '/:id/download',
  requirePermission(P.DOCUMENTS_DOWNLOAD, P.DOCUMENTS_VIEW),
  asyncHandler(async (req, res) => {
    const doc = await prisma.documentFile.findUnique({ where: { id: req.params.id } });
    if (!doc) throw new HttpError(404, 'المستند غير موجود.');
    const full = safePath(doc.storageKey);
    if (!fs.existsSync(full)) throw new HttpError(410, 'الملف غير متوفر في التخزين.');

    await prisma.documentAccessLog.create({
      data: { fileId: doc.id, userId: req.user.id, userName: req.user.fullName, action: 'download', ip: req.ip },
    });
    await audit(req, { action: 'download_document', entityType: 'DocumentFile', entityId: doc.id });

    res.setHeader('Content-Type', doc.mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(doc.originalName)}"`);
    res.setHeader('Cache-Control', 'no-store, private');
    fs.createReadStream(full).pipe(res);
  })
);

router.get(
  '/:id',
  requirePermission(P.DOCUMENTS_VIEW),
  asyncHandler(async (req, res) => {
    const doc = await prisma.documentFile.findUnique({ where: { id: req.params.id } });
    if (!doc) throw new HttpError(404, 'المستند غير موجود.');
    res.json({ id: doc.id, originalName: doc.originalName, mimeType: doc.mimeType, size: doc.size, createdAt: doc.createdAt });
  })
);

module.exports = router;
