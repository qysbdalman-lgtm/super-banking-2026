const express = require('express');
const { prisma } = require('../db');
const { authenticate } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { attachScope } = require('../scope');
const { audit } = require('../services/audit');

const r = express.Router();
r.use(authenticate, attachScope);

r.get('/', requirePermission('banks.view'), async (req, res, next) => {
  try {
    const rows = await prisma.service.findMany({
      orderBy: { sortOrder: 'asc' },
      include: { banks: { select: { bankId: true, enabled: true, feeAmount: true, commissionAmount: true } } },
    });
    res.json(
      rows.map((s) => ({
        id: s.id, key: s.key, nameAr: s.nameAr, description: s.description, category: s.category,
        iconKey: s.iconKey, requiresIntegration: s.requiresIntegration, isActive: s.isActive, sortOrder: s.sortOrder,
        banksCount: s.banks.length, enabledBanks: s.banks.filter((b) => b.enabled).length,
      }))
    );
  } catch (e) {
    next(e);
  }
});

r.post('/', requirePermission('services.manage'), async (req, res, next) => {
  try {
    const d = req.body;
    if (!d.key || !d.nameAr) return res.status(400).json({ error: 'المفتاح والاسم مطلوبان.' });
    const s = await prisma.service.upsert({
      where: { key: d.key },
      create: { key: d.key, nameAr: d.nameAr, description: d.description || null, category: d.category || 'general', iconKey: d.iconKey || 'service', requiresIntegration: d.requiresIntegration !== false, sortOrder: d.sortOrder || 100 },
      update: { nameAr: d.nameAr, description: d.description || null, category: d.category, iconKey: d.iconKey, isActive: d.isActive !== false, sortOrder: d.sortOrder },
    });
    await audit(req, { action: 'SERVICE_UPSERT', entityType: 'Service', entityId: s.id, after: { key: s.key } });
    res.status(201).json(s);
  } catch (e) {
    next(e);
  }
});

r.patch('/:id', requirePermission('services.manage'), async (req, res, next) => {
  try {
    const data = {};
    for (const k of ['nameAr', 'description', 'category', 'iconKey', 'isActive', 'sortOrder', 'requiresIntegration'])
      if (k in req.body) data[k] = req.body[k];
    const s = await prisma.service.update({ where: { id: Number(req.params.id) }, data });
    await audit(req, { action: 'SERVICE_UPDATE', entityType: 'Service', entityId: s.id, after: data });
    res.json(s);
  } catch (e) {
    next(e);
  }
});

module.exports = r;
