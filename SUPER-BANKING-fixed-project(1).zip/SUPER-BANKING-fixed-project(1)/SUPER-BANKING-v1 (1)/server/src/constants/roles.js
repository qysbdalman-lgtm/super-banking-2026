const { PERMISSIONS: P, ALL_PERMISSIONS } = require('./permissions');

/**
 * الأدوار الثلاثة عشر المطلوبة في المواصفات، مع الصلاحيات المناسبة لكل دور.
 * ملاحظة أمنية: الوكيل (ذهبي/فضي) لا يملك صلاحية عرض الوكلاء الآخرين
 * ولا التقارير المالية العامة، إلا إذا مُنح صلاحية صريحة لاحقًا من الإدارة.
 */
const ROLES = [
  {
    key: 'OWNER',
    nameAr: 'مالك النظام',
    description: 'صلاحيات كاملة على النظام وإدارة المستخدمين والإعدادات',
    permissions: ALL_PERMISSIONS,
  },
  {
    key: 'GM',
    nameAr: 'مدير الإدارة العامة',
    description: 'إدارة العمليات والوكلاء والطلبات والتقارير',
    permissions: [
      P.DASHBOARD_VIEW, P.REPORTS_VIEW, P.REPORTS_EXPORT,
      P.USERS_VIEW, P.AGENTS_VIEW, P.AGENTS_VIEW_ALL, P.AGENTS_CREATE, P.AGENTS_REVIEW,
      P.AGENTS_SUSPEND, P.AGENTS_SET_SERVICES, P.AGENTS_SET_TYPE, P.AGENTS_SETTLEMENTS_VIEW,
      P.CONTRACTS_VIEW, P.CONTRACTS_MANAGE, P.DOCUMENTS_VIEW, P.DOCUMENTS_DOWNLOAD,
      P.CUSTOMERS_VIEW, P.CUSTOMERS_VIEW_SENSITIVE, P.CUSTOMERS_CREATE, P.CUSTOMERS_UPDATE,
      P.REQUESTS_VIEW, P.REQUESTS_CREATE, P.REQUESTS_REVIEW, P.REQUESTS_APPROVE, P.REQUESTS_CHANGE_STATUS,
      P.TRANSFERS_VIEW, P.TRANSFERS_CREATE, P.TRANSFERS_PROCESS, P.TRANSFERS_CANCEL,
      P.FINANCE_VIEW, P.FINANCE_MANAGE, P.COMMISSIONS_APPROVE, P.SETTLEMENTS_MANAGE,
      P.BANKS_VIEW, P.BANKS_MANAGE, P.SERVICES_MANAGE,
      P.NOTIFICATIONS_VIEW, P.NOTIFICATIONS_SEND, P.CIRCULARS_VIEW, P.CIRCULARS_MANAGE,
      P.TICKETS_VIEW, P.TICKETS_CREATE, P.TICKETS_MANAGE,
      P.AUDIT_VIEW, P.LOGIN_ATTEMPTS_VIEW,
    ],
  },
  {
    key: 'TECH_ADMIN',
    nameAr: 'مدير النظام التقني',
    description: 'إدارة الربط التقني والخدمات وإعدادات النظام ومتابعة الأعطال',
    permissions: [
      P.DASHBOARD_VIEW, P.REPORTS_VIEW, P.REPORTS_EXPORT,
      P.USERS_VIEW, P.BANKS_VIEW, P.BANKS_MANAGE, P.BANKS_INTEGRATION_MANAGE, P.SERVICES_MANAGE,
      P.SYSTEM_MAINTENANCE, P.SETTINGS_MANAGE,
      P.NOTIFICATIONS_VIEW, P.NOTIFICATIONS_SEND, P.CIRCULARS_VIEW,
      P.TICKETS_VIEW, P.TICKETS_MANAGE,
      P.AUDIT_VIEW, P.LOGIN_ATTEMPTS_VIEW, P.TRANSFERS_VIEW,
    ],
  },
  {
    key: 'AGENT_OFFICER',
    nameAr: 'موظف إدارة الوكلاء',
    description: 'متابعة ملفات الوكلاء والعقود والوثائق',
    permissions: [
      P.DASHBOARD_VIEW, P.AGENTS_VIEW, P.AGENTS_VIEW_ALL, P.AGENTS_CREATE, P.AGENTS_REVIEW,
      P.AGENTS_SET_SERVICES, P.AGENTS_SET_TYPE, P.AGENTS_SETTLEMENTS_VIEW,
      P.CONTRACTS_VIEW, P.CONTRACTS_MANAGE, P.DOCUMENTS_VIEW, P.DOCUMENTS_DOWNLOAD,
      P.NOTIFICATIONS_VIEW, P.CIRCULARS_VIEW, P.TICKETS_VIEW, P.REPORTS_VIEW,
    ],
  },
  {
    key: 'ACCOUNT_OFFICER',
    nameAr: 'موظف فتح الحسابات',
    description: 'تسجيل العملاء وإنشاء طلبات فتح الحسابات ورفع الوثائق',
    permissions: [
      P.DASHBOARD_VIEW, P.CUSTOMERS_VIEW, P.CUSTOMERS_CREATE, P.CUSTOMERS_UPDATE,
      P.REQUESTS_VIEW, P.REQUESTS_CREATE, P.REQUESTS_CHANGE_STATUS,
      P.DOCUMENTS_VIEW, P.BANKS_VIEW, P.AGENTS_VIEW,
      P.NOTIFICATIONS_VIEW, P.CIRCULARS_VIEW, P.TICKETS_CREATE, P.TICKETS_VIEW,
    ],
  },
  {
    key: 'REVIEWER',
    nameAr: 'موظف مراجعة واعتماد الطلبات',
    description: 'مراجعة طلبات فتح الحسابات واعتمادها أو رفضها',
    permissions: [
      P.DASHBOARD_VIEW, P.CUSTOMERS_VIEW, P.CUSTOMERS_VIEW_SENSITIVE,
      P.REQUESTS_VIEW, P.REQUESTS_REVIEW, P.REQUESTS_APPROVE, P.REQUESTS_CHANGE_STATUS,
      P.DOCUMENTS_VIEW, P.DOCUMENTS_DOWNLOAD, P.BANKS_VIEW, P.AGENTS_VIEW, P.AGENTS_VIEW_ALL,
      P.NOTIFICATIONS_VIEW, P.CIRCULARS_VIEW, P.REPORTS_VIEW,
    ],
  },
  {
    key: 'TRANSFER_OFFICER',
    nameAr: 'موظف متابعة الحوالات',
    description: 'إنشاء ومتابعة ومعالجة الحوالات',
    permissions: [
      P.DASHBOARD_VIEW, P.TRANSFERS_VIEW, P.TRANSFERS_CREATE, P.TRANSFERS_PROCESS, P.TRANSFERS_CANCEL,
      P.CUSTOMERS_VIEW, P.BANKS_VIEW, P.AGENTS_VIEW,
      P.NOTIFICATIONS_VIEW, P.CIRCULARS_VIEW, P.REPORTS_VIEW,
    ],
  },
  {
    key: 'AGENT_GOLD',
    nameAr: 'وكيل ذهبي',
    description: 'وكيل معتمد بصلاحيات موسّعة حسب ما تعتمده الإدارة',
    permissions: [
      P.DASHBOARD_VIEW, P.CUSTOMERS_VIEW, P.CUSTOMERS_CREATE, P.CUSTOMERS_UPDATE,
      P.REQUESTS_VIEW, P.REQUESTS_CREATE, P.REQUESTS_CHANGE_STATUS,
      P.DOCUMENTS_VIEW, P.BANKS_VIEW, P.TRANSFERS_VIEW, P.TRANSFERS_CREATE,
      P.FINANCE_VIEW, P.AGENTS_SETTLEMENTS_VIEW,
      P.NOTIFICATIONS_VIEW, P.CIRCULARS_VIEW, P.TICKETS_CREATE, P.TICKETS_VIEW,
      P.REPORTS_VIEW, P.CONTRACTS_VIEW,
    ],
  },
  {
    key: 'AGENT_SILVER',
    nameAr: 'وكيل فضي',
    description: 'تسجيل العملاء وفتح طلبات الحسابات ومتابعة العمولات',
    permissions: [
      P.DASHBOARD_VIEW, P.CUSTOMERS_VIEW, P.CUSTOMERS_CREATE, P.CUSTOMERS_UPDATE,
      P.REQUESTS_VIEW, P.REQUESTS_CREATE, P.REQUESTS_CHANGE_STATUS,
      P.DOCUMENTS_VIEW, P.BANKS_VIEW, P.FINANCE_VIEW,
      P.NOTIFICATIONS_VIEW, P.CIRCULARS_VIEW, P.TICKETS_CREATE, P.TICKETS_VIEW,
      P.CONTRACTS_VIEW,
    ],
  },
  {
    key: 'ACCOUNTANT',
    nameAr: 'موظف محاسبة وتسويات',
    description: 'متابعة العمولات والتسويات والقيود المالية',
    permissions: [
      P.DASHBOARD_VIEW, P.FINANCE_VIEW, P.FINANCE_MANAGE, P.COMMISSIONS_APPROVE, P.COMMISSIONS_PAY,
      P.SETTLEMENTS_MANAGE, P.AGENTS_VIEW, P.AGENTS_VIEW_ALL, P.AGENTS_SETTLEMENTS_VIEW,
      P.REPORTS_VIEW, P.REPORTS_EXPORT, P.TRANSFERS_VIEW,
      P.NOTIFICATIONS_VIEW, P.CIRCULARS_VIEW,
    ],
  },
  {
    key: 'SUPPORT',
    nameAr: 'موظف دعم فني',
    description: 'معالجة البلاغات الفنية ومتابعة المشاكل',
    permissions: [
      P.DASHBOARD_VIEW, P.TICKETS_VIEW, P.TICKETS_MANAGE, P.TICKETS_CREATE,
      P.AGENTS_VIEW, P.BANKS_VIEW, P.CIRCULARS_VIEW, P.CIRCULARS_MANAGE,
      P.NOTIFICATIONS_VIEW, P.NOTIFICATIONS_SEND,
    ],
  },
  {
    key: 'OPS_MONITOR',
    nameAr: 'مراقب عمليات',
    description: 'مراقبة العمليات وسجل النشاط دون تعديل',
    permissions: [
      P.DASHBOARD_VIEW, P.REPORTS_VIEW, P.REPORTS_EXPORT,
      P.AUDIT_VIEW, P.LOGIN_ATTEMPTS_VIEW,
      P.AGENTS_VIEW, P.AGENTS_VIEW_ALL, P.CUSTOMERS_VIEW, P.REQUESTS_VIEW,
      P.TRANSFERS_VIEW, P.FINANCE_VIEW, P.BANKS_VIEW,
      P.NOTIFICATIONS_VIEW, P.CIRCULARS_VIEW, P.TICKETS_VIEW,
    ],
  },
  {
    key: 'CUSTOMER',
    nameAr: 'عميل',
    description: 'بوابة عميل مستقلة (مبدئيًا: متابعة طلباته فقط)',
    permissions: [P.DASHBOARD_VIEW, P.REQUESTS_VIEW, P.NOTIFICATIONS_VIEW, P.CIRCULARS_VIEW],
  },
];

module.exports = { ROLES };
