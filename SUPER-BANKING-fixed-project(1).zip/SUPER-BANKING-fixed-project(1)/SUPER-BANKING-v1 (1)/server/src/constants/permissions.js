/**
 * مفاتيح الصلاحيات. كل صلاحية تُمنح لدور، والدور يُمنح لمستخدم.
 * الواجهة تُخفي الأزرار، والخادم يرفض أي طلب بلا صلاحية (الحماية الفعلية على الخادم).
 */
const PERMISSIONS = {
  // لوحة التحكم والتقارير
  DASHBOARD_VIEW: 'dashboard.view',
  REPORTS_VIEW: 'reports.view',
  REPORTS_EXPORT: 'reports.export',

  // المستخدمون والأدوار
  USERS_VIEW: 'users.view',
  USERS_MANAGE: 'users.manage',
  ROLES_MANAGE: 'roles.manage',

  // الوكلاء
  AGENTS_VIEW: 'agents.view',
  AGENTS_VIEW_ALL: 'agents.view_all',
  AGENTS_CREATE: 'agents.create',
  AGENTS_REVIEW: 'agents.review',
  AGENTS_SUSPEND: 'agents.suspend',
  AGENTS_SET_SERVICES: 'agents.set_services',
  AGENTS_SET_TYPE: 'agents.set_type',
  AGENTS_SETTLEMENTS_VIEW: 'agents.settlements_view',

  // العقود والوثائق
  CONTRACTS_VIEW: 'contracts.view',
  CONTRACTS_MANAGE: 'contracts.manage',
  DOCUMENTS_VIEW: 'documents.view',
  DOCUMENTS_DOWNLOAD: 'documents.download',

  // العملاء
  CUSTOMERS_VIEW: 'customers.view',
  CUSTOMERS_VIEW_SENSITIVE: 'customers.view_sensitive',
  CUSTOMERS_CREATE: 'customers.create',
  CUSTOMERS_UPDATE: 'customers.update',

  // طلبات فتح الحسابات
  REQUESTS_VIEW: 'requests.view',
  REQUESTS_CREATE: 'requests.create',
  REQUESTS_REVIEW: 'requests.review',
  REQUESTS_APPROVE: 'requests.approve',
  REQUESTS_CHANGE_STATUS: 'requests.change_status',

  // الحوالات
  TRANSFERS_VIEW: 'transfers.view',
  TRANSFERS_CREATE: 'transfers.create',
  TRANSFERS_PROCESS: 'transfers.process',
  TRANSFERS_CANCEL: 'transfers.cancel',

  // المحاسبة والعمولات
  FINANCE_VIEW: 'finance.view',
  FINANCE_MANAGE: 'finance.manage',
  COMMISSIONS_APPROVE: 'commissions.approve',
  COMMISSIONS_PAY: 'commissions.pay',
  SETTLEMENTS_MANAGE: 'settlements.manage',

  // البنوك والخدمات
  BANKS_VIEW: 'banks.view',
  BANKS_MANAGE: 'banks.manage',
  BANKS_INTEGRATION_MANAGE: 'banks.integration_manage',
  SERVICES_MANAGE: 'services.manage',

  // الإشعارات والتعاميم
  NOTIFICATIONS_VIEW: 'notifications.view',
  NOTIFICATIONS_SEND: 'notifications.send',
  CIRCULARS_VIEW: 'circulars.view',
  CIRCULARS_MANAGE: 'circulars.manage',

  // الدعم الفني
  TICKETS_VIEW: 'tickets.view',
  TICKETS_CREATE: 'tickets.create',
  TICKETS_MANAGE: 'tickets.manage',

  // التدقيق والإعدادات
  AUDIT_VIEW: 'audit.view',
  LOGIN_ATTEMPTS_VIEW: 'login_attempts.view',
  SETTINGS_MANAGE: 'settings.manage',
  SYSTEM_MAINTENANCE: 'system.maintenance',
};

const ALL_PERMISSIONS = Object.values(PERMISSIONS);

const PERMISSION_LABELS = {
  'dashboard.view': 'عرض لوحة التحكم',
  'reports.view': 'عرض التقارير',
  'reports.export': 'تصدير التقارير',
  'users.view': 'عرض المستخدمين',
  'users.manage': 'إدارة المستخدمين',
  'roles.manage': 'إدارة الأدوار والصلاحيات',
  'agents.view': 'عرض الوكلاء (النطاق المسموح)',
  'agents.view_all': 'عرض جميع الوكلاء',
  'agents.create': 'إنشاء وكيل',
  'agents.review': 'مراجعة طلبات الوكلاء',
  'agents.suspend': 'إيقاف/تعليق وكيل',
  'agents.set_services': 'تحديد خدمات الوكيل',
  'agents.set_type': 'تحديد نوع الوكالة (ذهبي/فضي)',
  'agents.settlements_view': 'عرض تسويات الوكيل',
  'contracts.view': 'عرض العقود',
  'contracts.manage': 'إدارة العقود',
  'documents.view': 'عرض الوثائق',
  'documents.download': 'تنزيل الوثائق',
  'customers.view': 'عرض العملاء',
  'customers.view_sensitive': 'عرض بيانات حساسة (رقم البطاقة)',
  'customers.create': 'تسجيل عميل',
  'customers.update': 'تحديث بيانات العميل',
  'requests.view': 'عرض طلبات فتح الحسابات',
  'requests.create': 'إنشاء طلب فتح حساب',
  'requests.review': 'مراجعة الطلبات',
  'requests.approve': 'اعتماد/رفض الطلبات',
  'requests.change_status': 'تغيير حالة الطلب',
  'transfers.view': 'عرض الحوالات',
  'transfers.create': 'إنشاء حوالة',
  'transfers.process': 'معالجة الحوالات',
  'transfers.cancel': 'إلغاء الحوالات',
  'finance.view': 'عرض المحاسبة والعمولات',
  'finance.manage': 'إدارة القيود المالية',
  'commissions.approve': 'اعتماد العمولات',
  'commissions.pay': 'صرف العمولات',
  'settlements.manage': 'إدارة التسويات',
  'banks.view': 'عرض البنوك والخدمات',
  'banks.manage': 'إدارة البنوك',
  'banks.integration_manage': 'إدارة الربط المصرفي',
  'services.manage': 'إدارة الخدمات والعمولات',
  'notifications.view': 'عرض الإشعارات',
  'notifications.send': 'إرسال الإشعارات',
  'circulars.view': 'عرض التعاميم',
  'circulars.manage': 'إدارة التعاميم',
  'tickets.view': 'عرض البلاغات الفنية',
  'tickets.create': 'إنشاء بلاغ فني',
  'tickets.manage': 'معالجة البلاغات الفنية',
  'audit.view': 'عرض سجل التدقيق',
  'login_attempts.view': 'عرض محاولات الدخول',
  'settings.manage': 'إدارة إعدادات النظام',
  'system.maintenance': 'إيقاف/تشغيل الخدمات',
};

module.exports = { PERMISSIONS, ALL_PERMISSIONS, PERMISSION_LABELS };
