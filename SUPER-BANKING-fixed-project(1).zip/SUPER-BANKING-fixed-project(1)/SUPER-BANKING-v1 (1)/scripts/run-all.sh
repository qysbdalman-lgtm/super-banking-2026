#!/usr/bin/env bash
set -u
ROOT=/home/user/super-banking
cd $ROOT

echo "############ 1. BANKS.TXT (PDF extraction) ############"
sed -n '1,140p' docs/banks.txt 2>/dev/null || echo "no banks.txt"

echo "############ 2. STRUCTURE ############"
echo "-- routes --"; ls server/src/routes 2>/dev/null
echo "-- migrations --"; ls -R server/prisma/migrations 2>/dev/null | head -30 || echo "no migrations dir"
echo "-- README --"; ls -la README.md docs/*.md 2>/dev/null || echo "no README.md"

echo "############ 3. SERVER INSTALL ############"
cd $ROOT/server
npm install --no-audit --no-fund 2>&1 | tail -6

echo "############ 4. PRISMA GENERATE ############"
npx prisma generate 2>&1 | tail -6

echo "############ 5. PRISMA MIGRATE ############"
export DATABASE_URL="postgresql://sb:sbpass@localhost:5432/superbanking?schema=public"
( npx prisma migrate deploy 2>&1 | tail -25 ) || ( echo "-- fallback db push --"; npx prisma db push --accept-data-loss 2>&1 | tail -25 )

echo "############ 6. SEED ############"
node src/cli/seed.js 2>&1 | tail -25

echo "############ 7. SEED DEMO ############"
node src/cli/seed-demo.js 2>&1 | tail -25

echo "############ 8. SERVER TESTS ############"
npx jest --runInBand 2>&1 | tail -70

echo "############ 9. CLIENT INSTALL + BUILD ############"
cd $ROOT/client
npm install --no-audit --no-fund 2>&1 | tail -6
npm run build 2>&1 | tail -35

echo "############ 10. DONE ############"
