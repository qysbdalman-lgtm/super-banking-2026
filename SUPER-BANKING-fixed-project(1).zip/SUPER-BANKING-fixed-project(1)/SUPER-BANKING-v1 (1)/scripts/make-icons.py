from PIL import Image, ImageDraw
import os
SRC = "/home/user/super-banking/brand/logo.png"
OUT = "/home/user/super-banking/client/public/icons"
RES = "/home/user/super-banking/client/resources"
os.makedirs(OUT, exist_ok=True); os.makedirs(RES, exist_ok=True)
img = Image.open(SRC).convert("RGBA")
# قص الهوامش البيضاء الزائدة للحصول على أيقونة ممتلئة
bg = Image.new("RGBA", img.size, (255,255,255,255))
diff = Image.alpha_composite(bg, img).convert("RGB")
import numpy as np
a = np.array(diff)
mask = (a.sum(axis=2) < 720)
ys, xs = np.where(mask)
if len(xs) > 100:
    box = (max(xs.min()-8,0), max(ys.min()-8,0), min(xs.max()+8, img.width), min(ys.max()+8, img.height))
    img = img.crop(box)
sq = Image.new("RGBA", (max(img.size), max(img.size)), (255,255,255,255))
sq.paste(img, ((sq.width-img.width)//2, (sq.height-img.height)//2), img)
def save(im, name, size, bgcolor=(255,255,255,255)):
    canvas = Image.new("RGBA", (size,size), bgcolor)
    r = im.copy(); r.thumbnail((size,size), Image.LANCZOS)
    canvas.paste(r, ((size-r.width)//2, (size-r.height)//2), r)
    canvas.convert("RGB").save(os.path.join(OUT,name), "PNG", optimize=True)
for s in (48,72,96,144,192,512):
    save(sq, f"icon-{s}.png", s)
for s in (192,512):
    pad = int(s*0.22); inner = s - pad*2
    canvas = Image.new("RGB",(s,s),(11,42,91))
    r = sq.copy(); r.thumbnail((inner,inner), Image.LANCZOS)
    canvas.paste(r, ((s-r.width)//2,(s-r.height)//2), r)
    canvas.save(os.path.join(OUT,f"maskable-{s}.png"),"PNG",optimize=True)
save(sq, "apple-touch-icon-180.png", 180)
save(sq, "favicon-32.png", 32)
save(sq, "favicon-16.png", 16)
# شاشات البدء (splash) بخلفية كحلية رسمية
for (w,h,name) in [(1024,1024,"splash.png"),(2732,2732,"splash-dark.png"),(2048,2732,"splash-port-xxhdpi.png")]:
    c = Image.new("RGB",(w,h),(11,42,91))
    r = sq.copy(); r.thumbnail((int(min(w,h)*0.42),)*2, Image.LANCZOS)
    c.paste(r, ((w-r.width)//2,(h-r.height)//2), r)
    c.save(os.path.join(OUT,name),"PNG",optimize=True)
# نسخ شعار كامل للواجهة + موارد Capacitor
Image.open(SRC).convert("RGB").save("/home/user/super-banking/client/public/logo.png","PNG",optimize=True)
for d in ("icon","splash"):
    os.makedirs(os.path.join(RES,d), exist_ok=True)
Image.open(SRC).convert("RGB").save(os.path.join(RES,"icon","logo.png"),"PNG")
Image.open("/home/user/super-banking/client/public/icons/icon-1024.png" if os.path.exists("/home/user/super-banking/client/public/icons/icon-1024.png") else "/home/user/super-banking/client/public/icons/icon-512.png").save(os.path.join(RES,"icon","icon.png"),"PNG")
print("ICONS OK")
