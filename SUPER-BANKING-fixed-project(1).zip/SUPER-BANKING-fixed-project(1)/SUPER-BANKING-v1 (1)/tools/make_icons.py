"""توليد أيقونات التطبيق (PWA / APK) من الشعار الرسمي."""
from PIL import Image, ImageDraw
import os

SRC = "/home/user/super-banking/assets/logo.png"
OUT = "/home/user/super-banking/client/public/icons"
os.makedirs(OUT, exist_ok=True)

NAVY = (11, 42, 91, 255)
WHITE = (255, 255, 255, 255)


def make(size, bg, pad_ratio, out_name, rounded=False):
    img = Image.open(SRC).convert("RGBA")
    canvas = Image.new("RGBA", (size, size), bg)
    inner = int(size * (1 - 2 * pad_ratio))
    img.thumbnail((inner, inner), Image.LANCZOS)
    x = (size - img.width) // 2
    y = (size - img.height) // 2
    canvas.alpha_composite(img, (x, y))
    if rounded:
        mask = Image.new("L", (size, size), 0)
        d = ImageDraw.Draw(mask)
        d.rounded_rectangle([0, 0, size - 1, size - 1], radius=int(size * 0.22), fill=255)
        canvas.putalpha(mask)
    canvas.save(os.path.join(OUT, out_name), "PNG")
    print("✔", out_name, size)


# أيقونة التطبيق: خلفية بيضاء والشعار في المنتصف
make(192, WHITE, 0.11, "icon-192.png")
make(512, WHITE, 0.11, "icon-512.png")
# أيقونة قابلة للقص (maskable): خلفية كحولية مع مساحة أمان أكبر
make(512, NAVY, 0.20, "icon-maskable-512.png")
# أيقونة أبل (بدون شفافية)
make(180, WHITE, 0.12, "apple-touch-icon.png")
# شعار الواجهة
logo_small = Image.open(SRC).convert("RGBA")
logo_small.thumbnail((320, 320), Image.LANCZOS)
logo_small.save("/home/user/super-banking/client/public/logo.png", "PNG")
print("✔ logo.png")
